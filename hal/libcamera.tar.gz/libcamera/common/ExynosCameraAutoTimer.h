/*
**
** Copyright 2013, Samsung Electronics Co. LTD
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

/*!
 * \file      ExynosCameraAutoTimer.h
 * \brief     hearder file for ExynosCameraAutoTimer
 * \author    Sangwoo.Park(sw5771.park@samsung.com)
 * \date      2013/06/18
 *
 * <b>Revision History: </b>
 * - 2013/06/18 : Sangwoo.Park(sw5771.park@samsung.com) \n
 *   Initial version
 *
 */

#ifndef EXYNOS_CAMERA_AUTO_TIMER_H
#define EXYNOS_CAMERA_AUTO_TIMER_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <camera/CameraParametersExtra.h>
#include <utils/threads.h>

namespace android {
/*
class ExynosCameraDurationTimer {
public:
    ExynosCameraDurationTimer()
    {
        memset(&m_startTime, 0x00, sizeof(struct timeval));
        memset(&m_stopTime, 0x00, sizeof(struct timeval));
    }
    ~ExynosCameraDurationTimer() {}

    void start()
    {
        gettimeofday(&m_startTime, NULL);
    };

    void stop()
    {
        gettimeofday(&m_stopTime, NULL);
    };

    uint64_t durationMsecs() const
    {
        nsecs_t stop  = ((nsecs_t)m_stopTime.tv_sec) * 1000LL + ((nsecs_t)m_stopTime.tv_usec) / 1000LL;
        nsecs_t start = ((nsecs_t)m_startTime.tv_sec) * 1000LL + ((nsecs_t)m_startTime.tv_usec) / 1000LL;

        return stop - start;
    };

    uint64_t durationUsecs() const
    {
        nsecs_t stop  = ((nsecs_t)m_stopTime.tv_sec) * 1000000LL + ((nsecs_t)m_stopTime.tv_usec);
        nsecs_t start = ((nsecs_t)m_startTime.tv_sec) * 1000000LL + ((nsecs_t)m_startTime.tv_usec);

        return stop - start;
    };

private:
    struct timeval  m_startTime;
    struct timeval  m_stopTime;
};
*/
class ExynosCameraDurationTimer {
public:
    ExynosCameraDurationTimer() {}
    ~ExynosCameraDurationTimer() {}
    void start();
    void stop();
    long long durationMsecs() const;
    long long durationUsecs() const;
    static long long subtractTimevals(const struct timeval* ptv1,
        const struct timeval* ptv2);
    static void addToTimeval(struct timeval* ptv, long usec);
private:
    struct timeval  m_startTime;
    struct timeval  m_stopTime;
};

void ExynosCameraDurationTimer::start(void) 
{
    gettimeofday(&m_startTime, NULL);
}

void ExynosCameraDurationTimer::stop(void)
{
    gettimeofday(&m_stopTime, NULL);
}

long long ExynosCameraDurationTimer::durationMsecs(void) const
{
    long long stop  = ((long long)m_stopTime.tv_sec) * 1000LL + ((long long)m_stopTime.tv_usec) / 1000LL;
    long long start = ((long long)m_startTime.tv_sec) * 1000LL + ((long long)m_startTime.tv_usec) / 1000LL;

    return stop - start;
};
    
long long ExynosCameraDurationTimer::durationUsecs(void) const
{
    return (long) subtractTimevals(&m_stopTime, &m_startTime);
}

/*static*/ long long ExynosCameraDurationTimer::subtractTimevals(const struct timeval* ptv1,
    const struct timeval* ptv2)
{
    long long stop  = ((long long) ptv1->tv_sec) * 1000000LL +
                      ((long long) ptv1->tv_usec);
    long long start = ((long long) ptv2->tv_sec) * 1000000LL +
                      ((long long) ptv2->tv_usec);
    return stop - start;
}

/*static*/ void ExynosCameraDurationTimer::addToTimeval(struct timeval* ptv, long usec)
{
    if (usec < 0) {
        ALOG(LOG_WARN, "", "Negative values not supported in addToTimeval\n");
        return;
    }

    if (ptv->tv_usec >= 1000000) {
        ptv->tv_sec += ptv->tv_usec / 1000000;
        ptv->tv_usec %= 1000000;
    }

    ptv->tv_usec += usec % 1000000;
    if (ptv->tv_usec >= 1000000) {
        ptv->tv_usec -= 1000000;
        ptv->tv_sec++;
    }
    ptv->tv_sec += usec / 1000000;
}

class ExynosCameraAutoTimer {
private:
    ExynosCameraAutoTimer(void)
    {}

public:
    inline ExynosCameraAutoTimer(char *strLog)
    {
        if (m_create(strLog) == false)
            ALOGE("ERR(%s):m_create() fail", __func__);
    }

    inline ExynosCameraAutoTimer(const char *strLog)
    {
        char *strTemp = (char*)strLog;

        if (m_create(strTemp) == false)
            ALOGE("ERR(%s):m_create() fail", __func__);
    }

    inline virtual ~ExynosCameraAutoTimer()
    {
        long long durationTime;

        m_timer.stop();

        durationTime = m_timer.durationUsecs();

        if (m_logStr) {
            ALOGD("DEBUG:duration time(%5d msec):(%s)",
                (int)durationTime / 1000, m_logStr);
        } else {
            ALOGD("DEBUG:duration time(%5d msec):(NULL)",
                (int)durationTime / 1000);
        }
    }

private:
    bool m_create(char *strLog)
    {
        m_logStr = strLog;

        m_timer.start();

        return true;
    }

private:
    ExynosCameraDurationTimer m_timer;
    char         *m_logStr;
};
}; // namespace android

#endif // EXYNOS_CAMERA_AUTO_TIMER_H
