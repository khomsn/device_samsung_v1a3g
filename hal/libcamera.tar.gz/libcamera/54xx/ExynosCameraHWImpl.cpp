/*
**
** Copyright 2013, Samsung Electronics Co. LTD
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

/* #define LOG_NDEBUG 0 */
#define LOG_TAG "ExynosCamera"

#include <log/log.h>

#include <ExynosCameraHWImpl.h>
#include <utils/ThreadDefs.h>
#include <common/ExynosCameraUtils.h>

#define VIDEO_COMMENT_MARKER_H          (0xFFBE)
#define VIDEO_COMMENT_MARKER_L          (0xFFBF)
#define VIDEO_COMMENT_MARKER_LENGTH     (4)
#define JPEG_EOI_MARKER                 (0xFFD9)
#define HIBYTE(x)                       (((x) >> 8) & 0xFF)
#define LOBYTE(x)                       ((x) & 0xFF)


// This hack does two things:
// -- it sets preview to NV21 (YUV420SP)
// -- it sets gralloc to YV12
//
// The reason being: the samsung encoder understands only yuv420sp, and gralloc
// does yv12 and rgb565.  So what we do is we break up the interleaved UV in
// separate V and U planes, which makes preview look good, and enabled the
// encoder as well.
//
// FIXME: Samsung needs to enable support for proper yv12 coming out of the
//        camera, and to fix their video encoder to work with yv12.
// FIXME: It also seems like either Samsung's YUV420SP (NV21) or img's YV12 has
//        the color planes switched.  We need to figure which side is doing it
//        wrong and have the respective party fix it.

namespace android {

gralloc_module_t const* ExynosCameraHWImpl::m_grallocHal;

Mutex ExynosCameraHWImpl::g_is3a0Mutex;
Mutex ExynosCameraHWImpl::g_is3a1Mutex;

ExynosCameraHWImpl::ExynosCameraHWImpl(int cameraId, camera_device_t *dev)
        :
          m_captureInProgress(false),
          m_captureMode(false),
          m_waitForCapture(false),
          m_flip_horizontal(0),
          m_faceDetected(false),
          m_fdThreshold(0),
          m_sensorErrCnt(0),
          m_skipFrame(0),
          m_notifyCb(0),
          m_dataCb(0),
          m_dataCbTimestamp(0),
          m_callbackCookie(0),
          m_enabledMsgType(0),
          m_storedMsg(0),
          m_halDevice(dev)
{
    BUILD_DATE();

    checkAndroidVersion();

    m_cameraId = cameraId;
    m_exynosCameraParameters = new ExynosCameraParameters(m_cameraId);
    ALOGD("DEBUG(%s):Parameters(Id=%d) created", __FUNCTION__, m_cameraId);

    m_exynosCameraActivityControl = m_exynosCameraParameters->getActivityControl();

    m_previewFrameFactory      = NULL;
    m_reprocessingFrameFactory = NULL;

    m_ionAllocator = NULL;
    m_grAllocator  = NULL;
    m_mhbAllocator = NULL;

    m_createInternalBufferManager(&m_bayerBufferMgr, "BAYER_BUF");
    m_createInternalBufferManager(&m_3aaBufferMgr, "3A1_BUF");
    m_createInternalBufferManager(&m_ispBufferMgr, "ISP_BUF");

    /* reprocessing Buffer */
    m_createInternalBufferManager(&m_ispReprocessingBufferMgr, "ISP_RE_BUF");
    m_createInternalBufferManager(&m_sccReprocessingBufferMgr, "SCC_RE_BUF");

    m_createInternalBufferManager(&m_sccBufferMgr, "SCC_BUF");
    m_createInternalBufferManager(&m_gscBufferMgr, "GSC_BUF");
    m_createInternalBufferManager(&m_jpegBufferMgr, "JPEG_BUF");

    /* preview Buffer */
    m_scpBufferMgr = NULL;
    m_createInternalBufferManager(&m_previewCallbackBufferMgr, "PREVIEW_CB_BUF");
    m_createInternalBufferManager(&m_highResolutionCallbackBufferMgr, "HIGH_RESOLUTION_CB_BUF");

    /* recording Buffer */
    m_recordingCallbackHeap = NULL;
    m_createInternalBufferManager(&m_recordingBufferMgr, "REC_BUF");

    m_createThreads();

    m_pipeFrameDoneQ     = new frame_queue_t;
    dstIspReprocessingQ  = new frame_queue_t;
    dstSccReprocessingQ  = new frame_queue_t;
    dstGscReprocessingQ  = new frame_queue_t;

    dstJpegReprocessingQ = new frame_queue_t;

    m_previewQ     = new frame_queue_t(m_previewThread);
    m_previewFrontQ = new frame_queue_t(m_previewThread);
    m_recordingQ   = new frame_queue_t(m_recordingThread);
    m_postPictureQ = new frame_queue_t(m_postPictureThread);
    m_jpegCallbackQ = new jpeg_callback_queue_t;

    /* set the wait time to 2000ms */
    dstIspReprocessingQ->setWaitTime(2000000000);
    dstSccReprocessingQ->setWaitTime(50000000);
    dstGscReprocessingQ->setWaitTime(2000000000);
    dstJpegReprocessingQ->setWaitTime(2000000000);

    m_jpegCallbackQ->setWaitTime(1000000000);

    memset(&m_frameMetadata, 0, sizeof(camera_frame_metadata_t));
    memset(m_faces, 0, sizeof(camera_face_t) * NUM_OF_DETECTED_FACES);

    m_exitAutoFocusThread = false;
    m_autoFocusRunning    = false;
    m_previewEnabled   = false;
    m_pictureEnabled   = false;
    m_recordingEnabled = false;
    m_zslPictureEnabled   = false;
    m_flagStartFaceDetection = false;
    m_captureSelector = NULL;
    m_sccCaptureSelector = NULL;
    m_autoFocusType = 0;
    m_hdrEnabled = false;
    m_doCscRecording = true;

#ifdef FPS_CHECK
    for (int i = 0; i < DEBUG_MAX_PIPE_NUM; i++)
        m_debugFpsCount[i] = 0;
#endif

    m_stopBurstShot = false;
    m_burst[JPEG_SAVE_THREAD0] = false;
    m_burst[JPEG_SAVE_THREAD1] = false;
    m_burst[JPEG_SAVE_THREAD2] = false;

    m_running[JPEG_SAVE_THREAD0] = false;
    m_running[JPEG_SAVE_THREAD1] = false;
    m_running[JPEG_SAVE_THREAD2] = false;
    m_callbackState = 0;
    m_callbackStateOld = 0;
    m_callbackMonitorCount = 0;

    m_highResolutionCallbackRunning = false;
    m_highResolutionCallbackQ = new frame_queue_t(m_highResolutionCallbackThread);
    m_highResolutionCallbackQ->setWaitTime(50000000);
    m_skipReprocessing = false;
    m_isFirstStart = true;


    m_exynosconfig = NULL;
    m_setConfigInform();

    /* HACK Reset Preview Flag*/
    m_resetPreview = false;

    m_dynamicSccCount = 0;
    m_previewBufferCount = NUM_PREVIEW_BUFFERS;
}

status_t  ExynosCameraHWImpl::m_setConfigInform() {
    struct ExynosConfigInfo exynosConfig;
    memset((void *)&exynosConfig, 0x00, sizeof(exynosConfig));

    exynosConfig.mode = CONFIG_MODE::NORMAL;

    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.num_bayer_buffers = NUM_BAYER_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.init_bayer_buffers = INIT_BAYER_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.num_preview_buffers = NUM_PREVIEW_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.num_picture_buffers = NUM_PICTURE_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.num_reprocessing_buffers = NUM_REPROCESSING_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.num_recording_buffers = NUM_RECORDING_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.num_fastaestable_buffer = INITIAL_SKIP_FRAME;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.reprocessing_bayer_hold_count = REPROCESSING_BAYER_HOLD_COUNT;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.front_num_bayer_buffers = FRONT_NUM_BAYER_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].bufInfo.front_num_picture_buffers = FRONT_NUM_PICTURE_BUFFERS;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_FLITE] = 3;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_3AA_ISP] = 3;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_SCC] = 1;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_SCP] = 3;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_FLITE_FRONT] = 3;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_SCC_FRONT] = 1;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_SCP_FRONT] = 3;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_SCP_REPROCESSING] = 3;
    exynosConfig.info[CONFIG_MODE::NORMAL].pipeInfo.prepare[PIPE_SCC_REPROCESSING] = 1;
    if( getCameraId() == CAMERA_ID_BACK ) {
        /* Config HIGH_SPEED 60 buffer & pipe info */
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_bayer_buffers = NUM_BAYER_BUFFERS + 5;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers = INIT_BAYER_BUFFERS * 2;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_preview_buffers = NUM_PREVIEW_BUFFERS + 5;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_picture_buffers = NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_reprocessing_buffers = NUM_REPROCESSING_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_recording_buffers = NUM_RECORDING_BUFFERS + 5;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_fastaestable_buffer = INITIAL_SKIP_FRAME;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.reprocessing_bayer_hold_count = REPROCESSING_BAYER_HOLD_COUNT;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.front_num_bayer_buffers = FRONT_NUM_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.front_num_picture_buffers = FRONT_NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_FLITE] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_3AA_ISP] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_SCP] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_SCP_REPROCESSING] = 3;
        /* Config HIGH_SPEED 120 buffer & pipe info */
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_bayer_buffers = NUM_BAYER_BUFFERS * 3;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers = INIT_BAYER_BUFFERS * 3;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_preview_buffers = NUM_PREVIEW_BUFFERS * 3;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_picture_buffers = NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_reprocessing_buffers = NUM_REPROCESSING_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_recording_buffers = NUM_RECORDING_BUFFERS *3;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_fastaestable_buffer = INITIAL_SKIP_FRAME;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.reprocessing_bayer_hold_count = REPROCESSING_BAYER_HOLD_COUNT;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.front_num_bayer_buffers = FRONT_NUM_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.front_num_picture_buffers = FRONT_NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_FLITE] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_3AA_ISP] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_SCP] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_SCP_REPROCESSING] = 3;
    } else {
        /* Config HIGH_SPEED 60 buffer & pipe info */
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_bayer_buffers = NUM_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers = INIT_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_preview_buffers = NUM_PREVIEW_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_picture_buffers = NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_reprocessing_buffers = NUM_REPROCESSING_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_recording_buffers = NUM_RECORDING_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.num_fastaestable_buffer = INITIAL_SKIP_FRAME;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.reprocessing_bayer_hold_count = REPROCESSING_BAYER_HOLD_COUNT;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.front_num_bayer_buffers = FRONT_NUM_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.front_num_picture_buffers = FRONT_NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_FLITE_FRONT] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_SCP_FRONT] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_60].pipeInfo.prepare[PIPE_SCP_REPROCESSING] = 3;
        /* Config HIGH_SPEED 120 buffer & pipe info */
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_bayer_buffers = NUM_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers = INIT_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_preview_buffers = NUM_PREVIEW_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_picture_buffers = NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_reprocessing_buffers = NUM_REPROCESSING_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_recording_buffers = NUM_RECORDING_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.num_fastaestable_buffer = INITIAL_SKIP_FRAME;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.reprocessing_bayer_hold_count = REPROCESSING_BAYER_HOLD_COUNT;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.front_num_bayer_buffers = FRONT_NUM_BAYER_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.front_num_picture_buffers = FRONT_NUM_PICTURE_BUFFERS;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_FLITE] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_3AA_ISP] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_SCP] = exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].bufInfo.init_bayer_buffers;
        exynosConfig.info[CONFIG_MODE::HIGHSPEED_120].pipeInfo.prepare[PIPE_SCP_REPROCESSING] = 3;
    }

     m_exynosCameraParameters->setConfig(&exynosConfig);

     m_exynosconfig = m_exynosCameraParameters->getConfig();

    return NO_ERROR;
}

void ExynosCameraHWImpl::m_createThreads(void)
{
    m_mainThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_mainThreadFunc, "ExynosCameraThread", PRIORITY_URGENT_DISPLAY);
    ALOGD("DEBUG(%s):mainThread created", __FUNCTION__);

    m_previewThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_previewThreadFunc, "previewThread", PRIORITY_DISPLAY);
    ALOGD("DEBUG(%s):previewThread created", __FUNCTION__);

    m_setBuffersThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_setBuffersThreadFunc, "setBuffersThread");
    ALOGD("DEBUG(%s):setBuffersThread created", __FUNCTION__);

    m_startPictureInternalThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_startPictureInternalThreadFunc, "startPictureInternalThread");
    ALOGD("DEBUG(%s):startPictureInternalThread created", __FUNCTION__);

    m_prePictureThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_prePictureThreadFunc, "prePictureThread");
    ALOGD("DEBUG(%s):prePictureThread created", __FUNCTION__);

    m_pictureThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_pictureThreadFunc, "PictureThread");
    ALOGD("DEBUG(%s):pictureThread created", __FUNCTION__);

    m_postPictureThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_postPictureThreadFunc, "postPictureThread");
    ALOGD("DEBUG(%s):postPictureThread created", __FUNCTION__);

    m_recordingThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_recordingThreadFunc, "recordingThread");
    ALOGD("DEBUG(%s):recordingThread created", __FUNCTION__);

    m_autoFocusThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_autoFocusThreadFunc, "AutoFocusThread");
    ALOGD("DEBUG(%s):autoFocusThread created", __FUNCTION__);

    m_monitorThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_monitorThreadFunc, "monitorThread");
    ALOGD("DEBUG(%s):monitorThread created", __FUNCTION__);

    m_jpegCallbackThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_jpegCallbackThreadFunc, "jpegCallbackThread");
    ALOGD("DEBUG(%s):jpegCallbackThread created", __FUNCTION__);

    /* high resolution preview callback Thread */
    m_highResolutionCallbackThread = new mainCameraThread(this, &ExynosCameraHWImpl::m_highResolutionCallbackThreadFunc, "m_highResolutionCallbackThread");
    ALOGD("DEBUG(%s):highResolutionCallbackThread created", __FUNCTION__);
}

ExynosCameraHWImpl::~ExynosCameraHWImpl()
{
    CLOGD("DEBUG(%s):in", __func__);

    this->release();

    CLOGD("DEBUG(%s):out", __func__);
}

void ExynosCameraHWImpl::release()
{
    ALOGI("INFO(%s[%d]): -IN-", __FUNCTION__, __LINE__);
    int ret = 0;

    if (m_previewFrameFactory != NULL) {
        ret = m_previewFrameFactory->destroy();
        if (ret < 0)
            ALOGE("ERR(%s[%d]):mainCameraFrameFactory destroy fail", __FUNCTION__, __LINE__);

        delete m_previewFrameFactory;
        m_previewFrameFactory = NULL;
        ALOGD("DEBUG(%s):FrameFactory(previewFrameFactory) destroyed", __FUNCTION__);
    }

    if (m_reprocessingFrameFactory != NULL) {
        ret = m_reprocessingFrameFactory->destroy();
        if (ret < 0)
            ALOGE("ERR(%s[%d]):frameReprocessingFactory destroy fail", __FUNCTION__, __LINE__);
        delete m_reprocessingFrameFactory;
        m_reprocessingFrameFactory = NULL;
        ALOGD("DEBUG(%s):FrameFactory(reprocessingFrameFactory) destroyed", __FUNCTION__);
    }

    if (m_exynosCameraParameters != NULL) {
        delete m_exynosCameraParameters;
        m_exynosCameraParameters = NULL;
        ALOGD("DEBUG(%s):Parameters(Id=%d) destroyed", __FUNCTION__, m_cameraId);
    }

    /* free all buffers */
    m_releaseBuffers();

    if (m_ionAllocator != NULL) {
        delete m_ionAllocator;
        m_ionAllocator = NULL;
    }

    if (m_grAllocator != NULL) {
        delete m_grAllocator;
        m_grAllocator = NULL;
    }

    if (m_pipeFrameDoneQ != NULL) {
        delete m_pipeFrameDoneQ;
        m_pipeFrameDoneQ = NULL;
    }

    if (dstIspReprocessingQ != NULL) {
        delete dstIspReprocessingQ;
        dstIspReprocessingQ = NULL;
    }

    if (dstSccReprocessingQ != NULL) {
        delete dstSccReprocessingQ;
        dstSccReprocessingQ = NULL;
    }

    if (dstGscReprocessingQ != NULL) {
        delete dstGscReprocessingQ;
        dstGscReprocessingQ = NULL;
    }

    if (dstJpegReprocessingQ != NULL) {
        delete dstJpegReprocessingQ;
        dstJpegReprocessingQ = NULL;
    }

    if (m_postPictureQ != NULL) {
        delete m_postPictureQ;
        m_postPictureQ = NULL;
    }

    if (m_jpegCallbackQ != NULL) {
        delete m_jpegCallbackQ;
        m_jpegCallbackQ = NULL;
    }

    if (m_previewQ != NULL) {
        delete m_previewQ;
        m_previewQ = NULL;
    }

    if (m_previewFrontQ != NULL) {
        delete m_previewFrontQ;
        m_previewFrontQ = NULL;
    }

    if (m_recordingQ != NULL) {
        delete m_recordingQ;
        m_recordingQ = NULL;
    }

    if (m_highResolutionCallbackQ != NULL) {
        delete m_highResolutionCallbackQ;
        m_highResolutionCallbackQ = NULL;
    }

    if (m_bayerBufferMgr != NULL) {
        delete m_bayerBufferMgr;
        m_bayerBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(bayerBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_3aaBufferMgr != NULL) {
        delete m_3aaBufferMgr;
        m_3aaBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(3aaBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_ispBufferMgr != NULL) {
        delete m_ispBufferMgr;
        m_ispBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(ispBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_scpBufferMgr != NULL) {
        delete m_scpBufferMgr;
        m_scpBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(scpBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_ispReprocessingBufferMgr != NULL) {
        delete m_ispReprocessingBufferMgr;
        m_ispReprocessingBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(ispReprocessingBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_sccReprocessingBufferMgr != NULL) {
        delete m_sccReprocessingBufferMgr;
        m_sccReprocessingBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(sccReprocessingBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_sccBufferMgr != NULL) {
        delete m_sccBufferMgr;
        m_sccBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(sccBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_gscBufferMgr != NULL) {
        delete m_gscBufferMgr;
        m_gscBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(gscBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_jpegBufferMgr != NULL) {
        delete m_jpegBufferMgr;
        m_jpegBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(jpegBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_previewCallbackBufferMgr != NULL) {
        delete m_previewCallbackBufferMgr;
        m_previewCallbackBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(previewCallbackBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_highResolutionCallbackBufferMgr != NULL) {
        delete m_highResolutionCallbackBufferMgr;
        m_highResolutionCallbackBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(m_highResolutionCallbackBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_recordingBufferMgr != NULL) {
        delete m_recordingBufferMgr;
        m_recordingBufferMgr = NULL;
        ALOGD("DEBUG(%s):BufferManager(recordingBufferMgr) destroyed", __FUNCTION__);
    }

    if (m_captureSelector != NULL) {
        delete m_captureSelector;
        m_captureSelector = NULL;
    }

    if (m_sccCaptureSelector != NULL) {
        delete m_sccCaptureSelector;
        m_sccCaptureSelector = NULL;
    }

    if (m_recordingCallbackHeap != NULL) {
        m_recordingCallbackHeap->release(m_recordingCallbackHeap);
        delete m_recordingCallbackHeap;
        m_recordingCallbackHeap = NULL;
        ALOGD("DEBUG(%s):BufferManager(recordingCallbackHeap) destroyed", __FUNCTION__);
    }

    m_isFirstStart = true;
    m_previewBufferCount = NUM_PREVIEW_BUFFERS;

    ALOGI("INFO(%s[%d]): -OUT-", __FUNCTION__, __LINE__);
}

int ExynosCameraHWImpl::getCameraId() const
{
    return m_cameraId;
}


void ExynosCameraHWImpl::m_disableMsgType(int32_t msgType, bool restore)
{
    CLOGD("DEBUG(%s):msgType = 0x%x, m_storedMsg = 0x%x, m_enabledMsgType(0x%x -> 0x%x)",
        __func__, msgType, m_storedMsg, m_enabledMsgType, m_enabledMsgType & ~msgType);

    if (m_storedMsg == 0 && m_enabledMsgType != 0) {
        if (restore == true) {
            m_storedMsg = m_enabledMsgType;
            m_enabledMsgType &= ~msgType;
        } else {
            m_enabledMsgType &= ~msgType;
            m_storedMsg = m_enabledMsgType;
        }
    }
}

void ExynosCameraHWImpl::m_restoreMsgType(void)
{
    CLOGD("DEBUG(%s):m_storedMsg = 0x%x, m_enabledMsgType(0x%x -> 0x%x)",
         __func__, m_storedMsg, m_enabledMsgType, m_storedMsg);

    if (m_storedMsg != 0) {
        m_enabledMsgType = m_storedMsg;
        m_storedMsg = 0;
    }
}

bool ExynosCameraHWImpl::m_initSecCamera(int cameraId)
{
    CLOGD("DEBUG(%s):in", __func__);

    if (m_secCamera != NULL) {
        CLOGE("ERR(%s):m_secCamera object is NULL", __func__);
        return false;
    }

    m_secCamera = new ExynosCamera;

    if (m_secCamera->create(cameraId) == false) {
        CLOGE("ERR(%s):Fail on m_secCamera->create(%d)", __func__, cameraId);
        return false;
    }

#ifdef START_HW_THREAD_ENABLE
    m_startThreadMain = new StartThreadMain(this);
    m_startThreadReprocessing = new StartThreadReprocessing(this);
    m_startThreadBufAlloc = new StartThreadBufAlloc(this);
#endif

    m_previewThread = new CameraThread(this, &ExynosCameraHWImpl::m_previewThreadFunc);
    m_videoThread = new VideoThread(this);
    m_autoFocusThread = new AutoFocusThread(this);
    m_pictureThread = new PictureThread(this);

    m_sensorThread = new CameraThread(this, &ExynosCameraHWImpl::m_sensorThreadFuncWrap);
    m_ispThread = new CameraThread(this, &ExynosCameraHWImpl::m_ispThreadFunc);

    if (cameraId == 0)
        m_sensorThreadReprocessing = new CameraThread(this, &ExynosCameraHWImpl::m_sensorThreadFuncReprocessing);

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}

void ExynosCameraHWImpl::m_initDefaultParameters(int cameraId)
{
    if (m_secCamera == NULL) {
        CLOGE("ERR(%s):m_secCamera object is NULL", __func__);
        return;
    }

    CameraParameters p;

    String8 parameterString;

    char * cameraName;
    cameraName = m_secCamera->getCameraName();
    if (cameraName == NULL)
        CLOGE("ERR(%s):getCameraName() fail", __func__);

    char strBuf[256];
    String8 listString;

    // preview
    int previewMaxW  = 0;
    int previewMaxH  = 0;

    m_secCamera->getSupportedPreviewSizes(&previewMaxW, &previewMaxH);

    listString.setTo("");
    if (m_getResolutionList(listString, &previewMaxW, &previewMaxH, MODE_PREVIEW) == false) {
        CLOGE("ERR(%s):m_getResolutionList() fail", __func__);

        previewMaxW = 640;
        previewMaxH = 480;
        listString = String8::format("%dx%d", previewMaxW, previewMaxH);
    }

    p.set(CameraParameters::KEY_SUPPORTED_PREVIEW_SIZES, listString.string());
    CLOGD("DEBUG(%s): Default preview size is %dx%d", __func__, previewMaxW, previewMaxH);
    p.setPreviewSize(previewMaxW, previewMaxH);

    listString.setTo("");
    listString = String8::format("%s,%s", CameraParameters::PIXEL_FORMAT_YUV420SP, CameraParameters::PIXEL_FORMAT_YUV420P);
    p.set(CameraParameters::KEY_SUPPORTED_PREVIEW_FORMATS, listString);
    p.setPreviewFormat(CameraParameters::PIXEL_FORMAT_YUV420SP);

    // video
    int videoMaxW = 0;
    int videoMaxH = 0;

    m_secCamera->getSupportedVideoSizes(&videoMaxW, &videoMaxH);

    listString.setTo("");
    if (m_getResolutionList(listString, &videoMaxW, &videoMaxH, MODE_VIDEO) == false) {
        CLOGE("ERR(%s):m_getResolutionList() fail", __func__);

        videoMaxW = 640;
        videoMaxH = 480;
        listString = String8::format("%dx%d", videoMaxW, videoMaxH);
    }
    p.set(CameraParameters::KEY_SUPPORTED_VIDEO_SIZES, listString.string());
    CLOGD("DEBUG(%s): Default video size is %dx%d", __func__, videoMaxW, videoMaxH);
    p.setVideoSize(videoMaxW, videoMaxH);

    int cropX, cropY, cropW, cropH = 0;
    m_secCamera->getCropRect(previewMaxW,  previewMaxH,
                             videoMaxW,    videoMaxH,
                             &cropX, &cropY, &cropW, &cropH,
                             0);

    listString.setTo("");
    listString = String8::format("%dx%d", previewMaxW, previewMaxH);
    p.set(CameraParameters::KEY_PREFERRED_PREVIEW_SIZE_FOR_VIDEO, listString.string());

    p.set(CameraParameters::KEY_VIDEO_FRAME_FORMAT, CameraParameters::PIXEL_FORMAT_YUV420SP);

    if (m_secCamera->isVideoSnapshotSupported() == true)
        p.set(CameraParameters::KEY_VIDEO_SNAPSHOT_SUPPORTED, "true");
    else
        p.set(CameraParameters::KEY_VIDEO_SNAPSHOT_SUPPORTED, "false");

    if (m_secCamera->isVideoStabilizationSupported() == true)
        p.set(CameraParameters::KEY_VIDEO_STABILIZATION_SUPPORTED, "true");
    else
        p.set(CameraParameters::KEY_VIDEO_STABILIZATION_SUPPORTED, "false");

    // picture
    int pictureMaxW = 0;
    int pictureMaxH = 0;
    int matchedW = 0;
    int matchedH = 0;

    m_secCamera->getSupportedPictureSizes(&pictureMaxW, &pictureMaxH);

    listString.setTo("");
    if (m_getResolutionList(listString, &pictureMaxW, &pictureMaxH, MODE_PICTURE) == false) {
        CLOGE("ERR(%s):m_getResolutionList() fail", __func__);

        pictureMaxW = 640;
        pictureMaxW = 480;
        listString = String8::format("%dx%d", pictureMaxW, pictureMaxH);
    }
    p.set(CameraParameters::KEY_SUPPORTED_PICTURE_SIZES, listString.string());

    if (m_getMatchedPictureSize(previewMaxW, previewMaxH, &matchedW, &matchedH) == false) {
        CLOGW("WRN(%s): Could not found matched picture size, set the max size(%dx%d)", __func__, pictureMaxW, pictureMaxH);
        p.setPictureSize(pictureMaxW, pictureMaxH);
    } else {
        CLOGD("DEBUG(%s): Default picture size is %dx%d", __func__, matchedW, matchedH);
        p.setPictureSize(matchedW, matchedH);
    }

    p.set(CameraParameters::KEY_SUPPORTED_PICTURE_FORMATS,
          CameraParameters::PIXEL_FORMAT_JPEG);

    p.setPictureFormat(CameraParameters::PIXEL_FORMAT_JPEG);

    p.set(CameraParameters::KEY_JPEG_QUALITY, "100"); // maximum quality

    // thumbnail
    int thumbnailMaxW = 0;
    int thumbnailMaxH = 0;

    m_secCamera->getSupportedJpegThumbnailSizes(&thumbnailMaxW, &thumbnailMaxH);
    listString.setTo("");
    if (m_getResolutionList(listString, &thumbnailMaxW, &thumbnailMaxH, MODE_PICTURE) == false) {
        listString = String8::format("%dx%d", thumbnailMaxW, thumbnailMaxH);
    }
    /*
     * listString = String8::format("%dx%d", thumbnailMaxW, thumbnailMaxH);
     * listString.append(",320x180");
     */
    listString.append(",0x0");

    p.set(CameraParameters::KEY_SUPPORTED_JPEG_THUMBNAIL_SIZES, listString.string());
    p.set(CameraParameters::KEY_JPEG_THUMBNAIL_WIDTH,  thumbnailMaxW);
    p.set(CameraParameters::KEY_JPEG_THUMBNAIL_HEIGHT, thumbnailMaxH);
    p.set(CameraParameters::KEY_JPEG_THUMBNAIL_QUALITY, "100");

    // exposure
    p.set(CameraParameters::KEY_MIN_EXPOSURE_COMPENSATION, m_secCamera->getMinExposureCompensation());
    p.set(CameraParameters::KEY_MAX_EXPOSURE_COMPENSATION, m_secCamera->getMaxExposureCompensation());
    p.set(CameraParameters::KEY_EXPOSURE_COMPENSATION, m_secCamera->getExposureCompensation());
    p.setFloat(CameraParameters::KEY_EXPOSURE_COMPENSATION_STEP, m_secCamera->getExposureCompensationStep());

    if (m_secCamera->isAutoExposureLockSupported() == true)
        p.set(CameraParameters::KEY_AUTO_EXPOSURE_LOCK_SUPPORTED, "true");
    else
        p.set(CameraParameters::KEY_AUTO_EXPOSURE_LOCK_SUPPORTED, "false");

    // face detection
    p.set(CameraParameters::KEY_MAX_NUM_DETECTED_FACES_HW, m_secCamera->getMaxNumDetectedFaces());
    p.set(CameraParameters::KEY_MAX_NUM_DETECTED_FACES_SW, 0);

    // focus mode
    int focusMode = m_secCamera->getSupportedFocusModes();
    parameterString.setTo("");
    if (focusMode & ExynosCamera::FOCUS_MODE_AUTO) {
        parameterString.append(CameraParameters::FOCUS_MODE_AUTO);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_INFINITY) {
        parameterString.append(CameraParameters::FOCUS_MODE_INFINITY);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_MACRO) {
        parameterString.append(CameraParameters::FOCUS_MODE_MACRO);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_FIXED) {
        parameterString.append(CameraParameters::FOCUS_MODE_FIXED);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_EDOF) {
        parameterString.append(CameraParameters::FOCUS_MODE_EDOF);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_CONTINUOUS_VIDEO) {
        parameterString.append(CameraParameters::FOCUS_MODE_CONTINUOUS_VIDEO);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_CONTINUOUS_PICTURE) {
        parameterString.append(CameraParameters::FOCUS_MODE_CONTINUOUS_PICTURE);
        parameterString.append(",");
    }
    if (focusMode & ExynosCamera::FOCUS_MODE_CONTINUOUS_PICTURE_MACRO)
        parameterString.append("continuous-picture-macro");

    p.set(CameraParameters::KEY_SUPPORTED_FOCUS_MODES,
          parameterString.string());

    if (focusMode & ExynosCamera::FOCUS_MODE_AUTO)
        p.set(CameraParameters::KEY_FOCUS_MODE,
              CameraParameters::FOCUS_MODE_AUTO);
    else if (focusMode & ExynosCamera::FOCUS_MODE_CONTINUOUS_PICTURE)
        p.set(CameraParameters::KEY_FOCUS_MODE,
              CameraParameters::FOCUS_MODE_CONTINUOUS_PICTURE);
    else if (focusMode & ExynosCamera::FOCUS_MODE_CONTINUOUS_VIDEO)
        p.set(CameraParameters::KEY_FOCUS_MODE,
              CameraParameters::FOCUS_MODE_CONTINUOUS_VIDEO);
    else if (focusMode & ExynosCamera::FOCUS_MODE_INFINITY)
        p.set(CameraParameters::KEY_FOCUS_MODE,
              CameraParameters::FOCUS_MODE_INFINITY);
    else
        p.set(CameraParameters::KEY_FOCUS_MODE,
          CameraParameters::FOCUS_MODE_FIXED);

    // HACK
    if (cameraId == ExynosCamera::CAMERA_ID_BACK) {
        p.set(CameraParameters::KEY_FOCUS_DISTANCES,
              BACK_CAMERA_AUTO_FOCUS_DISTANCES_STR);
        p.set(CameraParameters::FOCUS_DISTANCE_INFINITY,
              BACK_CAMERA_FOCUS_DISTANCE_INFINITY);
    } else {
        p.set(CameraParameters::KEY_FOCUS_DISTANCES,
              FRONT_CAMERA_FOCUS_DISTANCES_STR);
        p.set(CameraParameters::FOCUS_DISTANCE_INFINITY,
              FRONT_CAMERA_FOCUS_DISTANCE_INFINITY);
    }

    p.set(CameraParameters::KEY_MAX_NUM_FOCUS_AREAS, 0);
    if (focusMode & ExynosCamera::FOCUS_MODE_TOUCH) {
        p.set(CameraParameters::KEY_MAX_NUM_FOCUS_AREAS, 1);
        p.set(CameraParameters::KEY_FOCUS_AREAS, "(0,0,0,0,0)");
    }

    // flash
    int flashMode = m_secCamera->getSupportedFlashModes();
    parameterString.setTo("");
    if (flashMode & ExynosCamera::FLASH_MODE_OFF) {
        parameterString.append(CameraParameters::FLASH_MODE_OFF);
        parameterString.append(",");
    }
    if (flashMode & ExynosCamera::FLASH_MODE_AUTO) {
        parameterString.append(CameraParameters::FLASH_MODE_AUTO);
        parameterString.append(",");
    }
    if (flashMode & ExynosCamera::FLASH_MODE_ON) {
        parameterString.append(CameraParameters::FLASH_MODE_ON);
        parameterString.append(",");
    }
    if (flashMode & ExynosCamera::FLASH_MODE_RED_EYE) {
        parameterString.append(CameraParameters::FLASH_MODE_RED_EYE);
        parameterString.append(",");
    }
    if (flashMode & ExynosCamera::FLASH_MODE_TORCH)
        parameterString.append(CameraParameters::FLASH_MODE_TORCH);

    p.set(CameraParameters::KEY_SUPPORTED_FLASH_MODES, parameterString.string());
    p.set(CameraParameters::KEY_FLASH_MODE, CameraParameters::FLASH_MODE_OFF);

    // scene mode
    int sceneMode = m_secCamera->getSupportedSceneModes();
    parameterString.setTo("");
    if (sceneMode & ExynosCamera::SCENE_MODE_AUTO) {
        parameterString.append(CameraParameters::SCENE_MODE_AUTO);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_ACTION) {
        parameterString.append(CameraParameters::SCENE_MODE_ACTION);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_PORTRAIT) {
        parameterString.append(CameraParameters::SCENE_MODE_PORTRAIT);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_LANDSCAPE) {
        parameterString.append(CameraParameters::SCENE_MODE_LANDSCAPE);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_NIGHT) {
        parameterString.append(CameraParameters::SCENE_MODE_NIGHT);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_NIGHT_PORTRAIT) {
        parameterString.append(CameraParameters::SCENE_MODE_NIGHT_PORTRAIT);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_THEATRE) {
        parameterString.append(CameraParameters::SCENE_MODE_THEATRE);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_BEACH) {
        parameterString.append(CameraParameters::SCENE_MODE_BEACH);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_SNOW) {
        parameterString.append(CameraParameters::SCENE_MODE_SNOW);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_SUNSET) {
        parameterString.append(CameraParameters::SCENE_MODE_SUNSET);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_STEADYPHOTO) {
        parameterString.append(CameraParameters::SCENE_MODE_STEADYPHOTO);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_FIREWORKS) {
        parameterString.append(CameraParameters::SCENE_MODE_FIREWORKS);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_SPORTS) {
        parameterString.append(CameraParameters::SCENE_MODE_SPORTS);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_PARTY) {
        parameterString.append(CameraParameters::SCENE_MODE_PARTY);
        parameterString.append(",");
    }
    if (sceneMode & ExynosCamera::SCENE_MODE_CANDLELIGHT)
        parameterString.append(CameraParameters::SCENE_MODE_CANDLELIGHT);

    p.set(CameraParameters::KEY_SUPPORTED_SCENE_MODES,
          parameterString.string());
    p.set(CameraParameters::KEY_SCENE_MODE,
          CameraParameters::SCENE_MODE_AUTO);

    // effect
    int effect = m_secCamera->getSupportedColorEffects();
    parameterString.setTo("");
    if (effect & ExynosCamera::EFFECT_NONE) {
        parameterString.append(CameraParameters::EFFECT_NONE);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_MONO) {
        parameterString.append(CameraParameters::EFFECT_MONO);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_NEGATIVE) {
        parameterString.append(CameraParameters::EFFECT_NEGATIVE);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_SOLARIZE) {
        parameterString.append(CameraParameters::EFFECT_SOLARIZE);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_SEPIA) {
        parameterString.append(CameraParameters::EFFECT_SEPIA);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_POSTERIZE) {
        parameterString.append(CameraParameters::EFFECT_POSTERIZE);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_WHITEBOARD) {
        parameterString.append(CameraParameters::EFFECT_WHITEBOARD);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_BLACKBOARD) {
        parameterString.append(CameraParameters::EFFECT_BLACKBOARD);
        parameterString.append(",");
    }
    if (effect & ExynosCamera::EFFECT_AQUA)
        parameterString.append(CameraParameters::EFFECT_AQUA);

    p.set(CameraParameters::KEY_SUPPORTED_EFFECTS, parameterString.string());
    p.set(CameraParameters::KEY_EFFECT, CameraParameters::EFFECT_NONE);

    // white balance
    int whiteBalance = m_secCamera->getSupportedWhiteBalance();
    parameterString.setTo("");
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_AUTO) {
        parameterString.append(CameraParameters::WHITE_BALANCE_AUTO);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_INCANDESCENT) {
        parameterString.append(CameraParameters::WHITE_BALANCE_INCANDESCENT);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_FLUORESCENT) {
        parameterString.append(CameraParameters::WHITE_BALANCE_FLUORESCENT);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_WARM_FLUORESCENT) {
        parameterString.append(CameraParameters::WHITE_BALANCE_WARM_FLUORESCENT);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_DAYLIGHT) {
        parameterString.append(CameraParameters::WHITE_BALANCE_DAYLIGHT);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_CLOUDY_DAYLIGHT) {
        parameterString.append(CameraParameters::WHITE_BALANCE_CLOUDY_DAYLIGHT);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_TWILIGHT) {
        parameterString.append(CameraParameters::WHITE_BALANCE_TWILIGHT);
        parameterString.append(",");
    }
    if (whiteBalance & ExynosCamera::WHITE_BALANCE_SHADE)
        parameterString.append(CameraParameters::WHITE_BALANCE_SHADE);

    p.set(CameraParameters::KEY_SUPPORTED_WHITE_BALANCE,
          parameterString.string());
    p.set(CameraParameters::KEY_WHITE_BALANCE, CameraParameters::WHITE_BALANCE_AUTO);

    if (m_secCamera->isAutoWhiteBalanceLockSupported() == true)
        p.set(CameraParameters::KEY_AUTO_WHITEBALANCE_LOCK_SUPPORTED, "true");
    else
        p.set(CameraParameters::KEY_AUTO_WHITEBALANCE_LOCK_SUPPORTED, "false");

    // anti banding
    parameterString.setTo("");
    int antiBanding = m_secCamera->getSupportedAntibanding();
    if (antiBanding & ExynosCamera::ANTIBANDING_AUTO) {
        parameterString.append(CameraParameters::ANTIBANDING_AUTO);
        parameterString.append(",");
    }
    if (antiBanding & ExynosCamera::ANTIBANDING_50HZ) {
        parameterString.append(CameraParameters::ANTIBANDING_50HZ);
        parameterString.append(",");
    }
    if (antiBanding & ExynosCamera::ANTIBANDING_60HZ) {
        parameterString.append(CameraParameters::ANTIBANDING_60HZ);
        parameterString.append(",");
    }
    if (antiBanding & ExynosCamera::ANTIBANDING_OFF)
        parameterString.append(CameraParameters::ANTIBANDING_OFF);

    p.set(CameraParameters::KEY_SUPPORTED_ANTIBANDING,
          parameterString.string());

    p.set(CameraParameters::KEY_ANTIBANDING, CameraParameters::ANTIBANDING_AUTO);

    // rotation
    p.set(CameraParameters::KEY_ROTATION, 0);

    // view angle
    p.setFloat(CameraParameters::KEY_HORIZONTAL_VIEW_ANGLE, m_secCamera->getHorizontalViewAngle());
    p.setFloat(CameraParameters::KEY_VERTICAL_VIEW_ANGLE, m_secCamera->getVerticalViewAngle());

    // metering
    if (0 < m_secCamera->getMaxNumMeteringAreas()) {
        p.set(CameraParameters::KEY_MAX_NUM_METERING_AREAS, m_secCamera->getMaxNumMeteringAreas());
        p.set(CameraParameters::KEY_METERING_AREAS, "(0,0,0,0,1000)");
    }

    // zoom
    if (m_secCamera->isZoomSupported() == true) {

        int maxZoom = m_secCamera->getMaxZoom();
        if (0 < maxZoom) {

            p.set(CameraParameters::KEY_ZOOM_SUPPORTED, "true");

            if (m_secCamera->isSmoothZoomSupported() == true)
                p.set(CameraParameters::KEY_SMOOTH_ZOOM_SUPPORTED, "true");
            else
                p.set(CameraParameters::KEY_SMOOTH_ZOOM_SUPPORTED, "false");

            p.set(CameraParameters::KEY_MAX_ZOOM, maxZoom - 1);
            p.set(CameraParameters::KEY_ZOOM, m_secCamera->getZoom());

            int max_zoom_ratio = m_secCamera->getMaxZoomRatio();

            listString.setTo("");

            if (m_getZoomRatioList(listString, maxZoom, 100, max_zoom_ratio) == true)
                p.set(CameraParameters::KEY_ZOOM_RATIOS, listString.string());
            else
                p.set(CameraParameters::KEY_ZOOM_RATIOS, "100");
        } else {
            p.set(CameraParameters::KEY_ZOOM_SUPPORTED, "false");
            p.set(CameraParameters::KEY_SMOOTH_ZOOM_SUPPORTED, "false");
        }

    } else {
        p.set(CameraParameters::KEY_ZOOM_SUPPORTED, "false");
        p.set(CameraParameters::KEY_SMOOTH_ZOOM_SUPPORTED, "false");
    }

    // fps
    int minFpsRange, maxFpsRange;
    m_secCamera->getSupportedPreviewFpsRange(&minFpsRange, &maxFpsRange);

    listString.setTo("");

    int minFps = (minFpsRange == 0) ? 0 : (minFpsRange / 1000);
    int maxFps = (maxFpsRange == 0) ? 0 : (maxFpsRange / 1000);

    listString.setTo("");
    snprintf(strBuf, 256, "%d", minFps);
    listString.append(strBuf);

    for (int i = minFps + 1; i <= maxFps; i++) {
        snprintf(strBuf, 256, ",%d", i);
        listString.append(strBuf);
    }
    p.set(CameraParameters::KEY_SUPPORTED_PREVIEW_FRAME_RATES,  listString.string());

    listString.setTo("");
//    m_getSupportedFpsList(listString, minFpsRange, maxFpsRange);
    getSupportedFpsList(listString, minFpsRange, maxFpsRange);
    p.set(CameraParameters::KEY_SUPPORTED_PREVIEW_FPS_RANGE, "(15000,30000),(30000,30000)");

    // limit 30 fps on default setting.
    if (30 < maxFps)
        maxFps = 30;
    p.setPreviewFrameRate(maxFps);

    if (30000 < maxFpsRange)
        maxFpsRange = 30000;
    snprintf(strBuf, 256, "%d,%d", maxFpsRange/2, maxFpsRange);
    p.set(CameraParameters::KEY_PREVIEW_FPS_RANGE, strBuf);

    // focal length
    int num = 0;
    int den = 0;
    int precision = 0;
    m_secCamera->getFocalLength(&num, &den);

    switch (den) {
    default:
    case 1000:
        precision = 3;
        break;
    case 100:
        precision = 2;
        break;
    case 10:
        precision = 1;
        break;
    case 1:
        precision = 0;
        break;
    }

    snprintf(strBuf, 256, "%.*f", precision, ((float)num / (float)den));
    p.set(CameraParameters::KEY_FOCAL_LENGTH, strBuf);
    //p.set(CameraParameters::KEY_FOCAL_LENGTH, "3.43");
    //p.set(CameraParameters::KEY_FOCAL_LENGTH, "0.9");

    // Additional params.

    p.set("contrast", "auto");
    p.set("iso", "auto");
    /* TODO: For 3rd party compatibility */
    //p.set("metering", "matrix");

    p.set("brightness", 0);
    p.set("brightness-max", 2);
    p.set("brightness-min", -2);

    p.set("saturation", 0);
    p.set("saturation-max", 2);
    p.set("saturation-min", -2);

    p.set("sharpness", 0);
    p.set("sharpness-max", 2);
    p.set("sharpness-min", -2);

    p.set("hue", 0);
    p.set("hue-max", 2);
    p.set("hue-min", -2);

    // fnumber
    m_secCamera->getFnumber(&num, &den);
    p.set("fnumber-value-numerator", num);
    p.set("fnumber-value-denominator", den);

    // max aperture value
    m_secCamera->getApertureValue(&num, &den);
    p.set("maxaperture-value-numerator", num);
    p.set("maxaperture-value-denominator", den);

    // focal length
    m_secCamera->getFocalLength(&num, &den);
    p.set("focallength-value-numerator", num);
    p.set("focallength-value-denominator", den);

    // focal length in 35mm film
    int focalLengthIn35mmFilm = 0;
    focalLengthIn35mmFilm = m_secCamera->getFocalLengthIn35mmFilm();
    p.set("focallength-35mm-value", focalLengthIn35mmFilm);

    m_params = p;

    /* make sure m_secCamera has all the settings we do.  applications
     * aren't required to call setParameters themselves (only if they
     * want to change something.
     */
    setParameters(p);
}

status_t ExynosCameraHWImpl::m_startSensor()
{
    CLOGD("DEBUG(%s):in", __func__);

    Mutex::Autolock lock(m_sensorLock);

    // HACK : move to startPreview(), because of seqeunce order.
    /*
    if (m_secCamera->startSensor() == false) {
        CLOGE("ERR(%s):Fail on m_secCamera->startSensor()", __func__);
        return UNKNOWN_ERROR;
    }
    */

    m_sensorRunning = true;
    m_sensorThread->run("CameraSensorThread", PRIORITY_DEFAULT);

    CLOGD("DEBUG(%s):out", __func__);

    return NO_ERROR;
}

void ExynosCameraHWImpl::m_stopSensor()
{
    CLOGD("DEBUG(%s):in", __func__);

    if (m_sensorRunning == true) {
        m_sensorRunning = false;

#ifdef USE_VDIS
        m_secCamera->setRecordingHint(false);
#endif
            if (0 < m_secCamera->getNumOfShotedFrame() &&
                m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
                CLOGD("DEBUG %s(%d), stop phase - %d frames are remained", __func__, __LINE__, m_secCamera->getNumOfShotedFrame());
            // break; // this should be modified... origital code has break;
            }

            if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT) {
                if (m_secCamera->setSensorStreamOff(ExynosCamera::CAMERA_MODE_FRONT) == false)
                    CLOGE("ERR(%s):Fail on m_secCamera->setSensorStreamOff(ExynosCamera::CAMERA_MODE_FRONT)", __func__);

                if (m_secCamera->stopSensorOff(ExynosCamera::CAMERA_MODE_FRONT) == false)
                    CLOGE("ERR(%s):m_secCamera->stopSensorOff(ExynosCamera::CAMERA_MODE_FRONT) fail", __func__);

                if (m_secCamera->flagStartSensor() == true) {
                    if (m_secCamera->stopSensor() == false)
                        CLOGE("ERR(%s):m_secCamera->stopSensor() fail", __func__);
                }
            }

            // stop sensor 0-reprocessing if this mode is dual or back
            if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
                if (m_secCamera->setSensorStreamOff(ExynosCamera::CAMERA_MODE_REPROCESSING) == false)
                    CLOGE("ERR(%s):Fail on m_secCamera->setSensorStreamOff(ExynosCamera::CAMERA_MODE_REPROCESSING)", __func__);

                if (m_secCamera->stopSensorOff(ExynosCamera::CAMERA_MODE_REPROCESSING) == false)
                    CLOGE("ERR(%s):Fail on m_secCamera->stopSensorOff(ExynosCamera::CAMERA_MODE_REPROCESSING)", __func__);

                if (m_secCamera->flagStartSensor() == true) {
                    if (m_secCamera->stopSensor() == false)
                        CLOGE("ERR(%s:%d):m_secCamera is not created.. Something is wrong", __func__, __LINE__);
                }

                if (m_secCamera->flagStartSensorReprocessing() == true) {
                    if (m_secCamera->stopSensorReprocessing() == false)
                        CLOGE("ERR(%s:%d):m_secCamera is not created.. Something is wrong", __func__, __LINE__);
                }
            }
    } else {
        CLOGV("DEBUG(%s):sensor not running, doing nothing", __func__);
    }

    CLOGD("DEBUG(%s):out", __func__);
}

bool ExynosCameraHWImpl::m_sensorThreadFuncWrap(void)
{
    bool ret = false;

    int cameraMode = m_secCamera->getCameraMode();

    switch (cameraMode) {
    case ExynosCamera::CAMERA_MODE_BACK:
        ret = m_sensorThreadFuncOTF();
        break;
    case ExynosCamera::CAMERA_MODE_FRONT:
        ret = m_sensorThreadFuncM2M();
        break;
    default:
        CLOGE("ERR(%s):invalid cameraMode(%d)", __func__, cameraMode);
        ret = false;
        break;
    }

#ifdef USE_CAMERA_ESD_RESET
    /* thread stop */
    if (ret == false && m_sensorESDReset == true) {
        CLOGE("ERR(%s):[esdreset]:ret == false && m_sensorESDReset == true", __func__);
        return false;
    }
#endif

    return true;
}

bool ExynosCameraHWImpl::m_sensorThreadFuncM2M(void)
{
    ExynosBuffer sensorBuf;
    ExynosBuffer ispBuf;
    struct camera2_shot_ext *shot_ext;
    bool getSenBufDone = true;

#ifdef USE_CAMERA_ESD_RESET
    if (m_sensorESDReset == true) {
        usleep(33000);
        return false;
    }
#endif

#ifdef FORCE_LEADER_OFF
    if (tryThreadStop == true) {
        tryThreadStatus = tryThreadStatus | (1 << TRY_THREAD_STATUS_SENSOR) | (1 << TRY_THREAD_STATUS_BAYER);
        usleep(10000);

        CLOGD("DEBUG(%s):(%d):tryThreadStop == true", __func__, __LINE__);
        return false;
    }
#endif

    if (m_sensorRunning == true &&
        m_secCamera->getNotifyStopMsg() == false) {

        m_sensorLock.lock();

        if (m_secCamera->getSensorBuf(&sensorBuf) == false) {
            m_sensorLock.unlock();
            if (CHECK_THREADHOLD(m_sensorErrCnt)) {
                CLOG_ASSERT("ERR(%s): getSensorBuf() fail [%d times]!!!", __func__, m_sensorErrCnt);
                return false;
            } else {
                m_sensorErrCnt++;
                CLOGE("ERR(%s):getSensorBuf() fail", __func__);
                usleep(10000);
            }
            return true;
        } else {
            m_sensorErrCnt = 0;
        }

        if (sensorBuf.reserved.p < 0) {
            CLOGV("DEBUG(%s): sensor index(%d)", __func__, sensorBuf.reserved.p);
            getSenBufDone = false;
        } else {
            m_sharedBayerBuffer = sensorBuf;
            shot_ext = (struct camera2_shot_ext *)(sensorBuf.virt.extP[1]);
            m_sharedBayerFcount = shot_ext->shot.dm.request.frameCount;
            getSenBufDone = true;
        }

        m_sensorLock.unlock();
    } else {
        if (m_secCamera->getNumOfShotedFrame() <= 0) {
            CLOGD("DEBUG(%s): getnumOfShoted frame %d", __func__, m_secCamera->getNumOfShotedFrame());
            m_sensorRunning = false;
        }
        CLOGV("DEBUG(%s): stop phase", __func__);
        getSenBufDone = false;
    }

    shot_ext = (struct camera2_shot_ext *)(sensorBuf.virt.extP[1]);

    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
        ExynosCameraHWImpl::g_is3a1Mutex.lock();

        if (m_secCamera->getIs3a1Buf(ExynosCamera::CAMERA_MODE_BACK, &sensorBuf, &ispBuf) == false) {
            CLOGE("ERR(%s):getIs3a1Buf() fail(id:%d)", __func__, getCameraId());

            ExynosCameraHWImpl::g_is3a1Mutex.unlock();
            goto done;
        }
        ExynosCameraHWImpl::g_is3a1Mutex.unlock();
    } else if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT) {
        ExynosCameraHWImpl::g_is3a0Mutex.lock();

        if (m_secCamera->getIs3a0Buf(ExynosCamera::CAMERA_MODE_FRONT, &sensorBuf, &ispBuf) == false) {
            CLOGE("ERR(%s):getIs3a0Buf() fail(id:%d)", __func__, getCameraId());

            ExynosCameraHWImpl::g_is3a0Mutex.unlock();
            goto done;
        }
        ExynosCameraHWImpl::g_is3a0Mutex.unlock();
    }

    if (ispBuf.reserved.p < 0) {
        CLOGW("WRN(%s): ispBuf.reserved.p = %d", __func__, ispBuf.reserved.p);
        goto done;
    }

    shot_ext = (struct camera2_shot_ext *)ispBuf.virt.extP[1];
    isp_last_frame_cnt = shot_ext->shot.dm.request.frameCount;

    CLOGV("(%d) (%d) (%d) (%d)", shot_ext->free_cnt, shot_ext->request_cnt, shot_ext->process_cnt, shot_ext->complete_cnt);

    m_sharedISPBuffer = ispBuf;
    if (m_secCamera->putISPBuf(&ispBuf) == false) {
        CLOGE("ERR(%s):putISPBuf() fail", __func__);
        return false;
    }

    isp_input_count++;
    m_ispCondition.signal();

done:
    if (getSenBufDone == true) {
        m_sensorLock.lock();
        if (m_secCamera->putSensorBuf(&sensorBuf) == false) {
            CLOGE("ERR(%s):putSensorBuf() fail", __func__);
            m_sensorLock.unlock();
            return false;
        }
        m_sensorLock.unlock();
    }

    usleep(10);

    return true;
}

bool ExynosCameraHWImpl::m_sensorThreadFuncOTF(void)
{
    ExynosBuffer sensorBuf;
    ExynosBuffer ispBuf;
    struct camera2_shot_ext *shot_ext;
    bool getSenBufDone = true;

    if (m_sensorRunning == false)
        return false;

#ifdef USE_CAMERA_ESD_RESET
    if (m_sensorESDReset == true) {
        usleep(33000);
        return false;
    }
#endif

#ifdef FORCE_LEADER_OFF
    if (tryThreadStop == true) {
        tryThreadStatus = tryThreadStatus | (1 << TRY_THREAD_STATUS_SENSOR);
        usleep(10000);

        CLOGD("DEBUG(%s):(%d):tryThreadStop == true", __func__, __LINE__);
        return false;
    }
#endif
    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
        ExynosCameraHWImpl::g_is3a1Mutex.lock();

        if (m_secCamera->getIs3a1Buf(ExynosCamera::CAMERA_MODE_BACK, &sensorBuf, &ispBuf) == false) {
            CLOGE("ERR(%s):getIs3a1Buf() fail(id:%d)", __func__, getCameraId());

            ExynosCameraHWImpl::g_is3a1Mutex.unlock();
            goto done;
        }
        ExynosCameraHWImpl::g_is3a1Mutex.unlock();
        if (m_sensorRunning == false)
            return false;
    } else if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT) {
        ExynosCameraHWImpl::g_is3a0Mutex.lock();

        if (m_secCamera->getIs3a0Buf(ExynosCamera::CAMERA_MODE_FRONT, &sensorBuf, &ispBuf) == false) {
            CLOGE("ERR(%s):getIs3a0Buf() fail(id:%d)", __func__, getCameraId());

            ExynosCameraHWImpl::g_is3a0Mutex.unlock();
            goto done;
        }

        ExynosCameraHWImpl::g_is3a0Mutex.unlock();
        if (m_sensorRunning == false)
            return false;
    }

    if (ispBuf.reserved.p < 0) {
        CLOGW("WRN(%s): ispBuf.reserved.p = %d", __func__, ispBuf.reserved.p);
        goto done;
    }

    shot_ext = (struct camera2_shot_ext *)ispBuf.virt.extP[1];
    isp_last_frame_cnt = shot_ext->shot.dm.request.frameCount;

    CLOGV("(%d) (%d) (%d) (%d)", shot_ext->free_cnt, shot_ext->request_cnt, shot_ext->process_cnt, shot_ext->complete_cnt);

    m_sharedISPBuffer = ispBuf;
    if (m_secCamera->putISPBuf(&ispBuf) == false) {
        CLOGE("ERR(%s):putISPBuf() fail", __func__);
        return false;
    }
    isp_input_count++;
    m_ispCondition.signal();

done:
    if (m_secCamera->getCameraMode() != ExynosCamera::CAMERA_MODE_FRONT)
        usleep(10);

    return true;
}

status_t ExynosCameraHWImpl::m_startSensorReprocessing()
{
    Mutex::Autolock lock(m_sensorLockReprocessing);

    m_sensorRunningReprocessing = true;
    m_sensorThreadReprocessing->run("CameraSensorThreadReprocessing", PRIORITY_DEFAULT);

    return NO_ERROR;
}

void ExynosCameraHWImpl::m_stopSensorReprocessing()
{
    if (m_sensorRunningReprocessing == true) {
        m_sensorRunningReprocessing = false;
        m_sensorThreadReprocessing->requestExitAndWait();
    } else
        CLOGV("DEBUG(%s):sensor not running, doing nothing", __func__);
}

bool ExynosCameraHWImpl::m_sensorThreadFuncReprocessing(void)
{
    ExynosBuffer sensorBuf;
    struct camera2_shot_ext *shot_ext;
    bool getSenBufDone = true;

#ifdef USE_CAMERA_ESD_RESET
    if (m_sensorESDReset == true) {
        usleep(33000);
        return false;
    }
#endif
#ifdef FORCE_LEADER_OFF
    if (tryThreadStop == true) {
        tryThreadStatus = tryThreadStatus | (1 << TRY_THREAD_STATUS_BAYER);
        usleep(10000);

        CLOGD("DEBUG(%s):(%d):tryThreadStop == true", __func__, __LINE__);
        return false;
    }
#endif
    if (m_sensorRunningReprocessing == true) {
        m_sensorLockReprocessing.lock();

        if (m_secCamera->getSensorBuf(&sensorBuf) == false) {
            m_sensorLockReprocessing.unlock();
            if (CHECK_THREADHOLD(m_sensorErrCnt)) {
                CLOG_ASSERT("ERR(%s): getSensorBuf() fail [%d times]!!!", __func__, m_sensorErrCnt);
                return false;
            } else {
                m_sensorErrCnt++;
                CLOGE("ERR(%s):getSensorBuf() fail", __func__);
                usleep(10000);
            }
            return true;
        } else {
            m_sensorErrCnt = 0;
        }

        if (sensorBuf.reserved.p < 0) {
            CLOGE("DEBUG(%s): sensor index(%d)", __func__, sensorBuf.reserved.p);
            getSenBufDone = false;
        } else {
            m_sharedBayerBuffer = sensorBuf;

            shot_ext = (struct camera2_shot_ext *)(sensorBuf.virt.extP[1]);
            m_sharedBayerFcount = shot_ext->shot.dm.request.frameCount;
            getSenBufDone = true;
        }

        m_sensorLockReprocessing.unlock();
    } else
        return false;

    if (getSenBufDone == true) {
        m_sensorLockReprocessing.lock();
        if (m_secCamera->putSensorBuf(&sensorBuf) == false) {
            CLOGE("ERR(%s):putSensorBuf() fail", __func__);
            m_sensorLockReprocessing.unlock();
            return true;
        }
        m_sensorLockReprocessing.unlock();
    }

    usleep(10);

    return true;
}

bool ExynosCameraHWImpl::isReprocessing(void) const
{
    int camId = getCameraId();
    bool reprocessing = false;

    if (camId == CAMERA_ID_BACK)
        reprocessing = MAIN_CAMERA_REPROCESSING;
    else
        reprocessing = FRONT_CAMERA_REPROCESSING;

    return reprocessing;
}

bool ExynosCameraHWImpl::isSccCapture(void) const
{
    int camId = getCameraId();
    bool sccCapture = false;

    if (camId == CAMERA_ID_BACK)
        sccCapture = MAIN_CAMERA_SCC_CAPTURE;
    else
        sccCapture = FRONT_CAMERA_SCC_CAPTURE;

    return sccCapture;
}

status_t ExynosCameraHWImpl::setPreviewWindowLocked(preview_stream_ops *w)
{
    CLOGD("DEBUG(%s):in", __func__);

    int ret_val;

    CLOGD("DEBUG(%s):m_startStopLock.lock()", __func__);
    m_startStopLock.lock();

    ret_val = setPreviewWindow(w);

    m_startStopLock.unlock();
    CLOGD("DEBUG(%s):m_startStopLock.unlock()", __func__);

    CLOGD("DEBUG(%s):out", __func__);

    return ret_val;
}

status_t ExynosCameraHWImpl::setPreviewWindow(preview_stream_ops *w)
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    status_t ret = NO_ERROR;
    int width, height;
    int halPreviewFmt = 0;
    bool flagRestart = false;
    buffer_manager_type bufferType = BUFFER_MANAGER_ION_TYPE;

    if (previewEnabled() == true) {
        ALOGW("WRN(%s[%d]): preview is started, we forcely re-start preview", __FUNCTION__, __LINE__);
        flagRestart = true;
        stopPreview();
    }

    m_previewWindow = w;

    if (m_scpBufferMgr != NULL) {
        ALOGD("DEBUG(%s[%d]): scp buffer manager need recreate", __FUNCTION__, __LINE__);
        m_scpBufferMgr->deinit();

        delete m_scpBufferMgr;
        m_scpBufferMgr = NULL;
    }

    if (w == NULL) {
        bufferType = BUFFER_MANAGER_ION_TYPE;
        ALOGW("WARN(%s[%d]):window NULL, create internal buffer for preview", __FUNCTION__, __LINE__);
    } else {
        halPreviewFmt = m_exynosCameraParameters->getHalPixelFormat();
        bufferType = BUFFER_MANAGER_GRALLOC_TYPE;
        m_exynosCameraParameters->getHwPreviewSize(&width, &height);

        if (m_grAllocator == NULL)
            m_grAllocator = new ExynosCameraGrallocAllocator();

        ret = m_grAllocator->init(m_previewWindow, m_exynosconfig->current->bufInfo.num_preview_buffers);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):gralloc init fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            goto func_exit;
        }

        ret = m_grAllocator->setBuffersGeometry(width, height, halPreviewFmt);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):gralloc setBufferGeomety fail, size(%dx%d), fmt(%d), ret(%d)",
                __FUNCTION__, __LINE__, width, height, halPreviewFmt, ret);
            goto func_exit;
        }
    }

    m_createBufferManager(&m_scpBufferMgr, "SCP_BUF", bufferType);

    if (bufferType == BUFFER_MANAGER_GRALLOC_TYPE)
        m_scpBufferMgr->setAllocator(m_grAllocator);

    if (flagRestart == true)
        startPreview();

func_exit:

    return ret;
}

void ExynosCameraHWImpl::setCallbacks(
        camera_notify_callback notify_cb,
        camera_data_callback data_cb,
        camera_data_timestamp_callback data_cb_timestamp,
        camera_request_memory get_memory,
        void *user)
{
    ALOGI("INFO(%s[%d]): -IN-", __FUNCTION__, __LINE__);

    int ret = 0;

    m_notifyCb        = notify_cb;
    m_dataCb          = data_cb;
    m_dataCbTimestamp = data_cb_timestamp;
    m_getMemoryCb     = get_memory;
    m_callbackCookie  = user;

    if (m_mhbAllocator == NULL)
        m_mhbAllocator = new ExynosCameraMHBAllocator();

    ret = m_mhbAllocator->init(get_memory);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]:m_mhbAllocator init failed", __FUNCTION__, __LINE__);
    }
}

void ExynosCameraHWImpl::enableMsgType(int32_t msgType)
{
    if (m_exynosCameraParameters) {
        ALOGV("INFO(%s[%d]): enable Msg (%x)", __FUNCTION__, __LINE__, msgType);
        m_exynosCameraParameters->enableMsgType(msgType);
    }
}

void ExynosCameraHWImpl::disableMsgType(int32_t msgType)
{
    if (m_exynosCameraParameters) {
        ALOGV("INFO(%s[%d]): disable Msg (%x)", __FUNCTION__, __LINE__, msgType);
        m_exynosCameraParameters->disableMsgType(msgType);
    }
}

bool ExynosCameraHWImpl::msgTypeEnabled(int32_t msgType)
{
    bool IsEnabled = false;

    if (m_exynosCameraParameters) {
        ALOGV("INFO(%s[%d]): Msg type enabled (%x)", __FUNCTION__, __LINE__, msgType);
        IsEnabled = m_exynosCameraParameters->msgTypeEnabled(msgType);
    }

    return IsEnabled;
}

status_t ExynosCameraHWImpl::startPreviewLocked()
{
    CLOGD("DEBUG(%s):in", __func__);

    int ret_val;

    CLOGD("DEBUG(%s):m_startStopLock.lock()", __func__);
    m_startStopLock.lock();

    ret_val = startPreview();

    m_startStopLock.unlock();
    CLOGD("DEBUG(%s):m_startStopLock.unlock()", __func__);

    CLOGD("DEBUG(%s):out", __func__);

    return ret_val;
}

status_t ExynosCameraHWImpl::startPreview()
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);

    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    int ret = 0;
    int32_t skipFrameCount = INITIAL_SKIP_FRAME;

    if (m_captureInProgress == true) {
        CLOGE("ERR(%s):capture in progress, not allowed", __func__);
        return INVALID_OPERATION;
    }

    struct camera2_shot_ext *initMetaData = NULL;

    m_hdrSkipedFcount = 0;
    m_isTryStopFlash= false;
    m_exitAutoFocusThread = false;
    m_curMinFps = 0;
    m_isNeedAllocPictureBuffer = false;

    if (m_previewEnabled == true) {
        return INVALID_OPERATION;
    }

    m_fdCallbackHeap = m_getMemoryCb(-1, sizeof(camera_frame_metadata_t) * NUM_OF_DETECTED_FACES, 1, m_callbackCookie);

    {
        m_exynosCameraParameters->setSeriesShotMode(SERIES_SHOT_MODE_NONE);
        if (m_exynosCameraParameters->getShotMode() == SHOT_MODE_BEAUTY_FACE)
            m_exynosCameraParameters->setPreviewBufferCount(NUM_PREVIEW_BUFFERS + NUM_PREVIEW_SPARE_BUFFERS);
        else
            m_exynosCameraParameters->setPreviewBufferCount(NUM_PREVIEW_BUFFERS);

        if ((m_exynosCameraParameters->getRestartPreview() == true) ||
            m_previewBufferCount != m_exynosCameraParameters->getPreviewBufferCount()) {
            ret = setPreviewWindow(m_previewWindow);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):setPreviewWindow fail", __FUNCTION__, __LINE__);
                return INVALID_OPERATION;
            }

            ALOGE("INFO(%s[%d]) m_resetPreview(%d)", __FUNCTION__, __LINE__, m_resetPreview);
            if (ret < 0) {
                ALOGE("(%s[%d]): restart preview internal fail", __FUNCTION__, __LINE__);
                return INVALID_OPERATION;
            }

            m_previewBufferCount = m_exynosCameraParameters->getPreviewBufferCount();
        }

        ALOGI("INFO(%s[%d]):setBuffersThread is run", __FUNCTION__, __LINE__);
        m_setBuffersThread->run("ExynosCamera", PRIORITY_DEFAULT);

        if (m_captureSelector == NULL) {
            ExynosCameraBufferManager *bufMgr = NULL;

            if (getCameraId() == CAMERA_ID_BACK)
                bufMgr = m_bayerBufferMgr;
            else
                bufMgr = m_sccBufferMgr;

            m_captureSelector = new ExynosCameraFrameSelector(m_exynosCameraParameters, bufMgr);

            if (isReprocessing() == true) {
                ret = m_captureSelector->setFrameHoldCount(REPROCESSING_BAYER_HOLD_COUNT);
                if (ret < 0)
                    ALOGE("ERR(%s[%d]): setFrameHoldCount(%d) is fail", __FUNCTION__, __LINE__, REPROCESSING_BAYER_HOLD_COUNT);
            }
        }

        if (m_sccCaptureSelector == NULL) {
            ExynosCameraBufferManager *bufMgr = NULL;

            /* TODO: Dynamic select buffer manager for capture */
            bufMgr = m_sccBufferMgr;

            m_sccCaptureSelector = new ExynosCameraFrameSelector(m_exynosCameraParameters, bufMgr);
        }

        m_captureSelector->release();
        m_sccCaptureSelector->release();

        if (m_previewFrameFactory == NULL) {
            m_previewFrameFactory = ExynosCameraFrameFactory::createFrameFactory(m_cameraId, m_exynosCameraParameters);

            ret = m_previewFrameFactory->create();
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):m_previewFrameFactory->create() failed", __FUNCTION__, __LINE__);
                goto err;
            }
            ALOGD("DEBUG(%s):FrameFactory(previewFrameFactory) created", __FUNCTION__);
        }

        if (m_exynosCameraParameters->getUseFastenAeStable() == true &&
                m_exynosCameraParameters->getCameraId() == CAMERA_ID_BACK &&
                m_exynosCameraParameters->getDualMode() == false &&
                m_exynosCameraParameters->getRecordingHint() == false &&
                m_isFirstStart == true) {

            ret = m_fastenAeStable();
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):m_fastenAeStable() failed", __FUNCTION__, __LINE__);
            } else {
                skipFrameCount = 0;
                m_exynosCameraParameters->setUseFastenAeStable(false);
            }
        }

        initMetaData = new struct camera2_shot_ext;
        if (initMetaData != NULL) {
            m_exynosCameraParameters->duplicateCtrlMetadata(initMetaData);

            ret = m_previewFrameFactory->setControl(V4L2_CID_IS_MIN_TARGET_FPS, initMetaData->shot.ctl.aa.aeTargetFpsRange[0], PIPE_FLITE);
            if (ret < 0)
                ALOGE("ERR(%s[%d]):FLITE setControl fail, ret(%d)", __FUNCTION__, __LINE__, ret);

            ret = m_previewFrameFactory->setControl(V4L2_CID_IS_MAX_TARGET_FPS, initMetaData->shot.ctl.aa.aeTargetFpsRange[1], PIPE_FLITE);
            if (ret < 0)
                ALOGE("ERR(%s[%d]):FLITE setControl fail, ret(%d)", __FUNCTION__, __LINE__, ret);

            ret = m_previewFrameFactory->setControl(V4L2_CID_IS_SCENE_MODE, initMetaData->shot.ctl.aa.sceneMode, PIPE_FLITE);
            if (ret < 0)
                ALOGE("ERR(%s[%d]):FLITE setControl fail, ret(%d)", __FUNCTION__, __LINE__, ret);

            delete initMetaData;
            initMetaData = NULL;
        } else {
            ALOGE("ERR(%s[%d]):initMetaData is NULL", __FUNCTION__, __LINE__);
        }

        m_exynosCameraParameters->setFrameSkipCount(skipFrameCount);

        m_setBuffersThread->join();

        ret = m_startPreviewInternal();
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_startPreviewInternal() failed", __FUNCTION__, __LINE__);
            goto err;
        }

        if (isReprocessing() == true) {
#ifdef START_PICTURE_THREAD
            m_startPictureInternalThread->run("ExynosCamera", PRIORITY_DEFAULT);
#endif
        } else {
            m_pictureFrameFactory = m_previewFrameFactory;
            ALOGD("DEBUG(%s[%d]):FrameFactory(pictureFrameFactory) created", __FUNCTION__, __LINE__);
        }

        if (m_previewWindow != NULL)
            m_previewWindow->set_timestamp(m_previewWindow, systemTime(SYSTEM_TIME_MONOTONIC));

        m_mainThread->run("ExynosCamera", PRIORITY_DEFAULT);
        m_monitorThread->run("ExynosCamera", PRIORITY_DEFAULT);

        if ((m_exynosCameraParameters->getHighResolutionCallbackMode() == true) &&
            (m_highResolutionCallbackRunning == false)) {
            ALOGD("DEBUG(%s[%d]):High resolution preview callback start", __FUNCTION__, __LINE__);
            if (skipFrameCount > 0)
                m_skipReprocessing = true;
            m_highResolutionCallbackRunning = true;
            m_startPictureInternalThread->run("ExynosCamera", PRIORITY_DEFAULT);

            m_startPictureInternalThread->join();
            m_prePictureThread->run("ExynosCamera", PRIORITY_DEFAULT);
        }

        /* FD-AE is always on */
#ifdef USE_FD_AE
        if ((m_exynosCameraParameters->getDualMode() == true && m_exynosCameraParameters->getCameraId() == CAMERA_ID_BACK) ||
                (m_exynosCameraParameters->getRecordingHint() == true)) {
            m_startFaceDetection(false);
        } else {
            m_startFaceDetection(true);
        }
#endif

        if (m_exynosCameraParameters->getUseFastenAeStable() == true &&
                m_exynosCameraParameters->getCameraId() == CAMERA_ID_BACK &&
                m_exynosCameraParameters->getDualMode() == false &&
                m_exynosCameraParameters->getRecordingHint() == false &&
                m_isFirstStart == true) {
            /* AF mode is setted as INFINITY in fastenAE, and we should update that mode */
            m_exynosCameraActivityControl->setAutoFocusMode(FOCUS_MODE_INFINITY);

            m_exynosCameraParameters->setUseFastenAeStable(false);
            m_exynosCameraActivityControl->setAutoFocusMode(m_exynosCameraParameters->getFocusMode());
            m_isFirstStart = false;
        }
    }

    return NO_ERROR;

err:
    m_setBuffersThread->join();

    m_releaseBuffers();

    return ret;
}

void ExynosCameraHWImpl::stopPreviewLocked()
{
    CLOGD("DEBUG(%s):in", __func__);

    CLOGD("DEBUG(%s):m_startStopLock.lock()", __func__);
    m_startStopLock.lock();

    stopPreview();

    m_startStopLock.unlock();
    CLOGD("DEBUG(%s):m_startStopLock.unlock()", __func__);

    CLOGD("DEBUG(%s):out", __func__);
}

void ExynosCameraHWImpl::stopPreview()
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);
    int ret = 0;

    ExynosCameraActivityFlash *m_flashMgr = m_exynosCameraActivityControl->getFlashMgr();
    ExynosCameraActivityAutofocus *autoFocusMgr = m_exynosCameraActivityControl->getAutoFocusMgr();

    if (m_previewEnabled == false) {
        ALOGD("DEBUG(%s[%d]): preview is not enabled", __FUNCTION__, __LINE__);
        return;
    }

    if (m_captureMode)
        this->cancelPicture();

    {
        m_previewFrameFactory->setStopFlag();
        m_exynosCameraActivityControl->cancelAutoFocus();

        m_takePictureCounter.clearCount();
        m_reprocessingCounter.clearCount();
        m_pictureCounter.clearCount();
        m_jpegCounter.clearCount();
        m_captureSelector->cancelPicture();

        ALOGD("DEBUG(%s[%d]): (%d, %d)", __FUNCTION__, __LINE__, m_flashMgr->getNeedCaptureFlash(), m_pictureEnabled);
        if (m_flashMgr->getNeedCaptureFlash() == true && m_pictureEnabled == true) {
            ALOGE("DEBUG(%s[%d]): force flash off", __FUNCTION__, __LINE__);
            m_exynosCameraActivityControl->cancelFlash();
            autoFocusMgr->stopAutofocus();
            m_isTryStopFlash = true;
            m_exitAutoFocusThread = true;

            usleep(150000);

            m_flashMgr->setFlashStep(ExynosCameraActivityFlash::FLASH_STEP_OFF);
        }

        if ((m_exynosCameraParameters->getHighResolutionCallbackMode() == true) &&
            (m_highResolutionCallbackRunning == true)) {
            m_skipReprocessing = false;
            m_highResolutionCallbackRunning = false;
            ALOGD("DEBUG(%s[%d]):High resolution preview callback stop", __FUNCTION__, __LINE__);

            m_prePictureThread->requestExitAndWait();
            m_highResolutionCallbackQ->release();
        }

        m_startPictureInternalThread->join();
        ret = m_stopPictureInternal();
        if (ret < 0)
            ALOGE("ERR(%s[%d]):m_stopPictureInternal fail", __FUNCTION__, __LINE__);

        m_exynosCameraActivityControl->stopAutoFocus();
        m_autoFocusThread->requestExitAndWait();

        m_previewThread->requestExitAndWait();

        if (m_previewQ != NULL) {
            m_previewQ->release();
        }

        if (m_previewFrontQ != NULL) {
            m_previewFrontQ->release();
        }

        m_mainThread->requestExitAndWait();
        m_monitorThread->requestExitAndWait();

        ret = m_stopPreviewInternal();
        if (ret < 0)
            ALOGE("ERR(%s[%d]):m_stopPreviewInternal fail", __FUNCTION__, __LINE__);
    }

    /* skip to free and reallocate buffers : flite / 3aa / isp / ispReprocessing */
    if (m_bayerBufferMgr != NULL) {
        m_bayerBufferMgr->resetBuffers();
    }
    if (m_3aaBufferMgr != NULL) {
        m_3aaBufferMgr->resetBuffers();
    }
    if (m_ispBufferMgr != NULL) {
        m_ispBufferMgr->resetBuffers();
    }

    /* realloc reprocessing buffer for change burst panorama <-> normal mode */
    if (m_ispReprocessingBufferMgr != NULL) {
        m_ispReprocessingBufferMgr->deinit();
    }
    if (m_sccReprocessingBufferMgr != NULL) {
        m_sccReprocessingBufferMgr->deinit();
    }

    /* realloc callback buffers */
    if (m_scpBufferMgr != NULL) {
        m_scpBufferMgr->deinit();
        m_scpBufferMgr->setBufferCount(0);
    }
    if (m_sccBufferMgr != NULL) {
        m_sccBufferMgr->deinit();
    }
    if (m_gscBufferMgr != NULL) {
        m_gscBufferMgr->deinit();
    }

    if (m_jpegBufferMgr != NULL) {
        m_jpegBufferMgr->deinit();
    }
    if (m_recordingBufferMgr != NULL) {
        m_recordingBufferMgr->deinit();
    }
    if (m_previewCallbackBufferMgr != NULL) {
        m_previewCallbackBufferMgr->deinit();
    }
    if (m_highResolutionCallbackBufferMgr != NULL) {
        m_highResolutionCallbackBufferMgr->deinit();
    }
    if (m_captureSelector != NULL) {
        m_captureSelector->release();
    }
    if (m_sccCaptureSelector != NULL) {
        m_sccCaptureSelector->release();
    }

#if 0
    /* skip to free and reallocate buffers : flite / 3aa / isp / ispReprocessing */
    ALOGE(" m_setBuffers free all buffers");
    if (m_bayerBufferMgr != NULL) {
        m_bayerBufferMgr->deinit();
    }
    if (m_3aaBufferMgr != NULL) {
        m_3aaBufferMgr->deinit();
    }
    if (m_ispBufferMgr != NULL) {
        m_ispBufferMgr->deinit();
    }
#endif
    m_reprocessingCounter.clearCount();
    m_pictureCounter.clearCount();

    m_hdrSkipedFcount = 0;
    m_dynamicSccCount = 0;

    /* HACK Reset Preview Flag*/
    m_resetPreview = false;

    m_isTryStopFlash= false;
    m_exitAutoFocusThread = false;
    m_isNeedAllocPictureBuffer = false;

    m_fdCallbackHeap->release(m_fdCallbackHeap);
}

bool ExynosCameraHWImpl::previewEnabled()
{
    ALOGI("INFO(%s[%d]):m_previewEnabled=%d",
        __FUNCTION__, __LINE__, (int)m_previewEnabled);

    Mutex::Autolock lock(m_previewLock);
    //CLOGV("DEBUG(%s):%d", __func__, m_previewRunning);
    //return m_previewRunning;

    /* in scalable mode, we should controll out state */
    if (m_exynosCameraParameters != NULL &&
        (m_exynosCameraParameters->getScalableSensorMode() == true) &&
        (m_scalableSensorMgr.getMode() == EXYNOS_CAMERA_SCALABLE_CHANGING))
        return true;
    else
        return m_previewEnabled;
}

status_t ExynosCameraHWImpl::storeMetaDataInBuffers(bool enable)
{
    if (!enable) {
        CLOGE("Non-m_frameMetadata buffer mode is not supported!");
        return INVALID_OPERATION;
    }

    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    return OK;
}

status_t ExynosCameraHWImpl::startRecording()
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    int ret = 0;
    ExynosCameraActivityAutofocus *autoFocusMgr = m_exynosCameraActivityControl->getAutoFocusMgr();

    m_recordingStateLock.lock();
    if (m_recordingEnabled == true) {
        m_recordingStateLock.unlock();
        ret = INVALID_OPERATION;
        goto func_exit;
    }
    m_recordingStateLock.unlock();

#ifdef USE_FD_AE
    m_startFaceDetection(false);
#endif


    /* Do start recording process */
    ret = m_startRecordingInternal();
    if (ret < 0) {
        ALOGE("ERR");
        return ret;
    }

    m_lastRecordingTimeStamp  = 0;
    m_recordingStartTimeStamp = 0;
    m_recordingFrameSkipCount = 0;

    m_recordingStateLock.lock();
    m_recordingEnabled = true;
    m_recordingStateLock.unlock();

    autoFocusMgr->setRecordingHint(true);

func_exit:

    return NO_ERROR;
}

void ExynosCameraHWImpl::stopRecording()
{
    CLOGD("DEBUG(%s):in", __func__);
    /**************************************************************/
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    int ret = 0;
    ExynosCameraActivityAutofocus *autoFocusMgr = m_exynosCameraActivityControl->getAutoFocusMgr();

    m_recordingStateLock.lock();
    if (m_recordingEnabled == false) {
        m_recordingStateLock.unlock();
        //return;
        CLOGV("DEBUG(%s):video not running, doing nothing", __func__);
    }
    else
    {

        m_recordingEnabled = false;
        m_recordingStateLock.unlock();
/*****************************************/
        Mutex::Autolock lock(m_videoLock);
        m_resetRecordingFrameStatus();
        CLOGD("DEBUG(%s:%d): SIGNAL(m_videoCondition) - send", __func__, __LINE__);
        m_videoCondition.signal();
        /* wait until video thread is stopped */
        CLOGD("DEBUG(%s:%d): SIGNAL(m_videoStoppedCondition) - waiting", __func__, __LINE__);
        if (m_videoStoppedCondition.waitRelative(m_videoLock, (1000 * 1000000)) == NO_ERROR)
            CLOGD("DEBUG(%s:%d): SIGNAL(m_videoStoppedCondition) - recevied", __func__, __LINE__);
        else
            CLOGD("DEBUG(%s:%d): SIGNAL(m_videoStoppedCondition) - not recevied, but release after 1 sec", __func__, __LINE__);
/*******************************************/
        /* Do stop recording process */

        ret = m_stopRecordingInternal();
        if (ret < 0)
            ALOGE("ERR(%s[%d]):m_stopRecordingInternal fail", __FUNCTION__, __LINE__);

#ifdef USE_FD_AE
        if ((m_exynosCameraParameters->getDualMode() == true) &&
            (m_exynosCameraParameters->getCameraId() == CAMERA_ID_BACK)) {
            m_startFaceDetection(false);
        } else {
            m_startFaceDetection(true);
        }
#endif

        autoFocusMgr->setRecordingHint(false);
    }
    /*******************************************************/
    if (m_recordingCallbackHeap != NULL) {
        m_recordingCallbackHeap->release(m_recordingCallbackHeap);
        m_recordingCallbackHeap = 0;
        m_recordingCallbackHeapFd = -1;
    }

    for (int i = 0; i < NUM_OF_VIDEO_BUF; i++) {
        for (int j = 0; j < 2; j++) {
            if (m_resizedVideoHeap[i][j] != NULL) {
                m_resizedVideoHeap[i][j]->release(m_resizedVideoHeap[i][j]);
                m_resizedVideoHeap[i][j] = 0;
                m_resizedVideoHeapFd[i][j] = -1;
            }
        }
    }
    CLOGD("DEBUG(%s):out", __func__);
}

bool ExynosCameraHWImpl::recordingEnabled()
{
    ALOGI("INFO(%s[%d]):m_recordingEnabled=%d",
        __FUNCTION__, __LINE__, (int)m_recordingEnabled);

    return m_recordingEnabled;
}

void ExynosCameraHWImpl::releaseRecordingFrame(const void *opaque)
{
    Mutex::Autolock lock(m_recordingFrameMutex);

    m_recordingStateLock.lock();
    if (m_recordingEnabled == false) {
        m_recordingStateLock.unlock();
        return;
    }
    m_recordingStateLock.unlock();

    if (m_recordingCallbackHeap == NULL) {
        ALOGW("WARN(%s[%d]):recordingCallbackHeap equals NULL", __FUNCTION__, __LINE__);
        return;
    }

    bool found = false;
    struct addrs *recordAddrs  = (struct addrs *)m_recordingCallbackHeap->data;
    struct addrs *releaseFrame = (struct addrs *)opaque;
/*
    if (recordAddrs) {
        for (int i = 0; i < NUM_OF_VIDEO_BUF; i++) {
            if ((char *)(&(recordAddrs[i].type)) == (char *)opaque) {
                found = true;
                break;
            }
        }
    }
*/
    if (recordAddrs != NULL) {
        for (uint32_t i = 0; i < m_exynosconfig->current->bufInfo.num_recording_buffers; i++) {
            if ((char *)(&(recordAddrs[i])) == (char *)opaque) {
                found = true;
                ALOGV("DEBUG(%s[%d]):releaseFrame->bufIndex=%d", __FUNCTION__, __LINE__, releaseFrame->bufIndex);

                if (m_doCscRecording == true)
                    m_releaseRecordingBuffer(releaseFrame->bufIndex);

                break;
            }
            m_isFirstStart = false;
        }
    }

    if (found) {
        m_availableRecordingFrameCnt++;
        CLOGV("DEBUG(%s): found index[%d] availableCount(%d)", __func__, i, m_availableRecordingFrameCnt);
        m_recordingFrameAvailable[i] = true;
    } else {
        CLOGE("ERR(%s):no matched index(%p)", __func__, (char *)opaque);
        ALOGW("WARN(%s[%d]):**** releaseFrame not founded ****", __FUNCTION__, __LINE__);
    }

}

status_t ExynosCameraHWImpl::autoFocus()
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    /* waiting previous AF is over */
    m_autoFocusLock.lock();

    m_autoFocusType = AUTO_FOCUS_SERVICE;
    m_autoFocusThread->requestExitAndWait();

//#if 0
    if (m_exynosCameraParameters->getFocusMode() == FOCUS_MODE_AUTO) {
        ALOGI("INFO(%s[%d]) ae awb lock", __FUNCTION__, __LINE__);
        m_exynosCameraParameters->m_setAutoExposureLock(true);
        m_exynosCameraParameters->m_setAutoWhiteBalanceLock(true);
    }
//#endif

    m_autoFocusThread->run("CameraAutoFocusThread", PRIORITY_DEFAULT);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::cancelAutoFocus()
{
/**************************
    CLOGD("DEBUG(%s):in", __func__);

    m_autoFocusRunning = false;

    if (m_secCamera->cancelAutoFocus() == false) {
        CLOGE("ERR(%s):Fail on m_secCamera->cancelAutoFocus()", __func__);
        return UNKNOWN_ERROR;
    }
*********************/
    /* Adonis can support the different AF area and Metering Areas */
//#if 0
    /* TODO: Currently we only able to set same area both touchAF and touchMetering */
/*    if (m_secCamera->getFocusMode() == ExynosCamera::FOCUS_MODE_TOUCH) {
        if (m_secCamera->cancelMeteringAreas() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->cancelMeteringArea()", __func__);
            return UNKNOWN_ERROR;
        } else {
            m_params.set(CameraParameters::KEY_METERING_AREAS, "(0,0,0,0,0)");
        }
    }
//#endif

    CLOGD("DEBUG(%s):out", __func__);

    return NO_ERROR;
*************************/
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    m_autoFocusRunning = false;

//#if 0
    if (m_exynosCameraParameters->getFocusMode() == FOCUS_MODE_AUTO) {
        ALOGI("INFO(%s[%d]) ae awb unlock", __FUNCTION__, __LINE__);
        m_exynosCameraParameters->m_setAutoExposureLock(false);
        m_exynosCameraParameters->m_setAutoWhiteBalanceLock(false);
    }
//#endif

    if (m_exynosCameraActivityControl->cancelAutoFocus() == false) {
        ALOGE("ERR(%s):Fail on m_secCamera->cancelAutoFocus()", __FUNCTION__);
        return UNKNOWN_ERROR;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::takePicture()
{
    int ret = 0;
    int takePictureCount = m_takePictureCounter.getCount();
    int seriesShotCount = m_exynosCameraParameters->getSeriesShotCount();
    int currentSeriesShotMode = m_exynosCameraParameters->getSeriesShotMode();
    ExynosCameraFrame *newFrame = NULL;
    int32_t reprocessingBayerMode = m_exynosCameraParameters->getReprocessingBayerMode();

    int retryCount = 0;

    if (m_captureInProgress == true) {
        CLOGW("WARN(%s):capture already in progress", __func__);
        return NO_ERROR;
    }

    m_captureInProgress = true;

//    if (m_videoRunning == false)
//        m_captureMode = true;

    /* wait autoFocus is over for turning on preFlash */
    m_autoFocusThread->join();

    /* HACK Reset Preview Flag*/
    while ((m_resetPreview == true) && (retryCount < 10)) {
        usleep(200000);
        retryCount ++;
        ALOGI("INFO(%s[%d]) retryCount(%d) m_resetPreview(%d)", __FUNCTION__, __LINE__, retryCount, m_resetPreview);
    }

    if (takePictureCount < 0) {
        ALOGE("ERR(%s[%d]): takePicture is called too much. takePictureCount(%d) / seriesShotCount(%d) . so, fail",
            __FUNCTION__, __LINE__, takePictureCount, seriesShotCount);
        return INVALID_OPERATION;
    } else if (takePictureCount == 0) {
        if (seriesShotCount == 0) {
            m_captureLock.lock();
            if (m_pictureEnabled == true) {
                ALOGE("ERR(%s[%d]): take picture is inprogressing", __FUNCTION__, __LINE__);
                /* return NO_ERROR; */
                m_captureLock.unlock();
                return INVALID_OPERATION;
            }
            m_captureLock.unlock();

            /* general shot */
            seriesShotCount = 1;
        }
        if (currentSeriesShotMode != SERIES_SHOT_MODE_LLS ||
                currentSeriesShotMode != SERIES_SHOT_MODE_SIS)
            m_takePictureCounter.setCount(seriesShotCount);
        else
            m_takePictureCounter.setCount(1);
    }

    ALOGI("INFO(%s[%d]): takePicture start m_takePictureCounter(%d), seriesShotCount(%d)",
        __FUNCTION__, __LINE__, m_takePictureCounter.getCount(), seriesShotCount);

    if(m_exynosCameraParameters->getShotMode() == SHOT_MODE_RICH_TONE) {
        m_hdrEnabled = true;
    } else {
        m_hdrEnabled = false;
    }

    /* TODO: Dynamic bayer capture, currently support only single shot */
    if (reprocessingBayerMode == REPROCESSING_BAYER_MODE_PURE_DYNAMIC) {
        int pipeId = m_getBayerPipeId();

        if (m_bayerBufferMgr->getNumOfAvailableBuffer() > 0) {
            m_previewFrameFactory->setRequestFLITE(true);
            ret = generateFrame(-1, &newFrame);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
                return ret;
            }
            m_previewFrameFactory->setRequestFLITE(false);

            ret = m_setupEntity(pipeId, newFrame);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):setupEntity fail", __FUNCTION__, __LINE__);
                return ret;
            }

            m_previewFrameFactory->pushFrameToPipe(&newFrame, pipeId);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, pipeId);
        }

        m_previewFrameFactory->startThread(pipeId);
    }

    if (m_takePictureCounter.getCount() == seriesShotCount) {
        ExynosCameraActivitySpecialCapture *m_sCaptureMgr = m_exynosCameraActivityControl->getSpecialCaptureMgr();
        ExynosCameraActivityFlash *m_flashMgr = m_exynosCameraActivityControl->getFlashMgr();

        m_stopBurstShot = false;

//#if 0
        if (isReprocessing() == false || m_exynosCameraParameters->getSeriesShotCount() > 0 ||
                m_hdrEnabled == true) {
            m_pictureFrameFactory = m_previewFrameFactory;
            if (m_exynosCameraParameters->getUseDynamicScc() == true) {
                m_previewFrameFactory->setRequestSCC(true);

                /* boosting dynamic SCC */
                if (m_hdrEnabled == false &&
                    currentSeriesShotMode == SERIES_SHOT_MODE_NONE) {
                    ret = m_boostDynamicCapture();
                    if (ret < 0)
                        ALOGW("WRN(%s[%d]): fail to boosting dynamic capture", __FUNCTION__, __LINE__);
                }

            }
        } else {
            m_pictureFrameFactory = m_reprocessingFrameFactory;

        }
//#endif

        if (m_exynosCameraParameters->getScalableSensorMode()) {
            m_exynosCameraParameters->setScalableSensorMode(false);
            stopPreview();
            setPreviewWindow(m_previewWindow);
            startPreview();
            m_exynosCameraParameters->setScalableSensorMode(true);
        }

        ALOGI("INFO(%s[%d]): takePicture enabled, takePictureCount(%d)",
                __FUNCTION__, __LINE__, m_takePictureCounter.getCount());
        m_pictureEnabled = true;
        m_takePictureCounter.decCount();
        m_isNeedAllocPictureBuffer = true;

        if (isReprocessing() == true) {
            m_startPictureInternalThread->join();
        }

        if (m_hdrEnabled == true) {
            seriesShotCount = HDR_REPROCESSING_COUNT;
            m_sCaptureMgr->setCaptureStep(ExynosCameraActivitySpecialCapture::SCAPTURE_STEP_START);
            m_sCaptureMgr->resetHdrStartFcount();
            m_exynosCameraParameters->setFrameSkipCount(13);
        } else if (m_flashMgr->getNeedCaptureFlash() == true &&
                        currentSeriesShotMode == SERIES_SHOT_MODE_NONE) {
            if (!m_flashMgr->checkPreFlash() && m_isTryStopFlash == false) {
                m_flashMgr->setCaptureStatus(true);
                ALOGD("DEBUG(%s[%d]): checkPreFlash(false), Start auto focus internally", __FUNCTION__, __LINE__);
                m_autoFocusType = AUTO_FOCUS_HAL;
                m_flashMgr->setFlashTrigerPath(ExynosCameraActivityFlash::FLASH_TRIGGER_SHORT_BUTTON);

                /* execute autoFocus for preFlash */
                m_autoFocusThread->requestExitAndWait();
                m_autoFocusThread->run("ExynosCamera", PRIORITY_DEFAULT);
            }
        }

        m_reprocessingCounter.setCount(seriesShotCount);
        if (m_prePictureThread->isRunning() == false) {
            if (m_prePictureThread->run("ExynosCamera", PRIORITY_DEFAULT) != NO_ERROR) {
                ALOGE("ERR(%s[%d]):couldn't run pre-picture thread", __FUNCTION__, __LINE__);
                return INVALID_OPERATION;
            }
        }

        m_jpegCounter.setCount(seriesShotCount);
        m_pictureCounter.setCount(seriesShotCount);
        if (m_pictureThread->isRunning() == false)
            ret = m_pictureThread->run("ExynosCamera");
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):couldn't run picture thread, ret(%d)", __FUNCTION__, __LINE__, ret);
            return INVALID_OPERATION;
        }

        /* HDR, LLS, SIS should make YUV callback data. so don't use jpeg thread */
        if (!(m_hdrEnabled == true ||
                currentSeriesShotMode == SERIES_SHOT_MODE_LLS ||
                currentSeriesShotMode == SERIES_SHOT_MODE_SIS)) {
            m_jpegCallbackThread->join();
            ret = m_jpegCallbackThread->run("ExynosCamera");
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):couldn't run jpeg callback thread, ret(%d)", __FUNCTION__, __LINE__, ret);
                return INVALID_OPERATION;
            }
        }
    } else {
        /* HDR, LLS, SIS should make YUV callback data. so don't use jpeg thread */
        if (!(m_hdrEnabled == true ||
                currentSeriesShotMode == SERIES_SHOT_MODE_LLS ||
                currentSeriesShotMode == SERIES_SHOT_MODE_SIS)) {
            /* series shot : push buffer to callback thread. */
            m_jpegCallbackThread->join();
            ret = m_jpegCallbackThread->run("ExynosCamera");
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):couldn't run jpeg callback thread, ret(%d)", __FUNCTION__, __LINE__, ret);
                return INVALID_OPERATION;
            }
        }
        ALOGI("INFO(%s[%d]): series shot takePicture, takePictureCount(%d)",
                __FUNCTION__, __LINE__, m_takePictureCounter.getCount());
        m_takePictureCounter.decCount();

        /* TODO : in case of no reprocesssing, we make zsl scheme or increse buf */
        if (isReprocessing() == false)
            m_pictureEnabled = true;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::cancelPicture()
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    if (m_pictureThread.get()) {
        CLOGV("DEBUG(%s):waiting for picture thread to exit", __func__);
        m_pictureThread->requestExitAndWait();
        CLOGV("DEBUG(%s):picture thread has exited", __func__);
    }

/*
    m_takePictureCounter.clearCount();
    m_reprocessingCounter.clearCount();
    m_pictureCounter.clearCount();
    m_jpegCounter.clearCount();
 */

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::setParametersLocked(const CameraParameters& params)
{
    CLOGD("DEBUG(%s):in", __func__);

    int ret_val;

    CLOGD("DEBUG(%s):m_startStopLock.lock()", __func__);
    m_startStopLock.lock();

    ret_val = setParameters(params);

    m_startStopLock.unlock();
    CLOGD("DEBUG(%s):m_startStopLock.unlock()", __func__);

    CLOGD("DEBUG(%s):out", __func__);

    return ret_val;
}

status_t ExynosCameraHWImpl::setParameters(const CameraParameters& params)
{
    status_t ret = NO_ERROR;
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

#ifdef SCALABLE_ON
    m_exynosCameraParameters->setScalableSensorMode(true);
#else
    m_exynosCameraParameters->setScalableSensorMode(false);
#endif

    ret = m_exynosCameraParameters->setParameters(params);
#if 1
    /* HACK Reset Preview Flag*/
    if (m_exynosCameraParameters->getRestartPreview() == true && m_previewEnabled == true) {
        m_resetPreview = true;
        ret = m_restartPreviewInternal();
        m_resetPreview = false;
        ALOGI("INFO(%s[%d]) m_resetPreview(%d)", __FUNCTION__, __LINE__, m_resetPreview);

        if (ret < 0)
            ALOGE("(%s[%d]): restart preview internal fail", __FUNCTION__, __LINE__);
    }
#endif
    return ret;

}

CameraParameters ExynosCameraHWImpl::getParameters() const
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    return m_exynosCameraParameters->getParameters();
}

int ExynosCameraHWImpl::getMaxNumDetectedFaces(void)
{
    return m_exynosCameraParameters->getMaxNumDetectedFaces();
}

bool ExynosCameraHWImpl::m_startFaceDetection(bool toggle)
{
    ALOGD("DEBUG(%s[%d]) toggle : %d", __FUNCTION__, __LINE__, toggle);

    if (toggle == true) {
        m_exynosCameraParameters->setFdEnable(true);
        m_exynosCameraParameters->setFdMode(FACEDETECT_MODE_FULL);
    } else {
        m_exynosCameraParameters->setFdEnable(false);
        m_exynosCameraParameters->setFdMode(FACEDETECT_MODE_OFF);
    }

    memset(&m_frameMetadata, 0, sizeof(camera_frame_metadata_t));

    return true;
}

bool ExynosCameraHWImpl::startFaceDetection(void)
{
    if (m_flagStartFaceDetection == true) {
        ALOGD("DEBUG(%s):Face detection already started..", __FUNCTION__);
        return true;
    }

    /* FD-AE is always on */
#ifdef USE_FD_AE
#else
    m_startFaceDetection(true);
#endif
    ExynosCameraActivityAutofocus *autoFocusMgr = m_exynosCameraActivityControl->getAutoFocusMgr();

    if (autoFocusMgr->setFaceDetection(true) == false) {
        ALOGE("ERR(%s[%d]):setFaceDetection(%d)", __FUNCTION__, __LINE__, true);
    } else {
        /* restart CAF when FD mode changed */
        switch (autoFocusMgr->getAutofocusMode()) {
        case ExynosCameraActivityAutofocus::AUTOFOCUS_MODE_CONTINUOUS_PICTURE:
        case ExynosCameraActivityAutofocus::AUTOFOCUS_MODE_CONTINUOUS_PICTURE_MACRO:
            if (autoFocusMgr->flagAutofocusStart() == true &&
                autoFocusMgr->flagLockAutofocus() == false) {
                autoFocusMgr->stopAutofocus();
                autoFocusMgr->startAutofocus();
            }
            break;
        default:
            break;
        }
    }

    m_flagStartFaceDetection = true;

    return true;
}

bool ExynosCameraHWImpl::stopFaceDetection(void)
{
    if (m_flagStartFaceDetection == false) {
        ALOGD("DEBUG(%s [%d]):Face detection already stopped..", __FUNCTION__, __LINE__);
        return true;
    }

    ExynosCameraActivityAutofocus *autoFocusMgr = m_exynosCameraActivityControl->getAutoFocusMgr();

    if (autoFocusMgr->setFaceDetection(false) == false) {
        ALOGE("ERR(%s[%d]):setFaceDetection(%d)", __FUNCTION__, __LINE__, false);
    } else {
        /* restart CAF when FD mode changed */
        switch (autoFocusMgr->getAutofocusMode()) {
        case ExynosCameraActivityAutofocus::AUTOFOCUS_MODE_CONTINUOUS_PICTURE:
        case ExynosCameraActivityAutofocus::AUTOFOCUS_MODE_CONTINUOUS_PICTURE_MACRO:
            if (autoFocusMgr->flagAutofocusStart() == true &&
                autoFocusMgr->flagLockAutofocus() == false) {
                autoFocusMgr->stopAutofocus();
                autoFocusMgr->startAutofocus();
            }
            break;
        default:
            break;
        }
    }

    /* FD-AE is always on */
#ifdef USE_FD_AE
#else
    m_startFaceDetection(false);
#endif
    m_flagStartFaceDetection = false;

    return true;
}
/*
bool ExynosCameraHWImpl::m_getSupportedVariableFpsList(int min, int max, int *newMin, int *newMax)
{
    bool ret = fals
    ret = m_exynosCameraParameters->
    return ret;
}
*/
int ExynosCameraHWImpl::m_getAlignedYUVSize(int colorFormat, int w, int h, ExynosBuffer *buf, bool flagAndroidColorFormat)
{
    getSupportedFpsList();
    int FrameSize = 0;

    CLOGV("[%s] (%d) colorFormat %d", __func__, __LINE__, colorFormat);
    switch (colorFormat) {
    // 1p
    case V4L2_PIX_FMT_RGB565 :
    case V4L2_PIX_FMT_YUYV :
    case V4L2_PIX_FMT_UYVY :
    case V4L2_PIX_FMT_VYUY :
    case V4L2_PIX_FMT_YVYU :
        buf->size.extS[0] = FRAME_SIZE(V4L2_PIX_2_HAL_PIXEL_FORMAT(colorFormat), w, h);
        CLOGV("V4L2_PIX_FMT_YUYV buf->size.extS[0] %d", buf->size.extS[0]);
        buf->size.extS[1] = 0;
        buf->size.extS[2] = 0;
        break;
    // 2p
    case V4L2_PIX_FMT_NV12 :
    case V4L2_PIX_FMT_NV12T :
    case V4L2_PIX_FMT_NV21 :
    case V4L2_PIX_FMT_NV12M :
    case V4L2_PIX_FMT_NV21M :
        if (flagAndroidColorFormat == true) {
            buf->size.extS[0] = w * h;
            buf->size.extS[1] = w * h / 2;
            buf->size.extS[2] = 0;
        } else {
            buf->size.extS[0] = ALIGN_UP(w, 16) * ALIGN_UP(h, 16);
            buf->size.extS[1] = ALIGN_UP(w, 16) * ALIGN_UP(h, 16) / 2;
            buf->size.extS[2] = 0;
        }
        CLOGV("V4L2_PIX_FMT_NV21 buf->size.extS[0] %d buf->size.extS[1] %d", buf->size.extS[0], buf->size.extS[1]);
        break;
    case V4L2_PIX_FMT_NV12MT_16X16 :
        if (flagAndroidColorFormat == true) {
            buf->size.extS[0] = w * h;
            buf->size.extS[1] = w * h / 2;
            buf->size.extS[2] = 0;
        } else {
            buf->size.extS[0] = ALIGN_UP(w, 16) * ALIGN_UP(h, 16);
            buf->size.extS[1] = ALIGN(buf->size.extS[0] / 2, 256);
            buf->size.extS[2] = 0;
        }
        CLOGV("V4L2_PIX_FMT_NV12M buf->size.extS[0] %d buf->size.extS[1] %d", buf->size.extS[0], buf->size.extS[1]);
        break;
    case V4L2_PIX_FMT_NV16 :
    case V4L2_PIX_FMT_NV61 :
        buf->size.extS[0] = ALIGN_UP(w, 16) * ALIGN_UP(h, 16);
        buf->size.extS[1] = ALIGN_UP(w, 16) * ALIGN_UP(h, 16);
        buf->size.extS[2] = 0;
        CLOGV("V4L2_PIX_FMT_NV16 buf->size.extS[0] %d buf->size.extS[1] %d", buf->size.extS[0], buf->size.extS[1]);
        break;
     // 3p
    case V4L2_PIX_FMT_YUV420 :
    case V4L2_PIX_FMT_YVU420 :
        /* http://developer.android.com/reference/android/graphics/ImageFormat.html#YV12 */
        if (flagAndroidColorFormat == true) {
            buf->size.extS[0] = ALIGN_UP(w, 16) * h;
            buf->size.extS[1] = ALIGN_UP(w / 2, 16) * h / 2;
            buf->size.extS[2] = ALIGN_UP(w / 2, 16) * h / 2;
        } else {
            buf->size.extS[0] = (w * h);
            buf->size.extS[1] = (w * h) >> 2;
            buf->size.extS[2] = (w * h) >> 2;
        }
        CLOGV("V4L2_PIX_FMT_YUV420 buf->size.extS[0] %d buf->size.extS[1] %d buf->size.extS[2] %d", buf->size.extS[0], buf->size.extS[1], buf->size.extS[2]);
        break;
    case V4L2_PIX_FMT_YUV420M :
    case V4L2_PIX_FMT_YVU420M :
        if (flagAndroidColorFormat == true) {
            buf->size.extS[0] = ALIGN_UP(w, 16) * h;
            buf->size.extS[1] = ALIGN_UP(w / 2, 16) * h / 2;
            buf->size.extS[2] = ALIGN_UP(w / 2, 16) * h / 2;
        } else {
            buf->size.extS[0] = ALIGN_UP(w,   32) * ALIGN_UP(h,  16);
            buf->size.extS[1] = ALIGN_UP(w/2, 16) * ALIGN_UP(h/2, 8);
            buf->size.extS[2] = ALIGN_UP(w/2, 16) * ALIGN_UP(h/2, 8);
        }
        CLOGV("V4L2_PIX_FMT_YUV420M buf->size.extS[0] %d buf->size.extS[1] %d buf->size.extS[2] %d", buf->size.extS[0], buf->size.extS[1], buf->size.extS[2]);
        break;
    case V4L2_PIX_FMT_YUV422P :
        buf->size.extS[0] = ALIGN_UP(w,   16) * ALIGN_UP(h,  16);
        buf->size.extS[1] = ALIGN_UP(w/2, 16) * ALIGN_UP(h/2, 8);
        buf->size.extS[2] = ALIGN_UP(w/2, 16) * ALIGN_UP(h/2, 8);
        CLOGV("V4L2_PIX_FMT_YUV422P buf->size.extS[0] %d buf->size.extS[1] %d buf->size.extS[2] %d", buf->size.extS[0], buf->size.extS[1], buf->size.extS[2]);
        break;
    default:
        CLOGE("ERR(%s):unmatched colorFormat(%d)", __func__, colorFormat);
        return 0;
        break;
    }

    if (buf->virt.extP[0]) {
        for (int i = 1; i < ExynosBuffer::BUFFER_PLANE_NUM_DEFAULT; i++) {
            if (buf->size.extS[i] != 0)
                buf->virt.extP[i] = buf->virt.extP[i - 1] + buf->size.extS[i - 1];
            else
                buf->virt.extP[i] = NULL;
        }
    }

    for (int i = 0; i < ExynosBuffer::BUFFER_PLANE_NUM_DEFAULT; i++)
        FrameSize += buf->size.extS[i];

    return FrameSize;
}
/*
bool ExynosCameraHWImpl::m_getSupportedFpsList(String8 & string8Buf, int min, int max)
{
    bool ret = false;
    bool flagFirst = true;
    char strBuf[32];
    int numOfList = 0;

    numOfList = sizeof(FPS_RANGE_LIST) / (sizeof(int) * 2);

    for (int i = 0; i < numOfList; i++) {
        if (min <= FPS_RANGE_LIST[i][0] &&
            FPS_RANGE_LIST[i][1] <= max) {
            if (flagFirst == true) {
                flagFirst = false;
                snprintf(strBuf, sizeof(strBuf), "(%d,%d)", FPS_RANGE_LIST[i][0], FPS_RANGE_LIST[i][1]);
            } else {
                snprintf(strBuf, sizeof(strBuf), ",(%d,%d)", FPS_RANGE_LIST[i][0], FPS_RANGE_LIST[i][1]);
            }
            string8Buf.append(strBuf);

            ret = true;
        }
    }

    if (ret == false)
        CLOGE("ERR(%s):cannot find fps list", __func__);

    return ret;
}
*/
bool ExynosCameraHWImpl::m_getResolutionList(String8 & string8Buf, int *w, int *h, int mode)
{
    bool ret = false;
    bool flagFirst = true;
    char strBuf[32];
    int sizeOfResSize = 0;
    int cropX = 0, cropY = 0, cropW = 0, cropH = 0;
    int max_w = 0, max_h = 0;

    // this is up to /packages/apps/Camera/res/values/arrays.xml
    int (*RESOLUTION_LIST)[2] = {NULL,};

    switch (mode) {
    case MODE_PREVIEW:
        RESOLUTION_LIST = PREVIEW_LIST;
        sizeOfResSize = sizeof(PREVIEW_LIST) / (sizeof(int) * 2);
        break;
    case MODE_PICTURE:
        RESOLUTION_LIST = PICTURE_LIST;
        sizeOfResSize = sizeof(PICTURE_LIST) / (sizeof(int) * 2);
        break;
    case MODE_VIDEO:
        RESOLUTION_LIST = VIDEO_LIST;
        sizeOfResSize = sizeof(VIDEO_LIST) / (sizeof(int) * 2);
        break;
    default:
        CLOGE("ERR(%s):invalid mode(%d)", __func__, mode);
        return false;
        break;
    }

    for (int i = 0; i < sizeOfResSize; i++) {
        if (   RESOLUTION_LIST[i][0] <= *w
            && RESOLUTION_LIST[i][1] <= *h) {
            if (flagFirst == true) {
                snprintf(strBuf, sizeof(strBuf), "%dx%d", RESOLUTION_LIST[i][0], RESOLUTION_LIST[i][1]);
                string8Buf.append(strBuf);
                max_w = RESOLUTION_LIST[i][0];
                max_h = RESOLUTION_LIST[i][1];

                flagFirst = false;
            } else {
                snprintf(strBuf, sizeof(strBuf), ",%dx%d", RESOLUTION_LIST[i][0], RESOLUTION_LIST[i][1]);
                string8Buf.append(strBuf);
            }

            ret = true;
        }
    }

    if (ret == false)
        CLOGE("ERR(%s):cannot find resolutions", __func__);

    *w = max_w;
    *h = max_h;

    return ret;
}

bool ExynosCameraHWImpl::m_getZoomRatioList(String8 & string8Buf, int maxZoom, int start, int end)
{
    bool flagFirst = true;
    char strBuf[32];

    int cur = start;
    int step = (end - start) / (maxZoom - 1);

    for (int i = 0; i < (maxZoom - 1); i++) {
        snprintf(strBuf, sizeof(strBuf), "%d", cur);
        string8Buf.append(strBuf);
        string8Buf.append(",");
        cur += step;
    }

    snprintf(strBuf, sizeof(strBuf), "%d", end);
    string8Buf.append(strBuf);

    // ex : "100,130,160,190,220,250,280,310,340,360,400"

    return true;
}

bool ExynosCameraHWImpl::m_getMatchedPictureSize(const int src_w, const int src_h, int *dst_w, int *dst_h)
{
    int sizeOfResSize = 0;
    float src_ratio = (float)src_w / (float)src_h;
    float dst_ratio = 0;
    int maxW, maxH;

    m_secCamera->getSupportedPictureSizes(&maxW, &maxH);
    sizeOfResSize = sizeof(PICTURE_LIST) / (sizeof(int) * 2);

    for (int i = 0; i < sizeOfResSize; i++) {
        if (PICTURE_LIST[i][0] > maxW || PICTURE_LIST[i][1] > maxH)
            continue;

        dst_ratio = (float)PICTURE_LIST[i][0] / (float)PICTURE_LIST[i][1];
        if (src_ratio == dst_ratio) {
            *dst_w = PICTURE_LIST[i][0];
            *dst_h = PICTURE_LIST[i][1];
            return true;
        }
    }

    CLOGE("ERR(%s):Could not find matched ratio size(%dx%d)", __func__, src_w, src_h);

    return false;
}

int ExynosCameraHWImpl::m_bracketsStr2Ints(char *str, int num, ExynosRect2 *rect2s, int *weights, int mode)
{
    char *curStr = str;
    char buf[128];
    char *bracketsOpen;
    char *bracketsClose;

    int tempArray[5];
    int validFocusedAreas = 0;
    bool isValid;
    bool nullArea = false;
    isValid = true;

    for (int i = 0; i < num + 1; i++) {
        if (curStr == NULL) {
            if (i != num) {
                nullArea = false;
            }
            break;
        }

        bracketsOpen = strchr(curStr, '(');
        if (bracketsOpen == NULL) {
            if (i != num) {
                nullArea = false;
            }
            break;
        }

        bracketsClose = strchr(bracketsOpen, ')');
        if (bracketsClose == NULL) {
            CLOGE("ERR(%s):m_subBracketsStr2Ints(%s) fail", __func__, buf);
            if (i != num) {
                nullArea = false;
            }
            break;
        } else if (i == num) {
            return 0;
        }

        strncpy(buf, bracketsOpen, bracketsClose - bracketsOpen + 1);
        buf[bracketsClose - bracketsOpen + 1] = 0;

        if (m_subBracketsStr2Ints(5, buf, tempArray) == false) {
            nullArea = false;
            break;
        }

        rect2s[i].x1 = tempArray[0];
        rect2s[i].y1 = tempArray[1];
        rect2s[i].x2 = tempArray[2];
        rect2s[i].y2 = tempArray[3];
        weights[i] = tempArray[4];

        if (mode) {
            isValid = true;

            for (int j = 0; j < 4; j++) {
                if (tempArray[j] < -1000 || tempArray[j] > 1000)
                    isValid = false;
            }

            if (tempArray[4] < 0 || tempArray[4] > 1000)
                isValid = false;

            if (!rect2s[i].x1 && !rect2s[i].y1 && !rect2s[i].x2 && !rect2s[i].y2 && !weights[i])
                nullArea = true;
            else if (weights[i] == 0)
                isValid = false;
            else if (!(tempArray[0] == 0 && tempArray[2] == 0) && tempArray[0] >= tempArray[2])
                isValid = false;
            else if (!(tempArray[1] == 0 && tempArray[3] == 0) && tempArray[1] >= tempArray[3])
                isValid = false;
            else if (!(tempArray[0] == 0 && tempArray[2] == 0) && (tempArray[1] == 0 && tempArray[3] == 0))
                isValid = false;
            else if ((tempArray[0] == 0 && tempArray[2] == 0) && !(tempArray[1] == 0 && tempArray[3] == 0))
                isValid = false;

            if (isValid)
                validFocusedAreas++;
            else
                return 0;
        } else {
            if (rect2s[i].x1 || rect2s[i].y1 || rect2s[i].x2 || rect2s[i].y2 || weights[i])
                validFocusedAreas++;
        }

        curStr = bracketsClose;
    }
    if (nullArea && mode)
        validFocusedAreas = num;

    if (validFocusedAreas == 0)
        validFocusedAreas = 1;

    return validFocusedAreas;
}

bool ExynosCameraHWImpl::m_subBracketsStr2Ints(int num, char *str, int *arr)
{
    if (str == NULL || arr == NULL) {
        CLOGE("ERR(%s):str or arr is NULL", __func__);
        return false;
    }

    // ex : (-10,-10,0,0,300)
    char buf[128];
    char *bracketsOpen;
    char *bracketsClose;
    char *tok;

    bracketsOpen = strchr(str, '(');
    if (bracketsOpen == NULL) {
        CLOGE("ERR(%s):no '('", __func__);
        return false;
    }

    bracketsClose = strchr(bracketsOpen, ')');
    if (bracketsClose == NULL) {
        CLOGE("ERR(%s):no ')'", __func__);
        return false;
    }

    strncpy(buf, bracketsOpen + 1, bracketsClose - bracketsOpen + 1);
    buf[bracketsClose - bracketsOpen + 1] = 0;

    tok = strtok(buf, ",");
    if (tok == NULL) {
        CLOGE("ERR(%s):strtok(%s) fail", __func__, buf);
        return false;
    }

    arr[0] = atoi(tok);

    for (int i = 1; i < num; i++) {
        tok = strtok(NULL, ",");
        if (tok == NULL) {
            if (i < num - 1) {
                CLOGE("ERR(%s):strtok() (index : %d, num : %d) fail", __func__, i, num);
                return false;
            }
            break;
        }

        arr[i] = atoi(tok);
    }

    return true;
}

int ExynosCameraHWImpl::m_calibratePosition(int w, int new_w, int pos)
{
    return (float)(pos * new_w) / (float)w;
}

status_t ExynosCameraHWImpl::m_doFdCallbackFunc(ExynosCameraFrame *frame)
{
    struct camera2_shot_ext *meta_shot_ext = new struct camera2_shot_ext;
    memset(meta_shot_ext, 0x00, sizeof(struct camera2_shot_ext));
    frame->getDynamicMeta(meta_shot_ext);

    if (m_flagStartFaceDetection == true) {
        int id[NUM_OF_DETECTED_FACES];
        int score[NUM_OF_DETECTED_FACES];
        ExynosRect2 detectedFace[NUM_OF_DETECTED_FACES];
        ExynosRect2 detectedLeftEye[NUM_OF_DETECTED_FACES];
        ExynosRect2 detectedRightEye[NUM_OF_DETECTED_FACES];
        ExynosRect2 detectedMouth[NUM_OF_DETECTED_FACES];
        int numOfDetectedFaces = 0;
        int num = 0;
        struct camera2_dm *dm = NULL;
        int previewW, previewH;

        memset(&id, 0x00, sizeof(int) * NUM_OF_DETECTED_FACES);
        memset(&score, 0x00, sizeof(int) * NUM_OF_DETECTED_FACES);

        m_exynosCameraParameters->getHwPreviewSize(&previewW, &previewH);

        dm = &(meta_shot_ext->shot.dm);
        if (dm == NULL) {
            ALOGE("ERR(%s[%d]) dm data is null", __FUNCTION__, __LINE__);
            delete meta_shot_ext;
            meta_shot_ext = NULL;
            return INVALID_OPERATION;
        }

        ALOGV("DEBUG(%s[%d]) faceDetectMode(%d)", __FUNCTION__, __LINE__, dm->stats.faceDetectMode);
        ALOGV("[%d %d]", dm->stats.faceRectangles[0][0], dm->stats.faceRectangles[0][1]);
        ALOGV("[%d %d]", dm->stats.faceRectangles[0][2], dm->stats.faceRectangles[0][3]);

       num = NUM_OF_DETECTED_FACES;
        if (getMaxNumDetectedFaces() < num)
            num = getMaxNumDetectedFaces();

        switch (dm->stats.faceDetectMode) {
        case FACEDETECT_MODE_SIMPLE:
        case FACEDETECT_MODE_FULL:
            break;
        case FACEDETECT_MODE_OFF:
        default:
            num = 0;
            break;
        }

        for (int i = 0; i < num; i++) {
            if (dm->stats.faceIds[i]) {
                switch (dm->stats.faceDetectMode) {
                case FACEDETECT_MODE_OFF:
                    break;
                case FACEDETECT_MODE_SIMPLE:
                    detectedFace[i].x1 = dm->stats.faceRectangles[i][0];
                    detectedFace[i].y1 = dm->stats.faceRectangles[i][1];
                    detectedFace[i].x2 = dm->stats.faceRectangles[i][2];
                    detectedFace[i].y2 = dm->stats.faceRectangles[i][3];
                    numOfDetectedFaces++;
                    break;
                case FACEDETECT_MODE_FULL:
                    id[i] = dm->stats.faceIds[i];
                    score[i] = dm->stats.faceScores[i];

                    detectedFace[i].x1 = dm->stats.faceRectangles[i][0];
                    detectedFace[i].y1 = dm->stats.faceRectangles[i][1];
                    detectedFace[i].x2 = dm->stats.faceRectangles[i][2];
                    detectedFace[i].y2 = dm->stats.faceRectangles[i][3];

                    detectedLeftEye[i].x1
                        = detectedLeftEye[i].y1
                        = detectedLeftEye[i].x2
                        = detectedLeftEye[i].y2 = -1;

                    detectedRightEye[i].x1
                        = detectedRightEye[i].y1
                        = detectedRightEye[i].x2
                        = detectedRightEye[i].y2 = -1;

                    detectedMouth[i].x1
                        = detectedMouth[i].y1
                        = detectedMouth[i].x2
                        = detectedMouth[i].y2 = -1;

                    numOfDetectedFaces++;
                    break;
                default:
                    break;
                }
            }
        }

        if (0 < numOfDetectedFaces) {
            /*
             * camera.h
             * width   : -1000~1000
             * height  : -1000~1000
             * if eye, mouth is not detectable : -2000, -2000.
             */
            memset(m_faces, 0, sizeof(camera_face_t) * NUM_OF_DETECTED_FACES);

            int realNumOfDetectedFaces = 0;

            for (int i = 0; i < numOfDetectedFaces; i++) {
                /*
                 * over 50s, we will catch
                 * if (score[i] < 50)
                 *    continue;
                */
                m_faces[realNumOfDetectedFaces].rect[0] = m_calibratePosition(previewW, 2000, detectedFace[i].x1) - 1000;
                m_faces[realNumOfDetectedFaces].rect[1] = m_calibratePosition(previewH, 2000, detectedFace[i].y1) - 1000;
                m_faces[realNumOfDetectedFaces].rect[2] = m_calibratePosition(previewW, 2000, detectedFace[i].x2) - 1000;
                m_faces[realNumOfDetectedFaces].rect[3] = m_calibratePosition(previewH, 2000, detectedFace[i].y2) - 1000;

                m_faces[realNumOfDetectedFaces].id = id[i];
                m_faces[realNumOfDetectedFaces].score = score[i] > 100 ? 100 : score[i];

                m_faces[realNumOfDetectedFaces].left_eye[0] = (detectedLeftEye[i].x1 < 0) ? -2000 : m_calibratePosition(previewW, 2000, detectedLeftEye[i].x1) - 1000;
                m_faces[realNumOfDetectedFaces].left_eye[1] = (detectedLeftEye[i].y1 < 0) ? -2000 : m_calibratePosition(previewH, 2000, detectedLeftEye[i].y1) - 1000;

                m_faces[realNumOfDetectedFaces].right_eye[0] = (detectedRightEye[i].x1 < 0) ? -2000 : m_calibratePosition(previewW, 2000, detectedRightEye[i].x1) - 1000;
                m_faces[realNumOfDetectedFaces].right_eye[1] = (detectedRightEye[i].y1 < 0) ? -2000 : m_calibratePosition(previewH, 2000, detectedRightEye[i].y1) - 1000;

                m_faces[realNumOfDetectedFaces].mouth[0] = (detectedMouth[i].x1 < 0) ? -2000 : m_calibratePosition(previewW, 2000, detectedMouth[i].x1) - 1000;
                m_faces[realNumOfDetectedFaces].mouth[1] = (detectedMouth[i].y1 < 0) ? -2000 : m_calibratePosition(previewH, 2000, detectedMouth[i].y1) - 1000;

                ALOGV("face posision(cal:%d,%d %dx%d)(org:%d,%d %dx%d), id(%d), score(%d)",
                    m_faces[realNumOfDetectedFaces].rect[0], m_faces[realNumOfDetectedFaces].rect[1],
                    m_faces[realNumOfDetectedFaces].rect[2], m_faces[realNumOfDetectedFaces].rect[3],
                    detectedFace[i].x1, detectedFace[i].y1,
                    detectedFace[i].x2, detectedFace[i].y2,
                    m_faces[realNumOfDetectedFaces].id,
                    m_faces[realNumOfDetectedFaces].score);

                ALOGV("DEBUG(%s[%d]): left eye(%d,%d), right eye(%d,%d), mouth(%dx%d), num of facese(%d)",
                        __FUNCTION__, __LINE__,
                        m_faces[realNumOfDetectedFaces].left_eye[0],
                        m_faces[realNumOfDetectedFaces].left_eye[1],
                        m_faces[realNumOfDetectedFaces].right_eye[0],
                        m_faces[realNumOfDetectedFaces].right_eye[1],
                        m_faces[realNumOfDetectedFaces].mouth[0],
                        m_faces[realNumOfDetectedFaces].mouth[1],
                        realNumOfDetectedFaces
                     );

                realNumOfDetectedFaces++;
            }

            m_frameMetadata.number_of_faces = realNumOfDetectedFaces;
            m_frameMetadata.faces = m_faces;

            m_faceDetected = true;
        } else {
            if (m_faceDetected == true && m_fdThreshold < NUM_OF_DETECTED_FACES_THRESHOLD) {
                /* waiting the unexpected fail about face detected */
                m_fdThreshold++;
            } else {
                if (0 < m_frameMetadata.number_of_faces)
                    memset(m_faces, 0, sizeof(camera_face_t) * NUM_OF_DETECTED_FACES);

                m_frameMetadata.number_of_faces = 0;
                m_frameMetadata.faces = m_faces;
                m_fdThreshold = 0;
                m_faceDetected = false;
            }
        }
    } else {
        if (0 < m_frameMetadata.number_of_faces)
            memset(m_faces, 0, sizeof(camera_face_t) * NUM_OF_DETECTED_FACES);

        m_frameMetadata.number_of_faces = 0;
        m_frameMetadata.faces = m_faces;

        m_fdThreshold = 0;

        m_faceDetected = false;
    }

    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_PREVIEW_METADATA)) {
        int bufIndex = -2;
        int hwPreviewW = 0, hwPreviewH = 0;
        int hwPreviewFormat = m_exynosCameraParameters->getHwPreviewFormat();

        setBit(&m_callbackState, CALLBACK_STATE_PREVIEW_META, false);
        m_dataCb(CAMERA_MSG_PREVIEW_METADATA, m_fdCallbackHeap, 0, &m_frameMetadata, m_callbackCookie);
        clearBit(&m_callbackState, CALLBACK_STATE_PREVIEW_META, false);
    }

    if (meta_shot_ext != NULL) {
        delete meta_shot_ext;
        meta_shot_ext = NULL;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::sendCommand(int32_t command, int32_t arg1, int32_t arg2)
{
    ExynosCameraActivityUCTL *uctlMgr = NULL;

    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);

    /* TO DO : implemented based on the command */
    switch(command) {
    case CAMERA_CMD_START_FACE_DETECTION:
    case CAMERA_CMD_STOP_FACE_DETECTION:
        if (getMaxNumDetectedFaces() == 0) {
            ALOGE("ERR(%s):getMaxNumDetectedFaces == 0", __FUNCTION__);
            return BAD_VALUE;
        }

        if (arg1 == CAMERA_FACE_DETECTION_SW) {
            ALOGE("ERR(%s):only support HW face dectection", __FUNCTION__);
            return BAD_VALUE;
        }

        if (command == CAMERA_CMD_START_FACE_DETECTION) {
            ALOGD("sendCommand: CAMERA_CMD_START_FACE_DETECTION is called!");
            if (m_flagStartFaceDetection == false
                && startFaceDetection() == false) {
                ALOGE("ERR(%s):startFaceDetection() fail", __FUNCTION__);
                return BAD_VALUE;
            }
        } else {
            ALOGD("sendCommand: CAMERA_CMD_STOP_FACE_DETECTION is called!");
            if ( m_flagStartFaceDetection == true
                && stopFaceDetection() == false) {
                ALOGE("ERR(%s):stopFaceDetection() fail", __FUNCTION__);
                return BAD_VALUE;
            }
        }
        break;
    case 1351: /*CAMERA_CMD_AUTO_LOW_LIGHT_SET */
        ALOGE("sendCommand: CAMERA_CMD_AUTO_LOW_LIGHT_SET is called!");
        break;
    /* 1510: CAMERA_CMD_SET_FLIP */
    case 1510 :
        ALOGD("DEBUG(%s):CAMERA_CMD_SET_FLIP is called!%d", __FUNCTION__, arg1);
        m_exynosCameraParameters->setFlipHorizontal(arg1);
        break;
    /* 1521: CAMERA_CMD_DEVICE_ORIENTATION */
    case 1521:
        ALOGD("DEBUG(%s):CAMERA_CMD_DEVICE_ORIENTATION is called!%d", __FUNCTION__, arg1);
        m_exynosCameraParameters->setDeviceOrientation(arg1);
        uctlMgr = m_exynosCameraActivityControl->getUCTLMgr();
        if (uctlMgr != NULL)
            uctlMgr->setDeviceRotation(m_exynosCameraParameters->getFdOrientation());
        break;
    /*1642: CAMERA_CMD_AUTOFOCUS_MACRO_POSITION*/
    case 1642:
        ALOGD("DEBUG(%s):CAMERA_CMD_AUTOFOCUS_MACRO_POSITION is called!%d", __FUNCTION__, arg1);
        m_exynosCameraParameters->setAutoFocusMacroPosition(arg1);
        break;
    default:
        ALOGV("DEBUG(%s):unexpectect command(%d)", __FUNCTION__, command);
        break;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::generateFrame(int32_t frameCount, ExynosCameraFrame **newFrame)
{
    Mutex::Autolock lock(m_frameLock);

    int ret = 0;
    *newFrame = NULL;

    if (frameCount >= 0) {
        ret = m_searchFrameFromList(&m_processList, frameCount, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):searchFrameFromList fail", __FUNCTION__, __LINE__);
            return INVALID_OPERATION;
        }
    }

    if (*newFrame == NULL) {
        *newFrame = m_previewFrameFactory->createNewFrame();

        if (*newFrame == NULL) {
            ALOGE("ERR(%s):newFrame is NULL", __FUNCTION__);
            return UNKNOWN_ERROR;
        }

        if ((*newFrame)->getRequest(PIPE_SCC) == true) {
            m_dynamicSccCount++;
            ALOGV("DEBUG(%s[%d]):dynamicSccCount inc(%d) frameCount(%d)", __FUNCTION__, __LINE__, m_dynamicSccCount, (*newFrame)->getFrameCount());
        }

        m_processList.push_back(*newFrame);
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_setupEntity(
        uint32_t pipeId,
        ExynosCameraFrame *newFrame,
        ExynosCameraBuffer *srcBuf,
        ExynosCameraBuffer *dstBuf)
{
    int ret = 0;
    entity_buffer_state_t entityBufferState;

    /* set SRC buffer */
    ret = newFrame->getSrcBufferState(pipeId, &entityBufferState);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):getSrcBufferState fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
        return ret;
    }

    if (entityBufferState == ENTITY_BUFFER_STATE_REQUESTED) {
        ret = m_setSrcBuffer(pipeId, newFrame, srcBuf);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_setSrcBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
            return ret;
        }
    }

    /* set DST buffer */
    ret = newFrame->getDstBufferState(pipeId, &entityBufferState);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):getDstBufferState fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
        return ret;
    }

    if (entityBufferState == ENTITY_BUFFER_STATE_REQUESTED) {
        ret = m_setDstBuffer(pipeId, newFrame, dstBuf);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_setDstBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
            return ret;
        }
    }

    ret = newFrame->setEntityState(pipeId, ENTITY_STATE_PROCESSING);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setEntityState(ENTITY_STATE_PROCESSING) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
        return ret;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_setSrcBuffer(
        uint32_t pipeId,
        ExynosCameraFrame *newFrame,
        ExynosCameraBuffer *buffer)
{
    int ret = 0;
    int bufIndex = -1;
    ExynosCameraBufferManager *bufferMgr = NULL;
    ExynosCameraBuffer srcBuf;

    if (buffer == NULL) {
        buffer = &srcBuf;

        ret = m_getBufferManager(pipeId, &bufferMgr, SRC_BUFFER_DIRECTION);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getBufferManager(SRC) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
            return ret;
        }

        if (bufferMgr == NULL) {
            ALOGE("ERR(%s[%d]):buffer manager is NULL, pipeId(%d)", __FUNCTION__, __LINE__, pipeId);
            return BAD_VALUE;
        }

        /* get buffers */
        ret = bufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, buffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getBuffer fail, pipeId(%d), frameCount(%d), ret(%d)",
                __FUNCTION__, __LINE__, pipeId, newFrame->getFrameCount(), ret);
            return ret;
        }
    }

    /* set buffers */
    ret = newFrame->setSrcBuffer(pipeId, *buffer);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setSrcBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
        return ret;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_setDstBuffer(
        uint32_t pipeId,
        ExynosCameraFrame *newFrame,
        ExynosCameraBuffer *buffer)
{
    int ret = 0;
    int bufIndex = -1;
    ExynosCameraBufferManager *bufferMgr = NULL;
    ExynosCameraBuffer dstBuf;

    if (buffer == NULL) {
        buffer = &dstBuf;

        ret = m_getBufferManager(pipeId, &bufferMgr, DST_BUFFER_DIRECTION);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getBufferManager(DST) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
            return ret;
        }

        if (bufferMgr == NULL) {
            ALOGE("ERR(%s[%d]):buffer manager is NULL, pipeId(%d)", __FUNCTION__, __LINE__, pipeId);
            return BAD_VALUE;
        }

        /* get buffers */
        ret = bufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, buffer);
        if (ret < 0) {
            ExynosCameraFrameEntity *curEntity = newFrame->searchEntityByPipeId(pipeId);
            if (curEntity->getBufType() == ENTITY_BUFFER_DELIVERY) {
                ALOGV("DEBUG(%s[%d]): pipe(%d) buffer is empty for delivery", __FUNCTION__, __LINE__, pipeId);
                buffer->index = -1;
            } else {
                ALOGE("ERR(%s[%d]):getBuffer fail, pipeId(%d), frameCount(%d), ret(%d)",
                        __FUNCTION__, __LINE__, pipeId, newFrame->getFrameCount(), ret);
                return ret;
            }
        }
    }

    /* set buffers */
    {
        ret = newFrame->setDstBuffer(pipeId, *buffer);
    }
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setDstBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
        return ret;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::generateFrameReprocessing(ExynosCameraFrame **newFrame)
{
    Mutex::Autolock lock(m_frameLock);

    int ret = 0;
    struct ExynosCameraBuffer tempBuffer;
    int bufIndex = -1;

     /* 1. Make Frame */
    *newFrame = m_reprocessingFrameFactory->createNewFrame();
    if (*newFrame == NULL) {
        ALOGE("ERR(%s):newFrame is NULL", __FUNCTION__);
        return UNKNOWN_ERROR;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_fastenAeStable(void)
{
    int ret = 0;
    ExynosCameraBuffer fastenAeBuffer[INITIAL_SKIP_FRAME];
    ExynosCameraBufferManager *skipBufferMgr = NULL;
    m_createInternalBufferManager(&skipBufferMgr, "SKIP_BUF");

    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    planeSize[0] = 32 * 64 * 2;
    int planeCount  = 2;
    int bufferCount = NUM_FASTAESTABLE_BUFFER;

    if (skipBufferMgr == NULL) {
        ALOGE("ERR(%s[%d]):createBufferManager failed", __FUNCTION__, __LINE__);
        goto func_exit;
    }

    ret = m_allocBuffers(skipBufferMgr, planeCount, planeSize, bytesPerLine, bufferCount, true, false);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_3aaBufferMgr m_allocBuffers(bufferCount=%d) fail",
            __FUNCTION__, __LINE__, bufferCount);
        return ret;
    }

    for (int i = 0; i < bufferCount; i++) {
        int index = i;
        ret = skipBufferMgr->getBuffer(&index, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, &fastenAeBuffer[i]);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getBuffer fail", __FUNCTION__, __LINE__);
            goto done;
        }
    }

    ret = m_previewFrameFactory->fastenAeStable(bufferCount, fastenAeBuffer);
    if (ret < 0) {
        // doing some error handling
    }

done:
    skipBufferMgr->deinit();
    delete skipBufferMgr;
    skipBufferMgr = NULL;

func_exit:
    return ret;
}
/************************* Check This ********************/
bool ExynosCameraHWImpl::m_ispThreadFunc(void)
{
    ExynosBuffer ispBuf;
#ifdef FORCE_LEADER_OFF
    if (tryThreadStop == true) {
        tryThreadStatus = tryThreadStatus | (1 << TRY_THREAD_STATUS_ISP);
        usleep(10000);

        CLOGD("DEBUG(%s):(%d):tryThreadStop == true", __func__, __LINE__);

        return false;
    }
#endif
    m_ispLock.lock();
    if (m_exitIspThread == true) {
        m_ispLock.unlock();
#ifdef FORCE_LEADER_OFF
        tryThreadStatus = tryThreadStatus | (1 << TRY_THREAD_STATUS_ISP);
#endif

        CLOGD("DEBUG(%s):exit 0", __func__);
        return false;
    }

    m_ispCondition.wait(m_ispLock);

    if (m_exitIspThread == true) {
        m_ispLock.unlock();
#ifdef FORCE_LEADER_OFF
        tryThreadStatus = tryThreadStatus | (1 << TRY_THREAD_STATUS_ISP);
#endif

        CLOGD("DEBUG(%s):exit 1", __func__);
        return false;
    }
    m_ispLock.unlock();

    if (isp_input_count > 1)
        CLOGV("[%s] (%d) (%d)", __func__, __LINE__, isp_input_count);

    do {
/* TODO: Check isp input count */
#if 0
        if (isp_input_count < 1) {
            CLOGW("WRN[%s](%d) isp_input_count(%d)", __func__, __LINE__, isp_input_count);
            break;
        }
#endif

        if (m_secCamera->getISPBuf(&ispBuf) == false) {
            CLOGE("ERR(%s):getISPBuf() fail", __func__);
            m_ispLock.unlock();
            return true;
        }
        isp_input_count--;
    } while (m_secCamera->getNumOfShotedIspFrame());

    if (m_secCamera->getCameraMode() != ExynosCamera::CAMERA_MODE_FRONT)
        usleep(10);

    return true;
}


bool ExynosCameraHWImpl::m_isSupportedPreviewSize(const int width,
                                               const int height)
{
    int maxWidth, maxHeight = 0;
    int sizeOfResSize = 0;

    m_secCamera->getSupportedPreviewSizes(&maxWidth, &maxHeight);
    sizeOfResSize = sizeof(PREVIEW_LIST) / (sizeof(int) * 2);

    if (maxWidth < width || maxHeight < height) {
        CLOGE("ERR(%s):invalid PreviewSize(maxSize(%d/%d) size(%d/%d)",
            __func__, maxWidth, maxHeight, width, height);
        return false;
    }

    for (int i = 0; i < sizeOfResSize; i++) {
        if (PREVIEW_LIST[i][0] > maxWidth || PREVIEW_LIST[i][1] > maxHeight)
            continue;
        if (PREVIEW_LIST[i][0] == width && PREVIEW_LIST[i][1] == height)
            return true;
    }

    CLOGE("ERR(%s):Invalid preview size(%dx%d)", __func__, width, height);

    return false;
}

bool ExynosCameraHWImpl::m_isSupportedPictureSize(const int width,
                                               const int height) const
{
    int maxWidth, maxHeight = 0;
    int sizeOfResSize = 0;

    m_secCamera->getSupportedPictureSizes(&maxWidth, &maxHeight);
    sizeOfResSize = sizeof(PICTURE_LIST) / (sizeof(int) * 2);

    if (maxWidth < width || maxHeight < height) {
        CLOGE("ERR(%s):invalid picture Size(maxSize(%d/%d) size(%d/%d)",
            __func__, maxWidth, maxHeight, width, height);
        return false;
    }

    for (int i = 0; i < sizeOfResSize; i++) {
        if (PICTURE_LIST[i][0] > maxWidth || PICTURE_LIST[i][1] > maxHeight)
            continue;
        if (PICTURE_LIST[i][0] == width && PICTURE_LIST[i][1] == height)
            return true;
    }

    CLOGE("ERR(%s):Invalid picture size(%dx%d)", __func__, width, height);

    return false;
}

bool ExynosCameraHWImpl::m_isSupportedVideoSize(const int width,
                                               const int height) const
{
    int maxWidth, maxHeight = 0;
    int sizeOfResSize = 0;

    m_secCamera->getSupportedVideoSizes(&maxWidth, &maxHeight);
    sizeOfResSize = sizeof(VIDEO_LIST) / (sizeof(int) * 2);

    if (maxWidth < width || maxHeight < height) {
        CLOGE("ERR(%s):invalid video Size(maxSize(%d/%d) size(%d/%d)",
            __func__, maxWidth, maxHeight, width, height);
        return false;
    }

    for (int i = 0; i < sizeOfResSize; i++) {
        if (VIDEO_LIST[i][0] > maxWidth || VIDEO_LIST[i][1] > maxHeight)
            continue;
        if (VIDEO_LIST[i][0] == width && VIDEO_LIST[i][1] == height)
            return true;
    }

    CLOGE("ERR(%s):Invalid video size(%dx%d)", __func__, width, height);

    return false;
}
/****************Check end****************/

#ifdef START_HW_THREAD_ENABLE
bool ExynosCameraHWImpl::m_startThreadFuncBufAlloc(void)
{
    CLOGD("DEBUG(%s):in", __func__);

     m_startThreadBufAllocLock.lock();
    /* check early exit request */
    if (m_exitStartThreadBufAlloc == true) {
        m_startThreadBufAllocLock.unlock();
        CLOGV("DEBUG(%s):exiting on request0", __func__);
        return true;
    }

    m_startThreadBufAllocCondition.wait(m_startThreadBufAllocLock);
    /* check early exit request */
    if (m_exitStartThreadBufAlloc == true) {
        m_startThreadBufAllocLock.unlock();
        CLOGV("DEBUG(%s):exiting on request1", __func__);
        return true;
    }
    m_startThreadBufAllocLock.unlock();

    CLOGD("DEBUG(%s):(%d)", __func__, __LINE__);

    m_startThreadBufAllocFinished = false;
    m_errorExistInStartThreadBufAlloc = false;
    if (m_getPreviewCallbackBuffer() == false) {
        CLOGE("ERR(%s):Fail on m_getPreviewCallbackBuffer()", __func__);
        m_errorExistInStartThreadBufAlloc = true;
        goto done;
    }

done:
    m_startThreadBufAllocFinishLock.lock();
    if (m_startThreadBufAllocWaiting == true) {
        CLOGD("DEBUG(%s):before send signal finished ThreadBufAlloc (%d)", __func__, __LINE__);
        m_startThreadBufAllocFinishCondition.signal();
    }
    m_startThreadBufAllocFinished = true;
    m_startThreadBufAllocFinishLock.unlock();

    CLOGD("DEBUG(%s):out", __func__);
    return true;
}

bool ExynosCameraHWImpl::m_startThreadFuncReprocessing(void)
{
    CLOGD("DEBUG(%s):in", __func__);

    m_startThreadReprocessingLock.lock();
    /* check early exit request */
    if (m_exitStartThreadReprocessing == true) {
        m_startThreadReprocessingLock.unlock();
        CLOGV("DEBUG(%s):exiting on request0", __func__);
        return true;
    }

    m_startThreadReprocessingCondition.wait(m_startThreadReprocessingLock);
    /* check early exit request */
    if (m_exitStartThreadReprocessing == true) {
        m_startThreadReprocessingLock.unlock();
        CLOGV("DEBUG(%s):exiting on request1", __func__);
        return true;
    }
    m_startThreadReprocessingLock.unlock();

    CLOGD("DEBUG(%s):(%d)", __func__, __LINE__);

    m_startThreadReprocessingFinished = false;
    m_errorExistInStartThreadReprocessing = false;
    m_startThreadReprocessingRunning = true;

    int i;
    int previewCallbackFramesize = 0;
    ExynosBuffer callbackBuf;

    m_getAlignedYUVSize(m_orgPreviewRect.colorFormat, m_orgPreviewRect.w, m_orgPreviewRect.h, &callbackBuf, true);

    for (i = 0; i < ExynosBuffer::BUFFER_PLANE_NUM_DEFAULT; i++)
        previewCallbackFramesize += callbackBuf.size.extS[i];

    for (i = 0; i < NUM_OF_PREVIEW_BUF; i++) {
        if (m_previewCallbackHeap[i]) {
            m_previewCallbackHeap[i]->release(m_previewCallbackHeap[i]);
            m_previewCallbackHeap[i] = 0;
            m_previewCallbackHeapFd[i] = -1;
        }

        m_previewCallbackHeap[i] = m_getMemoryCb(-1, previewCallbackFramesize, 1, &(m_previewCallbackHeapFd[i]));
        CLOGV("callback size!!!!!!!!!!!!!! %d", previewCallbackFramesize);
        if (!m_previewCallbackHeap[i] || m_previewCallbackHeapFd[i] < 0) {
            CLOGE("ERR(%s):m_getMemoryCb(m_previewCallbackHeap[%d], size(%d) fail", __func__, i, previewCallbackFramesize);
            continue;
        }
    }

    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
        if (m_errorExistInStartThreadMain == false &&
            m_secCamera->startIspReprocessing() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIspReprocessing()", __func__);
            m_errorExistInStartThreadReprocessing = true;
            goto done;
        }

        if (m_errorExistInStartThreadMain == false &&
            m_secCamera->startIs3a0(ExynosCamera::CAMERA_MODE_REPROCESSING) == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIs3a0()", __func__);
            m_errorExistInStartThreadReprocessing = true;
            goto done;
        }

        if (m_errorExistInStartThreadMain == false &&
            m_pictureRunning== false
            && m_startPictureInternalReprocessing() == false)
            CLOGE("ERR(%s):m_startPictureInternalReprocessing() fail", __func__);

        if (m_errorExistInStartThreadMain == false &&
            m_secCamera->startPreviewReprocessing() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startPreviewReprocessing()", __func__);
            m_errorExistInStartThreadReprocessing = true;
            goto done;
        }
    }

done:
    m_startThreadReprocessingFinishLock.lock();
    if (m_startThreadReprocessingFinishWaiting == true) {
        CLOGD("DEBUG(%s):before send signal finished startThreadReprocessing (%d)", __func__, __LINE__);
        m_startThreadReprocessingFinishCondition.signal();
    }
    m_startThreadReprocessingFinished = true;
    m_startThreadReprocessingFinishLock.unlock();

    CLOGD("DEBUG(%s):out", __func__);
    return true;
}

bool ExynosCameraHWImpl::m_startThreadFuncMain(void)
{
    CLOGD("DEBUG(%s):in", __func__);

    m_startThreadMainLock.lock();
    /* check early exit request */
    if (m_exitStartThreadMain == true) {
        m_startThreadMainLock.unlock();
        CLOGV("DEBUG(%s):exiting on request0", __func__);
        return true;
    }

    m_startThreadMainCondition.wait(m_startThreadMainLock);
    /* check early exit request */
    if (m_exitStartThreadMain == true) {
        m_startThreadMainLock.unlock();
        CLOGV("DEBUG(%s):exiting on request1", __func__);
        return true;
    }
    m_startThreadMainLock.unlock();

    CLOGD("DEBUG(%s):(%d)", __func__, __LINE__);

    m_errorExistInStartThreadMain = false;
    m_startThreadBufAllocWaiting = false;
    m_startThreadReprocessingFinishWaiting = false;

    if (m_startThreadMainRunning == true) {
        if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT) {
           if (m_secCamera->startSensor() == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startSensor()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            if (m_secCamera->startSensorOn(ExynosCamera::CAMERA_MODE_FRONT) == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startSensorOn()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            if (m_secCamera->startIsp() == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startIsp()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            CLOGD("DEBUG(%s):before send signal to startThreadReprocessing (%d)", __func__, __LINE__);
            m_startThreadReprocessingCondition.signal();

            if (m_secCamera->startIs3a0(ExynosCamera::CAMERA_MODE_FRONT) == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startIs3a0()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            if (m_pictureRunning == false &&
                m_startPictureInternal() == false)
                CLOGE("ERR(%s):m_startPictureInternal() fail", __func__);

        } else if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->startSensorReprocessing() == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startSensorReprocessing()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            /* Sensor stream on at the OTF path */
            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->startSensorOn(ExynosCamera::CAMERA_MODE_REPROCESSING) == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startSensorOn()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->startIsp() == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startIsp()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }

            CLOGD("DEBUG(%s):before send signal to startThreadReprocessing (%d)", __func__, __LINE__);
            m_startThreadReprocessingCondition.signal();

            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->startIs3a1(ExynosCamera::CAMERA_MODE_BACK) == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startIs3a1()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }
        }

        if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->startSensor() == false) {
                CLOGE("ERR(%s):Fail on m_secCamera->startSensor()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }
        }

        m_startThreadBufAllocFinishLock.lock();
        if (m_startThreadBufAllocFinished == false) {
            m_startThreadBufAllocWaiting = true;
            CLOGD("DEBUG(%s):wait signal finished ThreadBufAlloc (%d)", __func__, __LINE__);
            m_startThreadBufAllocFinishCondition.wait(m_startThreadBufAllocFinishLock);

        }
        m_startThreadBufAllocWaiting = false;
        m_startThreadBufAllocFinishLock.unlock();

        if (m_errorExistInStartThreadReprocessing == false &&
            m_secCamera->startPreview() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startPreview()", __func__);
            m_errorExistInStartThreadMain = true;
            goto done;
        }

        if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->qAll3a1Buf() == false)
                CLOGE("ERR(%s):Fail qAll3a1Buf", __func__);
        }

        m_startThreadReprocessingFinishLock.lock();
        if (m_startThreadReprocessingFinished == false) {
            m_startThreadReprocessingFinishWaiting = true;
            CLOGD("DEBUG(%s):wait signal finished startThreadReprocessing (%d)", __func__, __LINE__);
            m_startThreadReprocessingFinishCondition.wait(m_startThreadReprocessingFinishLock);
        }
        m_startThreadReprocessingFinishWaiting = false;
        m_startThreadReprocessingFinishLock.unlock();

        if (m_errorExistInStartThreadReprocessing == false &&
            m_secCamera->StartStream() == false) {
            CLOGE("ERR(%s):StartStream fail", __func__);
            m_errorExistInStartThreadMain = true;
            goto done;
        }
#if CAPTURE_BUF_GET
        if (((m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) ||
            (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT)) &&
            m_secCamera->getRecordingHint() != true)
        {
            ExynosBuffer tempBuf;
            if (m_errorExistInStartThreadReprocessing == false &&
                m_secCamera->getSensorBuf(&tempBuf) == false) {
                CLOGE("ERR(%s):getSensorBuf() fail", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }
            m_secCamera->putSensorBuf(&tempBuf);
        }
#endif

        m_setSkipFrame(INITIAL_SKIP_FRAME);

        if (m_errorExistInStartThreadReprocessing == false &&
            m_startSensor() != NO_ERROR) {
            CLOGE("ERR(%s):Fail on m_startSensor()", __func__);
            m_errorExistInStartThreadMain = true;
            goto done;
        }

#ifdef OTF_SENSOR_REPROCESSING
        if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
#ifdef DYNAMIC_BAYER_BACK_REC
            if ((m_secCamera->getRecordingHint() == true)
#ifdef SCALABLE_SENSOR
             || (m_secCamera->getScalableSensorStart() == true)
#endif
            ) {
                /* Dummy Start */
                m_sensorRunningReprocessing = true;
                isDqSensor = false;
            } else {
#endif /* DYNAMIC_BAYER_BACK_REC */
            if (m_errorExistInStartThreadReprocessing == false &&
                m_startSensorReprocessing() != NO_ERROR) {
                CLOGE("ERR(%s):Fail on m_startSensorReprocessing()", __func__);
                m_errorExistInStartThreadMain = true;
                goto done;
            }
#ifdef DYNAMIC_BAYER_BACK_REC
            }
#endif /* DYNAMIC_BAYER_BACK_REC */
#endif
        }

#ifdef USE_VDIS
        if ((m_secCamera->getRecordingHint() == true) &&
            (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) &&
            (m_secCamera->getVideoStabilization() == true)) {
            m_VDis->startVDisInternal();
        }
#endif
    }

done:
    if (m_startThreadMainRunning == true) {
        m_startThreadMainRunning = false;
        CLOGD("DEBUG(%s):before send signal to startThreadMain (%d)", __func__, __LINE__);
        m_startThreadMainFinishLock.lock();
        m_startThreadMainFinishCondition.signal();
        m_startThreadMainFinishLock.unlock();
    }

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}
#endif

status_t ExynosCameraHWImpl::m_startPreviewInternal(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);

    ALOGI("DEBUG(%s[%d]):IN", __FUNCTION__, __LINE__);

    uint32_t minFrameNum = 0;
    int ret = 0;
    ExynosCameraFrame *newFrame = NULL;
    ExynosCameraBuffer dstBuf;
    int32_t reprocessingBayerMode = m_exynosCameraParameters->getReprocessingBayerMode();

    m_fliteFrameCount = 0;
    m_3aa_ispFrameCount = 0;
    m_sccFrameCount = 0;
    m_scpFrameCount = 0;
    m_displayPreviewToggle = 0;

    minFrameNum = m_exynosconfig->current->bufInfo.init_bayer_buffers;

#ifdef FPS_CHECK
    for (int i = 0; i < DEBUG_MAX_PIPE_NUM; i++)
        m_debugFpsCount[i] = 0;
#endif

    switch (reprocessingBayerMode) {
        case REPROCESSING_BAYER_MODE_NONE : /* Not using reprocessing */
            ALOGD("DEBUG(%s[%d]): Use REPROCESSING_BAYER_MODE_NONE", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequest3AC(false);
            break;
        case REPROCESSING_BAYER_MODE_PURE_ALWAYS_ON :
            ALOGD("DEBUG(%s[%d]): Use REPROCESSING_BAYER_MODE_PURE_ALWAYS_ON", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequestFLITE(true);
            m_previewFrameFactory->setRequest3AC(false);
            break;
        case REPROCESSING_BAYER_MODE_DIRTY_ALWAYS_ON :
            ALOGD("DEBUG(%s[%d]): Use REPROCESSING_BAYER_MODE_DIRTY_ALWAYS_ON", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequestFLITE(false);
            m_previewFrameFactory->setRequest3AC(true);
            break;
        case REPROCESSING_BAYER_MODE_PURE_DYNAMIC :
            ALOGD("DEBUG(%s[%d]): Use REPROCESSING_BAYER_MODE_PURE_DYNAMIC", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequestFLITE(false);
            m_previewFrameFactory->setRequest3AC(false);
            break;
        case REPROCESSING_BAYER_MODE_DIRTY_DYNAMIC :
            ALOGD("DEBUG(%s[%d]): Use REPROCESSING_BAYER_MODE_DIRTY_DYNAMIC", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequestFLITE(false);
            m_previewFrameFactory->setRequest3AC(false);
            break;
        default :
            ALOGE("ERR(%s[%d]): Unknown dynamic bayer mode", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequest3AC(false);
            break;
    }

    ret = m_previewFrameFactory->initPipes();
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_previewFrameFactory->initPipes() failed", __FUNCTION__, __LINE__);
        return ret;
    }

    for (uint32_t i = 0; i < minFrameNum; i++) {
        ret = generateFrame(i, &newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
            return ret;
        }
        if (newFrame == NULL) {
            ALOGE("ERR(%s[%d]):new faame is NULL", __FUNCTION__, __LINE__);
            return ret;
        }

        m_fliteFrameCount++;
        m_3aa_ispFrameCount++;
        m_sccFrameCount++;
        m_scpFrameCount++;

        if (getCameraId() == CAMERA_ID_BACK) {
            if (reprocessingBayerMode == REPROCESSING_BAYER_MODE_PURE_ALWAYS_ON || reprocessingBayerMode == REPROCESSING_BAYER_MODE_DIRTY_ALWAYS_ON) {
                m_setupEntity(m_getBayerPipeId(), newFrame);
                m_previewFrameFactory->pushFrameToPipe(&newFrame, m_getBayerPipeId());
                m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, m_getBayerPipeId());
            }

            m_setupEntity(PIPE_3AA_ISP, newFrame);
            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_3AA_ISP);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_3AA_ISP);

            m_setupEntity(PIPE_SCP, newFrame);
            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCP);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCP);
        } else {
            m_setupEntity(PIPE_FLITE_FRONT, newFrame);
            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_FLITE_FRONT);

            m_setupEntity(PIPE_3AA_FRONT, newFrame);
            m_setupEntity(PIPE_ISP_FRONT, newFrame);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_ISP_FRONT);

            m_setupEntity(PIPE_SCC_FRONT, newFrame);
            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCC_FRONT);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCC_FRONT);

            m_setupEntity(PIPE_SCP_FRONT, newFrame);
            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCP_FRONT);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCP_FRONT);
        }
    }

    /* prepare pipes */
    ret = m_previewFrameFactory->preparePipes();
    if (ret < 0) {
        ALOGE("ERR(%s):preparePipe fail", __FUNCTION__);
        return ret;
    }

#ifndef START_PICTURE_THREAD
    if (isReprocessing() == true) {
        m_startPictureInternal();
    }
#endif

    /* stream on pipes */
    ret = m_previewFrameFactory->startPipes();
    if (ret < 0) {
        ALOGE("ERR(%s):startPipe fail", __FUNCTION__);
        return ret;
    }

    /* start all thread */
    ret = m_previewFrameFactory->startInitialThreads();
    if (ret < 0) {
        ALOGE("ERR(%s):startInitialThreads fail", __FUNCTION__);
        return ret;
    }

    m_previewEnabled = true;
    m_exynosCameraParameters->setPreviewRunning(m_previewEnabled);

    if (m_exynosCameraParameters->getFocusModeSetting() == true) {
        ALOGD("set Focus Mode(%s[%d])", __FUNCTION__, __LINE__);
        int focusmode = m_exynosCameraParameters->getFocusMode();
        m_exynosCameraActivityControl->setAutoFocusMode(focusmode);
        m_exynosCameraParameters->setFocusModeSetting(false);
    }

    ALOGI("DEBUG(%s[%d]):OUT", __FUNCTION__, __LINE__);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_stopPreviewInternal(void)
{
    int ret = 0;

    ALOGI("DEBUG(%s[%d]):IN", __FUNCTION__, __LINE__);

    ret = m_previewFrameFactory->stopPipes();
    if (ret < 0) {
        ALOGE("ERR(%s):stopPipe fail", __FUNCTION__);
        return ret;
    }

    ALOGD("DEBUG(%s[%d]):clear process Frame list", __FUNCTION__, __LINE__);
    ret = m_clearList(&m_processList);
    if (ret < 0) {
        ALOGE("ERR(%s):m_clearList fail", __FUNCTION__);
        return ret;
    }

    m_pipeFrameDoneQ->release();

    m_fliteFrameCount = 0;
    m_3aa_ispFrameCount = 0;
    m_sccFrameCount = 0;
    m_scpFrameCount = 0;

    m_previewEnabled = false;
    m_exynosCameraParameters->setPreviewRunning(m_previewEnabled);

    ALOGI("DEBUG(%s[%d]):OUT", __FUNCTION__, __LINE__);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_startPictureInternal(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);

    int ret = 0;
    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES]    = {0};
    int hwPictureW, hwPictureH;
    int planeCount  = 1;
    int minBufferCount = 1;
    int maxBufferCount = 1;
    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE;
    buffer_manager_allocation_mode_t allocMode = BUFFER_MANAGER_ALLOCATION_ONDEMAND;

    if (m_zslPictureEnabled == true) {
        ALOGD("DEBUG(%s[%d]): zsl picture is already initialized", __FUNCTION__, __LINE__);
        return NO_ERROR;
    }

    if (getCameraId() == CAMERA_ID_BACK) {
        if( m_exynosCameraParameters->getHighSpeedRecording() ) {
            m_exynosCameraParameters->getHwSensorSize(&hwPictureW, &hwPictureH);
            ALOGI("(%s):HW Picture(HighSpeed) width x height = %dx%d", __FUNCTION__, hwPictureW, hwPictureH);
        } else {
            m_exynosCameraParameters->getMaxSensorSize(&hwPictureW, &hwPictureH);
            ALOGI("(%s):HW Picture width x height = %dx%d", __FUNCTION__, hwPictureW, hwPictureH);
        }

        planeSize[0] = ALIGN_UP(hwPictureW, GSCALER_IMG_ALIGN) * ALIGN_UP(hwPictureH, GSCALER_IMG_ALIGN) * 2;
        planeCount  = 2;
        minBufferCount = 1;
        maxBufferCount = NUM_PICTURE_BUFFERS;

        if (m_exynosCameraParameters->getHighResolutionCallbackMode() == true) {
            /* SCC Reprocessing Buffer realloc for high resolution callback */
            minBufferCount = 2;
        }

        ret = m_allocBuffers(m_sccReprocessingBufferMgr, planeCount, planeSize, bytesPerLine, minBufferCount, maxBufferCount, type, allocMode, true, false);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_sccReprocessingBufferMgr m_allocBuffers(minBufferCount=%d, maxBufferCount=%d) fail",
                __FUNCTION__, __LINE__, minBufferCount, maxBufferCount);
            return ret;
        }

        if (m_exynosCameraParameters->getUsePureBayerReprocessing() == true) {
            ret = m_setReprocessingBuffer();
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):m_setReprocessing Buffer fail", __FUNCTION__, __LINE__);
                return ret;
            }
        }
    }

    if (m_reprocessingFrameFactory == NULL) {
        m_reprocessingFrameFactory = (ExynosCameraFrameFactory *)new ExynosCameraFrameReprocessingFactory(m_cameraId, m_exynosCameraParameters);

        ret = m_reprocessingFrameFactory->create();
        if (ret < 0) {
            ALOGE("ERR(%s):m_reprocessingFrameFactory->create() failed", __FUNCTION__);
            return ret;
        }

        m_pictureFrameFactory = m_reprocessingFrameFactory;
        ALOGD("DEBUG(%s[%d]):FrameFactory(pictureFrameFactory) created", __FUNCTION__, __LINE__);
    }

    ret = m_reprocessingFrameFactory->initPipes();
    if (ret < 0) {
        ALOGE("ERR(%s):m_reprocessingFrameFactory->initPipes() failed", __FUNCTION__);
        return ret;
    }

    ret = m_reprocessingFrameFactory->preparePipes();
    if (ret < 0) {
        ALOGE("ERR(%s):m_reprocessingFrameFactory preparePipe fail", __FUNCTION__);
        return ret;
    }

    /* stream on pipes */
    ret = m_reprocessingFrameFactory->startPipes();
    if (ret < 0) {
        ALOGE("ERR(%s):m_reprocessingFrameFactory startPipe fail", __FUNCTION__);
        return ret;
    }

    m_zslPictureEnabled = true;

    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT) {
        if (m_pictureRunning == true) {
            CLOGE("ERR(%s):Aready m_pictureRunning is running", __func__);
            return false;
        }

        int pictureW, pictureH, pictureFormat, pictureFramesize;
        ExynosBuffer nullBuf;

        pictureFormat = m_secCamera->getPictureFormat();
        m_secCamera->getPictureSize(&pictureW, &pictureH);
        pictureFramesize = FRAME_SIZE(V4L2_PIX_2_HAL_PIXEL_FORMAT(pictureFormat), ALIGN_UP(pictureW, CAMERA_MAGIC_ALIGN), ALIGN_UP(pictureH, CAMERA_MAGIC_ALIGN));

        if (m_rawHeap) {
            m_rawHeap->release(m_rawHeap);
            m_rawHeap = 0;
            m_rawHeapFd = -1;
            m_rawHeapSize = 0;
        }

        int rawHeapSize = pictureFramesize;

        m_rawHeap = m_getMemoryCb(-1, rawHeapSize, 1, &m_rawHeapFd);
        if (!m_rawHeap || m_rawHeapFd <= 0) {
            CLOGE("ERR(%s):m_getMemoryCb(m_rawHeap, size(%d) fail", __func__, rawHeapSize);
            return false;
        }
        m_rawHeapSize = rawHeapSize;

        for (int i = 0; i < NUM_OF_PICTURE_BUF; i++) {
            if (m_pictureHeap[i]) {
                m_pictureHeap[i]->release(m_pictureHeap[i]);
                m_pictureHeap[i] = 0;
                m_pictureHeapFd[i] = -1;
            }

            m_pictureHeap[i] = m_getMemoryCb(-1, pictureFramesize, 1, &(m_pictureHeapFd[i]));
            if (!m_pictureHeap[i] || m_pictureHeapFd[i] <= 0) {
                CLOGE("ERR(%s):m_getMemoryCb(m_pictureHeap[%d], size(%d) fail", __func__, i, pictureFramesize);
                return false;
            }

            m_pictureBuf[0] = nullBuf;
            m_pictureBuf[0].virt.extP[0] = (char *)m_pictureHeap[i]->data;
            m_pictureBuf[0].fd.extFd[0] = m_pictureHeapFd[i];

            m_getAlignedYUVSize(pictureFormat, ALIGN_UP(pictureW, CAMERA_MAGIC_ALIGN), ALIGN_UP(pictureH, CAMERA_MAGIC_ALIGN), &m_pictureBuf[0]);

            m_pictureBuf[0].reserved.p = i;

            m_secCamera->setPictureBuf(&m_pictureBuf[0]);
        }

        if (m_secCamera->startPicture() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startPicture()", __func__);
            return false;
        }

        for (int i = 0; i < NUM_OF_FLASH_BUF; i++)
            m_pictureBuf[i] = nullBuf;

        m_pictureRunning = true;
    }
    
    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_stopPictureInternal(void)
{
    ALOGI("INFO(%s[%d])", __FUNCTION__, __LINE__);
    int ret = 0;

    m_prePictureThread->join();
    m_pictureThread->join();
    m_postPictureThread->join();

    if (m_exynosCameraParameters->getHighResolutionCallbackMode() == true)
        m_highResolutionCallbackThread->join();

    m_jpegCallbackThread->join();

    if (m_zslPictureEnabled == true) {
        ret = m_reprocessingFrameFactory->stopPipes();
        if (ret < 0) {
            ALOGE("ERR(%s):m_reprocessingFrameFactory0>stopPipe() fail", __FUNCTION__);
        }
    }

    dstIspReprocessingQ->release();
    dstSccReprocessingQ->release();
    dstGscReprocessingQ->release();

    dstJpegReprocessingQ->release();

    m_jpegCallbackQ->release();

    ALOGD("DEBUG(%s[%d]):clear postProcess(Picture) Frame list", __FUNCTION__, __LINE__);
    ret = m_clearList(&m_postProcessList);
    if (ret < 0) {
        ALOGE("ERR(%s):m_clearList fail", __FUNCTION__);
        return ret;
    }

    m_zslPictureEnabled = false;

    if (m_pictureRunning == false) {
        CLOGE("ERR(%s):Aready m_pictureRunning is stop", __func__);
        return false;
    }

    if (m_secCamera->flagStartPicture() == true &&
        m_secCamera->stopPicture() == false)
        CLOGE("ERR(%s):Fail on m_secCamera->stopPicture()", __func__);

    for (int i = 0; i < NUM_OF_PICTURE_BUF; i++) {
        if (m_pictureHeap[i]) {
            m_pictureHeap[i]->release(m_pictureHeap[i]);
            m_pictureHeap[i] = 0;
            m_pictureHeapFd[i] = -1;
        }
    }

    if (m_rawHeap) {
        m_rawHeap->release(m_rawHeap);
        m_rawHeap = 0;
        m_rawHeapFd = -1;
        m_rawHeapSize = 0;
    }

    m_pictureRunning = false;

    /* TODO: need timeout */
    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_startRecordingInternal(void)
{
    int ret = 0;

    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES]    = {0};
    int videoW = 0, videoH = 0;
    int planeCount  = 1;
    int minBufferCount = 1;
    int maxBufferCount = 1;
    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE;
    buffer_manager_allocation_mode_t allocMode = BUFFER_MANAGER_ALLOCATION_SILENT;
    int heapFd = 0;

    for (uint32_t i = 0; i < m_exynosconfig->current->bufInfo.num_recording_buffers ; i++)
        m_recordingTimeStamp[i] = 0L;

    m_exynosCameraParameters->getVideoSize(&videoW, &videoH);
    ALOGD("DEBUG(%s[%d]):videoSize = %d x %d",  __FUNCTION__, __LINE__, videoW, videoH);

    m_doCscRecording = true;
    if (m_exynosCameraParameters->doCscRecording() == true) {
        ALOGI("INFO(%s[%d]):do Recording CSC !!!", __FUNCTION__, __LINE__);
    } else {
        ALOGI("INFO(%s[%d]):skip Recording CSC !!!", __FUNCTION__, __LINE__);
        m_doCscRecording = false;
    }

    /* alloc recording Callback Heap */
    m_recordingCallbackHeap = m_getMemoryCb(-1, sizeof(struct addrs), m_exynosconfig->current->bufInfo.num_recording_buffers, &heapFd);

    if (m_doCscRecording == true) {
        /* alloc recording Image buffer */
        planeSize[0] = ROUND_UP(videoW, CAMERA_MAGIC_ALIGN) * ROUND_UP(videoH, CAMERA_MAGIC_ALIGN) + MFC_7X_BUFFER_OFFSET;
        planeSize[1] = ROUND_UP(videoW, CAMERA_MAGIC_ALIGN) * ROUND_UP(videoH / 2, CAMERA_MAGIC_ALIGN) + MFC_7X_BUFFER_OFFSET;
        planeCount   = 2;
        minBufferCount = 1;
        maxBufferCount = m_exynosconfig->current->bufInfo.num_recording_buffers;

        ret = m_allocBuffers(m_recordingBufferMgr, planeCount, planeSize, bytesPerLine, minBufferCount, maxBufferCount, type, allocMode, false, true);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_recordingBufferMgr m_allocBuffers(minBufferCount=%d, maxBufferCount=%d) fail",
                __FUNCTION__, __LINE__, minBufferCount, maxBufferCount);
    }

        return ret;
    }

    if (m_doCscRecording == true) {
        int recPipeId = 0;
        if (getCameraId() == CAMERA_ID_BACK)
            recPipeId = PIPE_GSC_VIDEO;
        else
            recPipeId = PIPE_GSC_VIDEO_FRONT;

        m_previewFrameFactory->startThread(recPipeId);
    }

func_exit:

    return ret;
}

status_t ExynosCameraHWImpl::m_stopRecordingInternal(void)
{
    if (m_doCscRecording == true) {
        int recPipeId = 0;
        if (getCameraId() == CAMERA_ID_BACK)
            recPipeId = PIPE_GSC_VIDEO;
        else
            recPipeId = PIPE_GSC_VIDEO_FRONT;

        m_previewFrameFactory->stopThread(recPipeId);

        m_recordingThread->requestExitAndWait();
        m_recordingQ->release();

        m_recordingBufferMgr->deinit();
    }

    if (m_recordingCallbackHeap != NULL) {
        m_recordingCallbackHeap->release(m_recordingCallbackHeap);
        m_recordingCallbackHeap = NULL;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_restartPreviewInternal(void)
{
    ALOGI("INFO(%s[%d]): Internal restart preview", __FUNCTION__, __LINE__);
    int ret = 0;
    int err = 0;

    m_startPictureInternalThread->join();
    m_previewFrameFactory->setStopFlag();
    m_mainThread->requestExitAndWait();

    ret = m_stopPictureInternal();
    if (ret < 0)
        ALOGE("ERR(%s[%d]):m_stopPictureInternal fail", __FUNCTION__, __LINE__);

    ret = m_stopPreviewInternal();
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_stopPreviewInternal fail", __FUNCTION__, __LINE__);
        err = ret;
    }

#if 0
    ret = setPreviewWindow(m_previewWindow);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setPreviewWindow fail", __FUNCTION__, __LINE__);
        err = ret;
    }

    /* realloc callback buffers */
    if (m_scpBufferMgr != NULL) {
        m_scpBufferMgr->deinit();
    }
    if (m_previewCallbackBufferMgr != NULL) {
        m_previewCallbackBufferMgr->deinit();
    }
#endif

    /* skip to free and reallocate buffers */
    if (m_bayerBufferMgr != NULL) {
        m_bayerBufferMgr->resetBuffers();
    }
    if (m_3aaBufferMgr != NULL) {
        m_3aaBufferMgr->resetBuffers();
    }
    if (m_ispBufferMgr != NULL) {
        m_ispBufferMgr->resetBuffers();
    }
    if (m_sccBufferMgr != NULL) {
        m_sccBufferMgr->resetBuffers();
    }

    if (m_highResolutionCallbackBufferMgr != NULL) {
        m_highResolutionCallbackBufferMgr->resetBuffers();
    }

    /* skip to free and reallocate buffers */
    if (m_ispReprocessingBufferMgr != NULL) {
        m_ispReprocessingBufferMgr->resetBuffers();
    }
    if (m_sccReprocessingBufferMgr != NULL) {
        m_sccReprocessingBufferMgr->resetBuffers();
    }

    if (m_gscBufferMgr != NULL) {
        m_gscBufferMgr->resetBuffers();
    }
    if (m_jpegBufferMgr != NULL) {
        m_jpegBufferMgr->resetBuffers();
    }
    if (m_recordingBufferMgr != NULL) {
        m_recordingBufferMgr->resetBuffers();
    }

    /* realloc callback buffers */
    if (m_scpBufferMgr != NULL) {
        m_scpBufferMgr->deinit();
        m_scpBufferMgr->setBufferCount(0);
    }
    if (m_previewCallbackBufferMgr != NULL) {
        m_previewCallbackBufferMgr->deinit();
    }

    if (m_captureSelector != NULL) {
        m_captureSelector->release();
    }
    if (m_sccCaptureSelector != NULL) {
        m_sccCaptureSelector->release();
    }

    if( m_exynosCameraParameters->getHighSpeedRecording() && m_exynosCameraParameters->getReallocBuffer() ) {
        ALOGD("DEBUG(%s): realloc buffer all buffer deinit ", __FUNCTION__);
        if (m_bayerBufferMgr != NULL) {
            m_bayerBufferMgr->deinit();
        }
        if (m_3aaBufferMgr != NULL) {
            m_3aaBufferMgr->deinit();
        }
        if (m_ispBufferMgr != NULL) {
            m_ispBufferMgr->deinit();
        }
        if (m_sccBufferMgr != NULL) {
            m_sccBufferMgr->deinit();
        }
/*
        if (m_highResolutionCallbackBufferMgr != NULL) {
            m_highResolutionCallbackBufferMgr->deinit();
        }
*/
        if (m_gscBufferMgr != NULL) {
            m_gscBufferMgr->deinit();
        }
        if (m_jpegBufferMgr != NULL) {
            m_jpegBufferMgr->deinit();
        }
        if (m_recordingBufferMgr != NULL) {
            m_recordingBufferMgr->deinit();
        }
    }

    ret = setPreviewWindow(m_previewWindow);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setPreviewWindow fail", __FUNCTION__, __LINE__);
        err = ret;
    }

    ALOGI("INFO(%s[%d]):setBuffersThread is run", __FUNCTION__, __LINE__);
    m_setBuffersThread->run("ExynosCamera", PRIORITY_DEFAULT);
    m_setBuffersThread->join();

    ret = m_startPreviewInternal();
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_startPreviewInternal fail", __FUNCTION__, __LINE__);
        err = ret;
    }

    m_mainThread->run("ExynosCamera", PRIORITY_DEFAULT);

    return err;
}

bool ExynosCameraHWImpl::m_mainThreadFunc(void)
{
    int ret = 0;
    int index = 0;
    ExynosCameraFrame *newFrame = NULL;

    if (m_previewEnabled == false) {
        ALOGD("DEBUG(%s):preview is stopped, thread stop", __FUNCTION__);
        return false;
    }

    ret = m_pipeFrameDoneQ->waitAndPopProcessQ(&newFrame);
    if (ret < 0) {
        /* TODO: We need to make timeout duration depends on FPS */
        if (ret == TIMED_OUT) {
            ALOGW("WARN(%s):wait timeout", __FUNCTION__);
        } else {
            ALOGE("ERR(%s):wait and pop fail, ret(%d)", __FUNCTION__, ret);
            /* TODO: doing exception handling */
        }
        return true;
    }

/* HACK Reset Preview Flag*/
#if 0
    if (m_exynosCameraParameters->getRestartPreview() == true) {
        m_resetPreview = true;
        ret = m_restartPreviewInternal();
        m_resetPreview = false;
        ALOGE("INFO(%s[%d]) m_resetPreview(%d)", __FUNCTION__, __LINE__, m_resetPreview);
        if (ret < 0)
            ALOGE("(%s[%d]): restart preview internal fail", __FUNCTION__, __LINE__);

        return true;
    }
#endif

    if (newFrame == NULL) {
        ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
        return true;
    }

    if (getCameraId() == CAMERA_ID_BACK) {
        ret = m_handlePreviewFrame(newFrame);
    } else {
        ret = m_handlePreviewFrameFront(newFrame);
    }
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):handle preview frame fail", __FUNCTION__, __LINE__);
        return ret;
    }

    if (newFrame->isComplete() == true) {
        ret = m_removeFrameFromList(&m_processList, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):remove frame from processList fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        }

        if (newFrame->getFrameLockState() == false)
        {
            delete newFrame;
            newFrame = NULL;
        }
    }

    m_checkFpsAndUpdatePipeWaitTime();

    /* Continuous Auto-focus */
    if (m_exynosCameraParameters->getFocusMode() == FOCUS_MODE_CONTINUOUS_PICTURE)
    {
        int afstatus = 0;
        static int afResult = 1;
        int prev_afstatus = afResult;
        afstatus = m_exynosCameraActivityControl->getCAFResult();
        afResult = afstatus;

        if (afstatus == 3 && (prev_afstatus == 0 || prev_afstatus == 1)) {
            afResult = 4;
        }

        if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_FOCUS)
            && (prev_afstatus != afstatus)) {
            ALOGD("DEBUG(%s):CAMERA_MSG_FOCUS(%d) mode(%d)",
                __FUNCTION__, afResult, m_exynosCameraParameters->getFocusMode());
            m_notifyCb(CAMERA_MSG_FOCUS, afResult, 0, m_callbackCookie);
        }
    }

    return true;
}

status_t ExynosCameraHWImpl::m_handlePreviewFrame(ExynosCameraFrame *frame)
{
    int ret = 0;
    int frameSkipCount = 0;
    ExynosCameraFrameEntity *entity = NULL;
    ExynosCameraFrame *newFrame = NULL;
    ExynosCameraBuffer buffer;
    int pipeID = 0;
    /* to handle the high speed frame rate */
    bool skipPreview = false;
    int ratio = 1;
    uint32_t minFps = 0, maxFps = 0;
    uint32_t dispFps = EXYNOS_CAMERA_PREVIEW_FPS_REFERENCE;
    uint32_t fvalid = 0;
    uint32_t fcount = 0;
    struct camera2_stream *shot_stream = NULL;
    ExynosCameraBuffer resultBuffer;
    camera2_node_group node_group_info_isp;
    int32_t reprocessingBayerMode = m_exynosCameraParameters->getReprocessingBayerMode();

    entity = frame->getFrameDoneEntity();
    if (entity == NULL) {
        ALOGE("ERR(%s[%d]):current entity is NULL", __FUNCTION__, __LINE__);
        /* TODO: doing exception handling */
        return true;
    }

    /* TODO: remove hard coding */
    switch(entity->getPipeId()) {
    case PIPE_3AA_ISP:
        m_debugFpsCheck(entity->getPipeId());
        ret = frame->getSrcBuffer(entity->getPipeId(), &buffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getSrcBuffer fail, pipeId(%d), ret(%d)",
                __FUNCTION__, __LINE__, entity->getPipeId(), ret);
            return ret;
        }
        ret = m_putBuffers(m_3aaBufferMgr, buffer.index);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
        }

        ALOGV("DEBUG(%s[%d]):3AA_ISP frameCount(%d) frame.Count(%d)",
                __FUNCTION__, __LINE__,
                getMetaDmRequestFrameCount((struct camera2_shot_ext *)buffer.addr[1]),
                frame->getFrameCount());

        ret = frame->getDstBuffer(entity->getPipeId(), &buffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)",
                __FUNCTION__, __LINE__, entity->getPipeId(), ret);
            return ret;
        }

        ret = m_putBuffers(m_ispBufferMgr, buffer.index);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
            break;
        }
		
        frame->setMetaDataEnable(true);
		
        /* Face detection */
        if(!m_exynosCameraParameters->getHighSpeedRecording()) {
            if( m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_PREVIEW_METADATA) ) {
                ret = m_doFdCallbackFunc(frame);
                if (ret < 0) {
                    ALOGE("ERR(%s[%d]):m_doFdCallbackFunc fail, ret(%d)",
                        __FUNCTION__, __LINE__, ret);
                    return ret;
                }
            }
        }

        if (m_3aaBufferMgr->getNumOfAvailableBuffer() > 0 &&
                m_ispBufferMgr->getNumOfAvailableBuffer() > 0) {
            ret = generateFrame(m_3aa_ispFrameCount, &newFrame);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
                return ret;
            }

            ret = m_setupEntity(PIPE_3AA_ISP, newFrame);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):setupEntity fail", __FUNCTION__, __LINE__);
                break;
            }

            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_3AA_ISP);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_3AA_ISP);

            m_3aa_ispFrameCount++;
        }
        break;
    case PIPE_3AC:
    case PIPE_FLITE:
        m_debugFpsCheck(entity->getPipeId());
        if( m_exynosCameraParameters->getHighSpeedRecording() ) {
            ret = frame->getDstBuffer(entity->getPipeId(), &buffer);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, entity->getPipeId(), ret);
                return ret;
            }
            ret = m_putBuffers(m_bayerBufferMgr, buffer.index);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
                break;
            }
        } else {
            ret = m_captureSelector->manageFrameHoldList(frame, entity->getPipeId(), false);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):manageFrameHoldList fail", __FUNCTION__, __LINE__);
                return ret;
            }
        }

        /* TODO: Dynamic bayer capture, currently support only single shot */
        if (reprocessingBayerMode == REPROCESSING_BAYER_MODE_PURE_DYNAMIC) {
            m_previewFrameFactory->stopThread(entity->getPipeId());
        }

        if (reprocessingBayerMode == REPROCESSING_BAYER_MODE_PURE_ALWAYS_ON || reprocessingBayerMode == REPROCESSING_BAYER_MODE_DIRTY_ALWAYS_ON) {
            if (m_bayerBufferMgr->getNumOfAvailableBuffer() > 0) {
                ret = generateFrame(m_fliteFrameCount, &newFrame);
                if (ret < 0) {
                    ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
                    return ret;
                }

                ret = m_setupEntity(entity->getPipeId(), newFrame);
                if (ret < 0) {
                    ALOGE("ERR(%s[%d]):setupEntity fail", __FUNCTION__, __LINE__);
                    break;
                }

                m_previewFrameFactory->pushFrameToPipe(&newFrame, entity->getPipeId());
                m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, entity->getPipeId());

                m_fliteFrameCount++;
            }
        }
        break;
    case PIPE_SCP:
        if (entity->getDstBufState() == ENTITY_BUFFER_STATE_COMPLETE) {
            m_debugFpsCheck(entity->getPipeId());
            ret = frame->getDstBuffer(entity->getPipeId(), &buffer);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, entity->getPipeId(), ret);
                return ret;
            }

            /* TO DO : skip frame for HDR */
            shot_stream = (struct camera2_stream *)buffer.addr[2];
            if (shot_stream != NULL) {
                getStreamFrameValid(shot_stream, &fvalid);
                getStreamFrameCount(shot_stream, &fcount);
            } else {
                ALOGE("ERR(%s[%d]):shot_stream is NULL", __FUNCTION__, __LINE__);
                fvalid = false;
                fcount = 0;
            }

            /* drop preview frame if lcd supported frame rate < scp frame rate */
            frame->getFpsRange(&minFps, &maxFps);
            if (dispFps < maxFps) {
                ratio = (int)((maxFps * 10 / dispFps) / 10);
                m_displayPreviewToggle = (m_displayPreviewToggle + 1) % ratio;
                skipPreview = (m_displayPreviewToggle == 0) ? true : false;
#ifdef DEBUG
                ALOGE("DEBUG(%s[%d]):preview frame skip! frameCount(%d) (m_displayPreviewToggle=%d, maxFps=%d, dispFps=%d, ratio=%d, skipPreview=%d)",
                        __FUNCTION__, __LINE__, frame->getFrameCount(), m_displayPreviewToggle, maxFps, dispFps, ratio, (int)skipPreview);
#endif
            }

            m_exynosCameraParameters->getFrameSkipCount(&frameSkipCount);

            if (frameSkipCount > 0) {
            ALOGD("INFO(%s[%d]):frameSkipCount=%d buffer.index(%d)", __FUNCTION__, __LINE__, frameSkipCount, buffer.index);
                ret = m_scpBufferMgr->cancelBuffer(buffer.index);
            } else {
                if (m_skipReprocessing == true)
                    m_skipReprocessing = false;
                nsecs_t timeStamp = (nsecs_t)frame->getTimeStamp();
                m_recordingStateLock.lock();
                if (m_recordingEnabled == true
                    && m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_VIDEO_FRAME)) {
                    if (timeStamp <= 0L) {
                        ALOGE("WARN(%s[%d]):timeStamp(%lld) Skip", __FUNCTION__, __LINE__, timeStamp);
                    } else {
                        if (m_exynosCameraParameters->doCscRecording() == true) {
                            /* get Recording Image buffer */
                            int bufIndex = -2;
                            ExynosCameraBuffer recordingBuffer;
                            ret = m_recordingBufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, &recordingBuffer);
                            if (ret < 0 || bufIndex < 0) {
                                if ((++m_recordingFrameSkipCount % 100) == 0) {
                                    ALOGE("ERR(%s[%d]): Recording buffer is not available!! Recording Frames are Skipping(%d frames) (bufIndex=%d)",
                                            __FUNCTION__, __LINE__, m_recordingFrameSkipCount, bufIndex);
                                    m_recordingBufferMgr->printBufferQState();
                                }
                            } else {
                                if (m_recordingFrameSkipCount != 0) {
                                    ALOGE("ERR(%s[%d]): Recording buffer is not available!! Recording Frames are Skipped(%d frames) (bufIndex=%d) (recordingQ=%d)",
                                            __FUNCTION__, __LINE__, m_recordingFrameSkipCount, bufIndex, m_recordingQ->getSizeOfProcessQ());
                                    m_recordingFrameSkipCount = 0;
                                    m_recordingBufferMgr->printBufferQState();
                                }
                                m_recordingTimeStamp[bufIndex] = timeStamp;

                                ret = m_doPrviewToRecordingFunc(PIPE_GSC_VIDEO, buffer, recordingBuffer);
                                if (ret < 0) {
                                    ALOGW("WARN(%s[%d]):recordingCallback Skip", __FUNCTION__, __LINE__);
                                }
                            }
                        } else {
                            m_recordingTimeStamp[buffer.index] = timeStamp;
                            if (m_recordingStartTimeStamp == 0)
                                m_recordingStartTimeStamp = timeStamp;

                            if ((0L < timeStamp)
                                && (m_lastRecordingTimeStamp < timeStamp)
                                && (m_recordingStartTimeStamp <= timeStamp)) {
#ifdef CHECK_MONOTONIC_TIMESTAMP
                                    ALOGD("DEBUG(%s[%d]):m_dataCbTimestamp::recordingFrameIndex=%d, recordingTimeStamp=%lld",
                                        __FUNCTION__, __LINE__, buffer.index, timeStamp);
#endif
#ifdef DEBUG
                                    ALOGD("DEBUG(%s[%d]): - lastTimeStamp(%lld), systemTime(%lld), recordingStart(%lld)",
                                        __FUNCTION__, __LINE__,
                                        m_lastRecordingTimeStamp,
                                        systemTime(SYSTEM_TIME_MONOTONIC),
                                        m_recordingStartTimeStamp);
#endif
                                    struct addrs *recordAddrs = NULL;

                                    recordAddrs = (struct addrs *)m_recordingCallbackHeap->data;
                                    recordAddrs[buffer.index].type        = kMetadataBufferTypeCameraSource;
                                    recordAddrs[buffer.index].fdPlaneY    = (unsigned int)buffer.fd[0];
                                    recordAddrs[buffer.index].fdPlaneCbcr = (unsigned int)buffer.fd[1];
                                    recordAddrs[buffer.index].bufIndex    = buffer.index;

                                    m_dataCbTimestamp(
                                            timeStamp,
                                            CAMERA_MSG_VIDEO_FRAME,
                                            m_recordingCallbackHeap,
                                            buffer.index,
                                            m_callbackCookie);
                                    m_lastRecordingTimeStamp = timeStamp;
                            }
                        }
                    }
                }
                m_recordingStateLock.unlock();

            if (skipPreview == true) {
                ALOGD("INFO(%s[%d]):frameSkipCount=%d buffer.index(%d)", __FUNCTION__, __LINE__, frameSkipCount, buffer.index);
                ret = m_scpBufferMgr->cancelBuffer(buffer.index);
            } else {
                    ExynosCameraBuffer callbackBuffer;
                    ExynosCameraFrame *callbackFrame = NULL;
                    struct camera2_shot_ext *shot_ext = new struct camera2_shot_ext;
                    callbackFrame = m_previewFrameFactory->createNewFrameOnlyOnePipe(PIPE_SCP);

                    frame->getDstBuffer(PIPE_SCP, &callbackBuffer);
                    frame->getMetaData(shot_ext);
                    callbackFrame->storeDynamicMeta(shot_ext);
                    callbackFrame->setDstBuffer(PIPE_SCP, callbackBuffer);
                    delete shot_ext;

                    ALOGV("INFO(%s[%d]):push frame to previewQ", __FUNCTION__, __LINE__);
                    m_previewQ->pushProcessQ(&callbackFrame);
                }
            }

            ALOGV("DEBUG(%s[%d]):SCP done HAL-frameCount(%d)", __FUNCTION__, __LINE__, frame->getFrameCount());
        } else {
            ALOGV("DEBUG(%s[%d]):SCP droped - SCP buffer is not ready HAL-frameCount(%d)", __FUNCTION__, __LINE__, frame->getFrameCount());
            m_previewFrameFactory->dump();
        }

        ALOGV("DEBUG(%s[%d]):SCP done HAL-frameCount(%d)", __FUNCTION__, __LINE__, frame->getFrameCount());

        ret = generateFrame(m_scpFrameCount, &newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
            return ret;
        }
        ret = m_setupEntity(PIPE_SCP, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):setupEntity fail", __FUNCTION__, __LINE__);
            break;
        }

        /*check preview drop...*/
        newFrame->getDstBuffer(PIPE_SCP, &resultBuffer);
        if (resultBuffer.index < 0) {
            newFrame->setRequest(PIPE_SCP, false);
            newFrame->getNodeGroupInfo(&node_group_info_isp, PERFRAME_INFO_ISP);
            node_group_info_isp.capture[PERFRAME_BACK_SCP_POS].request = 0;
            newFrame->storeNodeGroupInfo(&node_group_info_isp, PERFRAME_INFO_ISP);

            m_previewFrameFactory->dump();

            /* when preview buffer is not ready, we should drop preview to make preview buffer ready */
            m_exynosCameraParameters->setFrameSkipCount(3);
        }
        /*check preview drop...*/

        m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCP);
        m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCP);

        m_scpFrameCount++;
        break;
    default:
        break;
    }

    ret = frame->setEntityState(entity->getPipeId(), ENTITY_STATE_COMPLETE);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setEntityState fail, pipeId(%d), state(%d), ret(%d)",
            __FUNCTION__, __LINE__, entity->getPipeId(), ENTITY_STATE_COMPLETE, ret);
        return ret;
    }

    return NO_ERROR;
}

bool ExynosCameraHWImpl::m_previewThreadFunc(void)
{
#ifdef DEBUG
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
#endif

    int  ret  = 0;
    bool loop = false;
    int  pipeId    = 0;
    int  pipeIdCsc = 0;
    int  maxbuffers   = 0;

    ExynosCameraBuffer buffer;
    ExynosCameraFrame  *frame = NULL;
    nsecs_t timeStamp = 0;
    int frameCount = -1;
    frame_queue_t *previewQ;

    if (getCameraId() == CAMERA_ID_BACK) {
        pipeId    = PIPE_SCP;
        pipeIdCsc = PIPE_GSC;
        previewQ = m_previewQ;
    } else {
        pipeId    = PIPE_SCP_FRONT;
        pipeIdCsc = PIPE_GSC_FRONT;
        previewQ = m_previewFrontQ;
    }

    ALOGV("INFO(%s[%d]):wait previewQ", __FUNCTION__, __LINE__);
    ret = previewQ->waitAndPopProcessQ(&frame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        ret = INVALID_OPERATION;
        goto func_exit;
    }
    if (frame == NULL) {
        ALOGE("ERR(%s[%d]):frame is NULL", __FUNCTION__, __LINE__);
        ret = INVALID_OPERATION;
        goto func_exit;
    }

    ALOGV("INFO(%s[%d]):get frame from previewQ", __FUNCTION__, __LINE__);
    timeStamp = (nsecs_t)frame->getTimeStamp();
    frameCount = frame->getFrameCount();
    ret = frame->getDstBuffer(pipeId, &buffer);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):getDstBuffer fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        /* TODO: doing exception handling */
        goto func_exit;
    }
    /* ------------- frome here "frame" cannot use ------------- */
    ALOGV("INFO(%s[%d]):push frame to previewReturnQ", __FUNCTION__, __LINE__);
    if( m_exynosCameraParameters->getShotMode() == SHOT_MODE_BEAUTY_FACE ) {
        maxbuffers = m_exynosCameraParameters->getPreviewBufferCount();

    } else {
        maxbuffers = (int)m_exynosconfig->current->bufInfo.num_preview_buffers;
    }

    if (buffer.index < 0 || buffer.index >= maxbuffers ) {
        ALOGE("ERR(%s[%d]):Out of Index! (Max: %d, Index: %d)", __FUNCTION__, __LINE__, maxbuffers, buffer.index);
        goto func_exit;
    }

    ALOGV("INFO(%s[%d]):m_previewQ->getSizeOfProcessQ(%d) m_scpBufferMgr->getNumOfAvailableBuffer(%d)", __FUNCTION__, __LINE__,
        previewQ->getSizeOfProcessQ(), m_scpBufferMgr->getNumOfAvailableBuffer());

    if ((m_recordingEnabled == true) ||
        (m_exynosCameraParameters->getPreviewBufferCount() == NUM_PREVIEW_BUFFERS + NUM_PREVIEW_SPARE_BUFFERS &&
        m_scpBufferMgr->getNumOfAvailableAndNoneBuffer() > 4 &&
        previewQ->getSizeOfProcessQ() < 2) ||
        (m_exynosCameraParameters->getPreviewBufferCount() == NUM_PREVIEW_BUFFERS &&
        m_scpBufferMgr->getNumOfAvailableAndNoneBuffer() > 2 &&
        previewQ->getSizeOfProcessQ() < 1)) {
        if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_PREVIEW_FRAME) &&
            m_highResolutionCallbackRunning == false) {
            ExynosCameraBuffer previewCbBuffer;

            ret = m_setPreviewCallbackBuffer();
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):m_setPreviewCallback Buffer fail", __FUNCTION__, __LINE__);
                return ret;
            }

            int bufIndex = -2;
            m_previewCallbackBufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, &previewCbBuffer);

            ExynosCameraFrame  *newFrame = NULL;

            newFrame = m_previewFrameFactory->createNewFrameOnlyOnePipe(pipeIdCsc);
            if (newFrame == NULL) {
                ALOGE("ERR(%s):newFrame is NULL", __FUNCTION__);
                return UNKNOWN_ERROR;
            }

            ret = m_doPreviewToCallbackFunc(pipeIdCsc, newFrame, buffer, previewCbBuffer);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):m_doPreviewToCallbackFunc fail", __FUNCTION__, __LINE__);
            } else {
                if (m_exynosCameraParameters->getCallbackNeedCopy2Rendering() == true) {
                    ret = m_doCallbackToPreviewFunc(pipeIdCsc, frame, previewCbBuffer, buffer);
                    if (ret < 0)
                        ALOGE("ERR(%s[%d]):m_doCallbackToPreviewFunc fail", __FUNCTION__, __LINE__);
                }
            }

            m_previewCallbackBufferMgr->putBuffer(bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_NONE);
        }

    if (m_previewWindow != NULL) {
        if (timeStamp > 0L) {
            m_previewWindow->set_timestamp(m_previewWindow, (int64_t)timeStamp);
        } else {
            uint32_t fcount = 0;
            getStreamFrameCount((struct camera2_stream *)buffer.addr[2], &fcount);
            ALOGW("WRN(%s[%d]): frameCount(%d)(%d), Invalid timeStamp(%lld)",
                    __FUNCTION__, __LINE__,
                    frameCount,
                    fcount,
                    timeStamp);
        }

        /* display the frame */
        ret = m_putBuffers(m_scpBufferMgr, buffer.index);
        if (ret < 0) {
            /* TODO: error handling */
            ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
        }
    }
    } else {

        ret = m_scpBufferMgr->cancelBuffer(buffer.index);
    }

func_exit:

    if (frame != NULL) {
        delete frame;
        frame = NULL;
    }

    if (previewQ->getSizeOfProcessQ() > 0)
        loop = true;

    return loop;
}

status_t ExynosCameraHWImpl::m_setCallbackBufferInfo(ExynosCameraBuffer *callbackBuf, char *baseAddr)
{
    /*
     * If it is not 16-aligend, shrink down it as 16 align. ex) 1080 -> 1072
     * But, memory is set on Android format. so, not aligned area will be black.
     */
    int dst_width = 0, dst_height = 0, dst_crop_width = 0, dst_crop_height = 0;
    int dst_format = m_exynosCameraParameters->getPreviewFormat();

    m_exynosCameraParameters->getPreviewSize(&dst_width, &dst_height);
    dst_crop_width = dst_width;
    dst_crop_height = dst_height;

    if (dst_format == V4L2_PIX_FMT_NV21 ||
        dst_format == V4L2_PIX_FMT_NV21M) {

        callbackBuf->size[0] = (dst_width * dst_height);
        callbackBuf->size[1] = (dst_width * dst_height) / 2;

        callbackBuf->addr[0] = baseAddr;
        callbackBuf->addr[1] = callbackBuf->addr[0] + callbackBuf->size[0];
    } else if (dst_format == V4L2_PIX_FMT_YVU420 ||
               dst_format == V4L2_PIX_FMT_YVU420M) {
        callbackBuf->size[0] = dst_width * dst_height;
        callbackBuf->size[1] = dst_width / 2 * dst_height / 2;
        callbackBuf->size[2] = callbackBuf->size[1];

        callbackBuf->addr[0] = baseAddr;
        callbackBuf->addr[1] = callbackBuf->addr[0] + callbackBuf->size[0];
        callbackBuf->addr[2] = callbackBuf->addr[1] + callbackBuf->size[1];
    }

    ALOGV("DEBUG(%s): preview size(%dx%d)", __FUNCTION__, hwPreviewW, hwPreviewH);
    ALOGV("DEBUG(%s): dst_size(%dx%d), dst_crop_size(%dx%d)", __FUNCTION__, dst_width, dst_height, dst_crop_width, dst_crop_height);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_doPreviewToCallbackFunc(
        int32_t pipeId,
        ExynosCameraFrame *newFrame,
        ExynosCameraBuffer previewBuf,
        ExynosCameraBuffer callbackBuf)
{
    ALOGV("DEBUG(%s): converting preview to callback buffer", __FUNCTION__);

    int ret = 0;
    status_t statusRet = NO_ERROR;

    int hwPreviewW = 0, hwPreviewH = 0;
    int hwPreviewFormat = m_exynosCameraParameters->getHwPreviewFormat();
    bool useCSC = m_exynosCameraParameters->getCallbackNeedCSC();

    ExynosCameraDurationTimer probeTimer;
    int probeTimeMSEC;
    uint32_t fcount = 0;

    m_exynosCameraParameters->getHwPreviewSize(&hwPreviewW, &hwPreviewH);

    ExynosRect srcRect, dstRect;

    camera_memory_t *previewCallbackHeap = NULL;
    previewCallbackHeap = m_getMemoryCb(callbackBuf.fd[0], callbackBuf.size[0], 1, m_callbackCookie);

    ret = m_setCallbackBufferInfo(&callbackBuf, (char *)previewCallbackHeap->data);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): setCallbackBufferInfo fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        statusRet = INVALID_OPERATION;
        goto done;
    }

    ret = m_calcPreviewGSCRect(&srcRect, &dstRect);

    if (useCSC) {
        frame_queue_t gscFrameDoneQ;

        ret = newFrame->setSrcRect(pipeId, &srcRect);
        ret = newFrame->setDstRect(pipeId, &dstRect);

        ret = m_setupEntity(pipeId, newFrame, &previewBuf, &callbackBuf);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):setupEntity fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, pipeId, ret);
            statusRet = INVALID_OPERATION;
            goto done;
        }
        m_previewFrameFactory->pushFrameToPipe(&newFrame, pipeId);
        m_previewFrameFactory->setOutputFrameQToPipe(&gscFrameDoneQ, pipeId);

        ALOGV("INFO(%s[%d]):wait preview callback output", __FUNCTION__, __LINE__);
        ret = gscFrameDoneQ.waitAndPopProcessQ(&newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            /* TODO: doing exception handling */
            statusRet = INVALID_OPERATION;
            goto done;
        }
        if (newFrame == NULL) {
            ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
            statusRet = INVALID_OPERATION;
            goto done;
        }
        ALOGV("INFO(%s[%d]):preview callback done", __FUNCTION__, __LINE__);

#if 0
        int remainedH = m_orgPreviewRect.h - dst_height;

        if (remainedH != 0) {
            char *srcAddr = NULL;
            char *dstAddr = NULL;
            int planeDiver = 1;

            for (int plane = 0; plane < 2; plane++) {
                planeDiver = (plane + 1) * 2 / 2;

                srcAddr = previewBuf.virt.extP[plane] + (ALIGN_UP(hwPreviewW, CAMERA_ISP_ALIGN) * dst_crop_height / planeDiver);
                dstAddr = callbackBuf->virt.extP[plane] + (m_orgPreviewRect.w * dst_crop_height / planeDiver);

                for (int i = 0; i < remainedH; i++) {
                    memcpy(dstAddr, srcAddr, (m_orgPreviewRect.w / planeDiver));

                    srcAddr += (ALIGN_UP(hwPreviewW, CAMERA_ISP_ALIGN) / planeDiver);
                    dstAddr += (m_orgPreviewRect.w                   / planeDiver);
                }
            }
        }
#endif
    } else { /* neon memcpy */
        char *srcAddr = NULL;
        char *dstAddr = NULL;
        int planeCount = getYuvPlaneCount(hwPreviewFormat);
        if (planeCount <= 0) {
            ALOGE("ERR(%s[%d]):getYuvPlaneCount(%d) fail", __FUNCTION__, __LINE__, hwPreviewFormat);
            statusRet = INVALID_OPERATION;
            goto done;
        }

        /* TODO : have to consider all fmt(planes) and stride */
        for (int plane = 0; plane < planeCount; plane++) {
            srcAddr = previewBuf.addr[plane];
            dstAddr = callbackBuf.addr[plane];
            memcpy(dstAddr, srcAddr, callbackBuf.size[plane]);
        }
    }

    probeTimer.start();
    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_PREVIEW_FRAME)) {
        setBit(&m_callbackState, CALLBACK_STATE_PREVIEW_FRAME, false);
        m_dataCb(CAMERA_MSG_PREVIEW_FRAME, previewCallbackHeap, 0, NULL, m_callbackCookie);
        clearBit(&m_callbackState, CALLBACK_STATE_PREVIEW_FRAME, false);
    }
    probeTimer.stop();
    getStreamFrameCount((struct camera2_stream *)previewBuf.addr[2], &fcount);
    probeTimeMSEC = (int)probeTimer.durationMsecs();

    if (probeTimeMSEC > 33 && probeTimeMSEC <= 66)
        ALOGV("(%s[%d]):(%d) %5d ", __FUNCTION__, __LINE__, fcount, (int)probeTimer.durationMsecs());
    else if(probeTimeMSEC > 66)
        ALOGE("(%s[%d]):(%d) %5d ", __FUNCTION__, __LINE__, fcount, (int)probeTimer.durationMsecs());
    else
        ALOGV("(%s[%d]):(%d) %5d ", __FUNCTION__, __LINE__, fcount, (int)probeTimer.durationMsecs());

done:
    previewCallbackHeap->release(previewCallbackHeap);

    return statusRet;
}

status_t ExynosCameraHWImpl::m_doCallbackToPreviewFunc(
        int32_t pipeId,
        ExynosCameraFrame *newFrame,
        ExynosCameraBuffer callbackBuf,
        ExynosCameraBuffer previewBuf)
{
    ALOGV("DEBUG(%s): converting callback to preview buffer", __FUNCTION__);

    int ret = 0;
    status_t statusRet = NO_ERROR;

    int hwPreviewW = 0, hwPreviewH = 0;
    int hwPreviewFormat = m_exynosCameraParameters->getHwPreviewFormat();
    int previewFormat = m_secCamera->getPreviewFormat();//****************//
    bool useCSC = m_exynosCameraParameters->getCallbackNeedCSC();

    m_exynosCameraParameters->getHwPreviewSize(&hwPreviewW, &hwPreviewH);

    camera_memory_t *previewCallbackHeap = NULL;
    previewCallbackHeap = m_getMemoryCb(callbackBuf.fd[0], callbackBuf.size[0], 1, m_callbackCookie);

    ret = m_setCallbackBufferInfo(&callbackBuf, (char *)previewCallbackHeap->data);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): setCallbackBufferInfo fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        statusRet = INVALID_OPERATION;
        goto done;
    }
/***********************************************************************************/
    if (m_secCamera->getPreviewSize(&previewW, &previewH) == false) {
        CLOGE("ERR(%s):Fail to getPreviewSize", __func__);
        return false;
    }
/**********************************************************************************/

    if (useCSC) {
        if (m_exynosPreviewCSC) {
            csc_set_src_format(m_exynosPreviewCSC,
                    ALIGN_DOWN(m_orgPreviewRect.w, CAMERA_MAGIC_ALIGN), ALIGN_DOWN(m_orgPreviewRect.h, CAMERA_MAGIC_ALIGN),
                    0, 0, ALIGN_DOWN(m_orgPreviewRect.w, CAMERA_MAGIC_ALIGN), ALIGN_DOWN(m_orgPreviewRect.h, CAMERA_MAGIC_ALIGN),
                    V4L2_PIX_2_HAL_PIXEL_FORMAT(m_orgPreviewRect.colorFormat),
                    1);

            csc_set_dst_format(m_exynosPreviewCSC,
                    previewW, previewH,
                    0, 0, previewW, previewH,
                    V4L2_PIX_2_HAL_PIXEL_FORMAT(previewFormat),
                    0);

            csc_set_src_buffer(m_exynosPreviewCSC,
                    (void **)callbackBuf->virt.extP, CSC_MEMORY_USERPTR);

            csc_set_dst_buffer(m_exynosPreviewCSC,
                    (void **)previewBuf.fd.extFd, CSC_MEMORY_TYPE);

            if (csc_convert_with_rotation(m_exynosPreviewCSC, 0, m_flip_horizontal, 0) != 0)
                ALOGE("ERR(%s):csc_convert() from callback to lcd fail", __FUNCTION__);
            if (csc_convert(m_exynosPreviewCSC) != 0)
                CLOGE("ERR(%s):csc_convert() from callback to lcd fail", __func__);
        } else {
            ALOGE("ERR(%s):m_exynosPreviewCSC == NULL", __FUNCTION__);
        }
    } else { /* neon memcpy */
        char *srcAddr = NULL;
        char *dstAddr = NULL;
        int planeCount = getYuvPlaneCount(hwPreviewFormat);
        if (planeCount <= 0) {
            ALOGE("ERR(%s[%d]):getYuvPlaneCount(%d) fail", __FUNCTION__, __LINE__, hwPreviewFormat);
            statusRet = INVALID_OPERATION;
            goto done;
        }

        /* TODO : have to consider all fmt(planes) and stride */
        for (int plane = 0; plane < planeCount; plane++) {
            srcAddr = callbackBuf.addr[plane];
            dstAddr = previewBuf.addr[plane];
            memcpy(dstAddr, srcAddr, callbackBuf.size[plane]);
        }
        /* TODO : have to consider all fmt(planes) and stride */
        /*
        for (int plane = 0; plane < 2; plane++) {
            srcAddr = callbackBuf->virt.extP[plane];
            dstAddr = previewBuf.virt.extP[plane];
            memcpy(dstAddr, srcAddr, callbackBuf->size.extS[plane]);
        }
        */
    }

done:
    previewCallbackHeap->release(previewCallbackHeap);

    return statusRet;
}

bool ExynosCameraHWImpl::m_videoThreadFuncWrapper(void)
{
    while (1) {
        while (m_recordingEnabled == false) {
            m_videoLock.lock();

#ifdef USE_3DNR_DMAOUT
            if (   m_secCamera->flagStartVideo() == true
                && m_secCamera->stopVideo() == false)
                CLOGE("ERR(%s):Fail on m_secCamera->stopVideo()", __func__);
#endif
            m_releaseVideoQ();

            CLOGD("DEBUG(%s:%d): SIGNAL(m_videoStoppedCondition) - send", __func__, __LINE__);
            m_videoStoppedCondition.signal();
            CLOGD("DEBUG(%s:%d): SIGNAL(m_videoCondition) - waiting", __func__, __LINE__);
            m_videoCondition.wait(m_videoLock);
            CLOGD("DEBUG(%s:%d): SIGNAL(m_videoCondition) - recevied", __func__, __LINE__);

            m_videoLock.unlock();
        }

        if (m_exitVideoThread == true) {
            CLOGD("DEBUG(%s:%d):m_exitVideoThread == true", __func__, __LINE__);
            m_videoLock.lock();

#ifdef USE_3DNR_DMAOUT
            if (   m_secCamera->flagStartVideo() == true
                && m_secCamera->stopVideo() == false)
                CLOGE("ERR(%s):Fail on m_secCamera->stopVideo()", __func__);
#endif
            m_releaseVideoQ();

            m_videoLock.unlock();
            return true;
        }

        /* waiting for preview thread */
        if (m_sizeOfVideoQ() == 0) {
            m_videoLock.lock();
            CLOGV("DEBUG(%s:%d): SIGNAL(m_videoCondition) - waiting", __func__, __LINE__);
            m_videoCondition.wait(m_videoLock);
            CLOGV("DEBUG(%s:%d): SIGNAL(m_videoCondition) - recevied", __func__, __LINE__);
            m_videoLock.unlock();
        }

        m_videoThreadFunc();
    }
    return true;
}

bool ExynosCameraHWImpl::m_videoThreadFunc(void)
{
    nsecs_t timestamp;
    struct addrs *addrs;
    ExynosBuffer videoBuf;
    int recordingFrameIndex = 0;

    static int cbcnt = 0;
    int waitCnt = 0;

    if ((m_enabledMsgType & CAMERA_MSG_VIDEO_FRAME) &&
        (m_recordingEnabled == true)) {

        if (m_popVideoQ(&videoBuf) == false) {
            /* CLOGV("DEBUG(%s:%d):m_popVideoQ() false", __func__, __LINE__); */
            return true;
        }

        timestamp = m_videoBufTimestamp[videoBuf.reserved.p];
        m_videoBufTimestamp[videoBuf.reserved.p] = 1;

#ifdef USE_3DNR_DMAOUT
        if (m_secCamera->getVideoBuf(&videoBuf) == false) {
            CLOGE("ERR(%s):Fail on ExynosCamera->getVideoBuf()", __func__);
            return false;
        }
#else
        while (m_availableRecordingFrameCnt == 0) {
            usleep(200);
            waitCnt++;
            if (waitCnt > 1000) {
                CLOGE("ERR(%s):videoThread Timeout", __func__);
                return true;
            }
        }

        recordingFrameIndex = m_getRecordingFrame();
        if (recordingFrameIndex == -1) {
            CLOGD("DEBUG(%s:%d): m_getRecordingFrame() is %d", __func__, __LINE__, recordingFrameIndex);
            return true;
        }

        videoBuf.reserved.p = recordingFrameIndex;
#endif

        /* Notify the client of a new frame. */
        if ((m_enabledMsgType & CAMERA_MSG_VIDEO_FRAME) &&
            (m_recordingEnabled == true)) {

            /* resize from videoBuf(max size) to m_videoHeap(user's set size) */
            if (m_exynosVideoCSC) {
                int videoW, videoH, videoFormat = 0;
                int cropX, cropY, cropW, cropH = 0;

                int previewW, previewH, previewFormat = 0;
                previewFormat = m_secCamera->getPreviewFormat();
                m_secCamera->getPreviewSize(&previewW, &previewH);

                videoFormat = m_secCamera->getVideoFormat();
                m_secCamera->getVideoSize(&videoW, &videoH);

                m_secCamera->getCropRectAlign(previewW, previewH,
                                         m_orgVideoRect.w, m_orgVideoRect.h,
                                         &cropX, &cropY,
                                         &cropW, &cropH,
                                         2, 2,
                                         0);

                CLOGV("DEBUG(%s):cropX = %d, cropY = %d, cropW = %d, cropH = %d",
                         __func__, cropX, cropY, cropW, cropH);

#ifdef USE_3DNR_DMAOUT
                csc_set_src_format(m_exynosVideoCSC,
                                   videoW, videoH,
                                   cropX, cropY, cropW, cropH,
                                   V4L2_PIX_2_HAL_PIXEL_FORMAT(videoFormat),
                                   0);
#else
                csc_set_src_format(m_exynosVideoCSC,
                                   previewW, previewH,
                                   cropX, cropY, cropW, cropH,
                                   V4L2_PIX_2_HAL_PIXEL_FORMAT(previewFormat),
                                   0);
#endif

                csc_set_dst_format(m_exynosVideoCSC,
                                   m_orgVideoRect.w, m_orgVideoRect.h,
                                   0, 0, m_orgVideoRect.w, m_orgVideoRect.h,
                                   V4L2_PIX_2_HAL_PIXEL_FORMAT(videoFormat),
                                   0);

                csc_set_src_buffer(m_exynosVideoCSC,
                                   (void **)videoBuf.fd.extFd, CSC_MEMORY_TYPE);

                ExynosBuffer dstBuf;
                m_getAlignedYUVSize(videoFormat, m_orgVideoRect.w, m_orgVideoRect.h, &dstBuf);

                dstBuf.virt.extP[0] = (char *)m_resizedVideoHeap[videoBuf.reserved.p][0]->data;
                dstBuf.virt.extP[1] = (char *)m_resizedVideoHeap[videoBuf.reserved.p][1]->data;

                dstBuf.fd.extFd[0] = m_resizedVideoHeapFd[videoBuf.reserved.p][0];
                dstBuf.fd.extFd[1] = m_resizedVideoHeapFd[videoBuf.reserved.p][1];

                csc_set_dst_buffer(m_exynosVideoCSC,
                                  (void **)dstBuf.fd.extFd, CSC_MEMORY_TYPE);

                if (csc_convert(m_exynosVideoCSC) != 0)
                    CLOGE("ERR(%s):csc_convert() fail", __func__);

                CLOGV("DEBUG(%s): Camera Meta addrs %d",__func__, recordingFrameIndex);
                addrs = (struct addrs *)m_recordingCallbackHeap->data;
                addrs[recordingFrameIndex].type      = kMetadataBufferTypeCameraSource;
                addrs[recordingFrameIndex].fdPlaneY      = (unsigned int)dstBuf.fd.extFd[0];
                addrs[recordingFrameIndex].fdPlaneCbcr   = (unsigned int)dstBuf.fd.extFd[1];
                addrs[recordingFrameIndex].bufIndex = recordingFrameIndex;
            } else {
                CLOGE("ERR(%s):m_exynosVideoCSC == NULL", __func__);
            }

#ifdef CHECK_TIME_RECORDING
            m_checkRecordingTime();
#endif

            if ((0L < timestamp) && (m_lastRecordingTimestamp < timestamp) && (m_recordingStartTimestamp < timestamp)) {
                if ((m_enabledMsgType & CAMERA_MSG_VIDEO_FRAME) && (m_recordingEnabled == true)) {

                    CLOGV("DEBUG(%s):timestamp(%d msec), curTime(%d msec)",
                        __func__,
                        (int)(timestamp) / (1000 * 1000),
                        (int)(systemTime(SYSTEM_TIME_MONOTONIC)) / (1000 * 1000));

                    m_dataCbTimestamp(timestamp, CAMERA_MSG_VIDEO_FRAME,
                                      m_recordingCallbackHeap, recordingFrameIndex, m_callbackCookie);

                    m_lastRecordingTimestamp = timestamp;
                }
            } else {
                CLOGW("WRN(%s): timestamp(%lld) invaild - last timestamp(%lld) systemtime(%lld) recordStart(%lld)",
                    __func__, timestamp, m_lastRecordingTimestamp, systemTime(SYSTEM_TIME_MONOTONIC), m_recordingStartTimestamp);
                m_freeRecordingFrame(recordingFrameIndex);
            }
        }

#ifdef USE_3DNR_DMAOUT
        m_secCamera->putVideoBuf(&videoBuf);

        m_pushVideoQ(&videoBuf);
#endif
        // until here
    } else
        usleep(1000); // sleep 1msec for stopRecording

    return true;
}

status_t ExynosCameraHWImpl::m_handlePreviewFrameFront(ExynosCameraFrame *frame)
{
    int ret = 0;
    int frameSkipCount = 0;
    ExynosCameraFrameEntity *entity = NULL;
    ExynosCameraFrame *newFrame = NULL;
    ExynosCameraBuffer buffer;
    int pipeID = 0;
    ExynosCameraBuffer resultBuffer;
    camera2_node_group node_group_info_isp;

    entity = frame->getFrameDoneEntity();
    if (entity == NULL) {
        ALOGE("ERR(%s[%d]):current entity is NULL, frameCount(%d)",
            __FUNCTION__, __LINE__, frame->getFrameCount());
        /* TODO: doing exception handling */
        return true;
    }

    pipeID = entity->getPipeId();

    switch(entity->getPipeId()) {
    case PIPE_ISP_FRONT:
        m_debugFpsCheck(entity->getPipeId());
        ret = frame->getSrcBuffer(entity->getPipeId(), &buffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getSrcBuffer fail, pipeId(%d), ret(%d)",
                __FUNCTION__, __LINE__, entity->getPipeId(), ret);
            return ret;
        }

        frame->setMetaDataEnable(true);

//        if (isReprocessing() == true && m_exynosCameraParameters->getSeriesShotCount() == 0 &&
//                frame->getRequest(PIPE_SCC) == false && m_hdrEnabled == false) {
        if (isReprocessing() == true) {
            ret = m_captureSelector->manageFrameHoldList(frame, pipeID, true);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):manageFrameHoldList fail", __FUNCTION__, __LINE__);
                return ret;
            }
        } else {
            /* TODO: This is unusual case, flite buffer and isp buffer */
            ret = m_putBuffers(m_bayerBufferMgr, buffer.index);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
            }
        }

        ret = m_putBuffers(m_ispBufferMgr, buffer.index);

        /* Face detection */
        ret = m_doFdCallbackFunc(frame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_doFdCallbackFunc fail, ret(%d)",
                    __FUNCTION__, __LINE__, ret);
            return ret;
        }

        ret = generateFrame(m_3aa_ispFrameCount, &newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
            return ret;
        }

        m_setupEntity(PIPE_FLITE_FRONT, newFrame);
        m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_FLITE_FRONT);

        m_setupEntity(PIPE_3AA_FRONT, newFrame);
        m_setupEntity(PIPE_ISP_FRONT, newFrame);
        m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_ISP_FRONT);

        m_3aa_ispFrameCount++;

        /* HACK: When SCC pipe is stopped, generate frame for SCC */
        if ((m_sccBufferMgr->getNumOfAvailableBuffer() > 2)) {
            ALOGW("WRN(%s[%d]): Too many available SCC buffers, generating frame for SCC", __FUNCTION__, __LINE__);
            while (m_sccBufferMgr->getNumOfAvailableBuffer() > 0) {
                ret = generateFrame(m_sccFrameCount, &newFrame);
                if (ret < 0) {
                    ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
                    return ret;
                }

                m_setupEntity(PIPE_SCC_FRONT, newFrame);
                m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCC_FRONT);
                m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCC_FRONT);

                m_sccFrameCount++;
            }
        }

        break;
    case PIPE_SCC_FRONT:
        m_debugFpsCheck(entity->getPipeId());
        if (entity->getDstBufState() == ENTITY_BUFFER_STATE_COMPLETE) {
            ret = m_sccCaptureSelector->manageFrameHoldList(frame, entity->getPipeId(), false);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):manageFrameHoldList fail", __FUNCTION__, __LINE__);
                return ret;
            }
        }

        while (m_sccBufferMgr->getNumOfAvailableBuffer() > 0) {
            ret = generateFrame(m_sccFrameCount, &newFrame);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
                return ret;
            }

            m_setupEntity(PIPE_SCC_FRONT, newFrame);
            m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCC_FRONT);
            m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCC_FRONT);

            m_sccFrameCount++;
        }
        break;
    case PIPE_SCP_FRONT:
        if (entity->getDstBufState() == ENTITY_BUFFER_STATE_COMPLETE) {
            m_debugFpsCheck(entity->getPipeId());
            ret = frame->getDstBuffer(entity->getPipeId(), &buffer);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, entity->getPipeId(), ret);
                return ret;
            }

            m_exynosCameraParameters->getFrameSkipCount(&frameSkipCount);
            if (frameSkipCount > 0) {
                ALOGD("INFO(%s[%d]):frameSkipCount=%d", __FUNCTION__, __LINE__, frameSkipCount);
                ret = m_scpBufferMgr->cancelBuffer(buffer.index);
            } else {
                nsecs_t timeStamp = (nsecs_t)frame->getTimeStamp();
                m_recordingStateLock.lock();
                if (m_recordingEnabled == true
                    && m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_VIDEO_FRAME)) {
                    if (timeStamp <= 0L) {
                        ALOGE("WARN(%s[%d]):timeStamp(%lld) Skip", __FUNCTION__, __LINE__, timeStamp);
                    } else {
                        /* get Recording Image buffer */
                        int bufIndex = -2;
                        ExynosCameraBuffer recordingBuffer;
                        ret = m_recordingBufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, &recordingBuffer);
                        if (ret < 0 || bufIndex < 0) {
                            if ((++m_recordingFrameSkipCount % 100) == 0) {
                                ALOGE("ERR(%s[%d]): Recording buffer is not available!! Recording Frames are Skipping(%d frames) (bufIndex=%d)",
                                        __FUNCTION__, __LINE__, m_recordingFrameSkipCount, bufIndex);
                            }
                        } else {
                            if (m_recordingFrameSkipCount != 0) {
                                ALOGE("ERR(%s[%d]): Recording buffer is not available!! Recording Frames are Skipped(%d frames) (bufIndex=%d)",
                                        __FUNCTION__, __LINE__, m_recordingFrameSkipCount, bufIndex);
                                m_recordingFrameSkipCount = 0;
                            }
                            m_recordingTimeStamp[bufIndex] = timeStamp;
                            ret = m_doPrviewToRecordingFunc(PIPE_GSC_VIDEO_FRONT, buffer, recordingBuffer);
                            if (ret < 0) {
                                ALOGW("WARN(%s[%d]):recordingCallback Skip", __FUNCTION__, __LINE__);
                            }
                        }
                    }
                }
                m_recordingStateLock.unlock();

                ExynosCameraBuffer callbackBuffer;
                ExynosCameraFrame *callbackFrame = NULL;
                struct camera2_shot_ext *shot_ext = new struct camera2_shot_ext;

                callbackFrame = m_previewFrameFactory->createNewFrameOnlyOnePipe(PIPE_SCP_FRONT);
                frame->getDstBuffer(PIPE_SCP_FRONT, &callbackBuffer);
                frame->getMetaData(shot_ext);
                callbackFrame->storeDynamicMeta(shot_ext);
                callbackFrame->setDstBuffer(PIPE_SCP_FRONT, callbackBuffer);
                delete shot_ext;

                ALOGV("INFO(%s[%d]):push frame to front previewQ", __FUNCTION__, __LINE__);
                m_previewFrontQ->pushProcessQ(&callbackFrame);

                ALOGV("DEBUG(%s[%d]):SCP done HAL-frameCount(%d)", __FUNCTION__, __LINE__, frame->getFrameCount());
            }
        } else {
            ALOGV("DEBUG(%s[%d]):SCP droped - SCP buffer is not ready HAL-frameCount(%d)", __FUNCTION__, __LINE__, frame->getFrameCount());
            m_previewFrameFactory->dump();
        }

        ret = generateFrame(m_scpFrameCount, &newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):generateFrame fail", __FUNCTION__, __LINE__);
            return ret;
        }

        m_setupEntity(PIPE_SCP_FRONT, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):setupEntity fail", __FUNCTION__, __LINE__);
            break;
        }

        /*check preview drop...*/
        newFrame->getDstBuffer(PIPE_SCP_FRONT, &resultBuffer);
        if (resultBuffer.index < 0) {
           newFrame->setRequest(PIPE_SCP_FRONT, false);
           newFrame->getNodeGroupInfo(&node_group_info_isp, PERFRAME_INFO_ISP);
           node_group_info_isp.capture[PERFRAME_FRONT_SCP_POS].request = 0;
           newFrame->storeNodeGroupInfo(&node_group_info_isp, PERFRAME_INFO_ISP);

           m_previewFrameFactory->dump();

           /* when preview buffer is not ready, we should drop preview to make preview buffer ready */
           m_exynosCameraParameters->setFrameSkipCount(3);
        }

        m_previewFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCP_FRONT);
        m_previewFrameFactory->setOutputFrameQToPipe(m_pipeFrameDoneQ, PIPE_SCP_FRONT);

        m_scpFrameCount++;
        break;
    default:
        break;
    }

    if (ret < 0) {
        ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
        return ret;
    }

    ret = frame->setEntityState(entity->getPipeId(), ENTITY_STATE_COMPLETE);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setEntityState fail, pipeId(%d), state(%d), ret(%d)",
            __FUNCTION__, __LINE__, entity->getPipeId(), ENTITY_STATE_COMPLETE, ret);
        return ret;
    }

    return NO_ERROR;
}

bool ExynosCameraHWImpl::m_setBuffersThreadFunc(void)
{
    int ret = 0;

    ret = m_setBuffers();
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_setBuffers failed", __FUNCTION__, __LINE__);

        /* TODO: Need release buffers and error exit */

        return false;
    }

    return false;
}

bool ExynosCameraHWImpl::m_startPictureInternalThreadFunc(void)
{
    int ret = 0;

    ret = m_startPictureInternal();
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_setBuffers failed", __FUNCTION__, __LINE__);

        /* TODO: Need release buffers and error exit */

        return false;
    }

    return false;
}

bool ExynosCameraHWImpl::m_prePictureThreadFunc(void)
{
    bool loop = false;
    bool isProcessed = true;

    ExynosCameraDurationTimer m_burstPrePictureTimer;
    uint64_t m_burstPrePictureTimerTime;
    status_t ret = NO_ERROR;

    uint64_t seriesShotDuration = m_exynosCameraParameters->getSeriesShotDuration();

    // Minimum guaranted delay between shot for burst case
    uint64_t subDuration = 0;
    if (m_exynosCameraParameters->getSeriesShotMode() == SERIES_SHOT_MODE_BURST) {
        subDuration = seriesShotDuration > 0 ? seriesShotDuration / 4 : 0;
    }

    if (m_isNeedAllocPictureBuffer == true) {

        /* alloc gsc/jpeg buffer */
        ret = m_setPictureBuffer();
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): set picture buffer fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            return UNKNOWN_ERROR;
        }
        ALOGD("DEBUG(%s[%d]): Deferred allocation of JPEG/GSC buffer completed.", __FUNCTION__, __LINE__);
        m_isNeedAllocPictureBuffer = false;
    }

    m_burstPrePictureTimer.start();

//    if (isReprocessing() && m_exynosCameraParameters->getSeriesShotCount() == 0 &&
//            m_hdrEnabled == false)
    if (isReprocessing())
        loop = m_reprocessingPrePictureInternal();
    else
        loop = m_prePictureInternal(&isProcessed);

    m_burstPrePictureTimer.stop();
    m_burstPrePictureTimerTime = m_burstPrePictureTimer.durationUsecs();

    if(isProcessed == false) {
        // HACK: If m_prePictureInternal reported frame processing failure, do not wait on the while loop.
        m_burstPrePictureTimerTime = seriesShotDuration;
        ALOGD("DEBUG(%s[%d]): m_prePictureInternal failed to get frame.", __FUNCTION__, __LINE__);
    } else if(subDuration > 0 && m_burstPrePictureTimerTime > subDuration) {
        /*
         * HACK: Making the frame delay between shot is at least 3/4 of getSeriesShotDuration()
         *       to avoid large variance in interval between burst shot pictures.
         */
        ALOGD("DEBUG(%s[%d]): Remaining time for next shot is too short(%lld)ms. Extended to (%lld)ms"
            , __FUNCTION__, __LINE__, seriesShotDuration - m_burstPrePictureTimerTime, seriesShotDuration - subDuration);
        m_burstPrePictureTimerTime = subDuration;
    }

    while (seriesShotDuration > m_burstPrePictureTimerTime && m_reprocessingCounter.getCount() > 0) {
        ALOGD("DEBUG(%s[%d]): waiting next shot(%lld)", __FUNCTION__, __LINE__, seriesShotDuration - m_burstPrePictureTimerTime);
        m_burstPrePictureTimerTime += 10000;
        usleep(10000);
    }

    return loop;
}

/*
 * pIsProcessed : out parameter
 *                true if the frame is properly handled.
 *                false if frame processing is failed or there is no frame to process
 */
bool ExynosCameraHWImpl::m_prePictureInternal(bool* pIsProcessed)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
    ALOGI("DEBUG(%s[%d]):", __FUNCTION__, __LINE__);

    int ret = 0;
    bool loop = false;
    ExynosCameraFrame *newFrame = NULL;
    camera2_shot_ext *shot_ext = NULL;

    ExynosCameraBuffer fliteReprocessingBuffer;
    ExynosCameraBuffer ispReprocessingBuffer;

    int pipeId = 0;
    bool isSrc = false;
    int retryCount = 3;

    if (m_hdrEnabled)
        retryCount = 15;

    if (getCameraId() == CAMERA_ID_BACK)
        pipeId = PIPE_SCC;
    else
        pipeId = PIPE_SCC_FRONT;

    int postProcessQSize = m_postPictureQ->getSizeOfProcessQ();
    if (postProcessQSize > 2) {
        ALOGW("DEBUG(%s[%d]): post picture is delayed(stacked %d frames), skip", __FUNCTION__, __LINE__, postProcessQSize);
        usleep(WAITING_TIME);
        goto CLEAN;
    }

    newFrame = m_sccCaptureSelector->selectFrames(m_reprocessingCounter.getCount(), pipeId, isSrc, retryCount);
    if (newFrame == NULL) {
        ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
        goto CLEAN;
    }
    newFrame->frameLock();

    ALOGE("DEBUG(%s[%d]):Frame Count (%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());

    m_postProcessList.push_back(newFrame);
    dstSccReprocessingQ->pushProcessQ(&newFrame);

    m_reprocessingCounter.decCount();

    ALOGI("INFO(%s[%d]):prePicture complete, remaining count(%d)", __FUNCTION__, __LINE__, m_reprocessingCounter.getCount());

    if (m_hdrEnabled) {
        ExynosCameraActivitySpecialCapture *m_sCaptureMgr;

        m_sCaptureMgr = m_exynosCameraActivityControl->getSpecialCaptureMgr();

        if (m_reprocessingCounter.getCount() == 0)
            m_sCaptureMgr->setCaptureStep(ExynosCameraActivitySpecialCapture::SCAPTURE_STEP_OFF);
    }

    if (m_reprocessingCounter.getCount() > 0) {
        loop = true;
#if 0
    } else {
        if (m_exynosCameraParameters->getUseDynamicScc() == true) {
            ALOGD("DEBUG(%s[%d]): Use dynamic bayer", __FUNCTION__, __LINE__);
            m_previewFrameFactory->setRequestSCC(false);
        }
        m_sccCaptureSelector->clearList(pipeId, isSrc);
#endif
    }

    *pIsProcessed = true;
    return loop;

CLEAN:
    if (newFrame != NULL && newFrame->isComplete() == true) {
        newFrame->printEntity();
        ALOGD("DEBUG(%s[%d]): Picture frame delete(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());
        delete newFrame;
        newFrame = NULL;
    }

    if (m_hdrEnabled) {
        ExynosCameraActivitySpecialCapture *m_sCaptureMgr;

        m_sCaptureMgr = m_exynosCameraActivityControl->getSpecialCaptureMgr();

        if (m_reprocessingCounter.getCount() == 0)
            m_sCaptureMgr->setCaptureStep(ExynosCameraActivitySpecialCapture::SCAPTURE_STEP_OFF);
    }

    if (m_reprocessingCounter.getCount() > 0)
        loop = true;

    ALOGI("INFO(%s[%d]): prePicture fail, remaining count(%d)", __FUNCTION__, __LINE__, m_reprocessingCounter.getCount());
    *pIsProcessed = false;   // Notify failure
    return loop;

}

bool ExynosCameraHWImpl::m_reprocessingPrePictureInternal(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
    ALOGI("DEBUG(%s[%d]):", __FUNCTION__, __LINE__);

    int ret = 0;
    bool loop = false;
    int retry = 0;
    ExynosCameraFrame *newFrame = NULL;
    ExynosCameraFrameEntity *entity = NULL;
    camera2_shot_ext *shot_ext = NULL;
    camera2_stream *shot_stream = NULL;
    uint32_t bayerFrameCount = 0;
    struct camera2_node_output output_crop_info;

    ExynosCameraBufferManager *bufferMgr = NULL;

    int bayerPipeId = 0;
    ExynosCameraBuffer bayerBuffer;
    ExynosCameraBuffer ispReprocessingBuffer;

    bayerBuffer.index = -2;
    ispReprocessingBuffer.index = -2;

    if (m_exynosCameraParameters->getHighResolutionCallbackMode() == true) {
        if (m_highResolutionCallbackRunning == true) {
            /* will be removed */
            while (m_skipReprocessing == true) {
                usleep(WAITING_TIME);
                if (m_skipReprocessing == false) {
                    ALOGD("DEBUG(%s[%d]:stop skip frame for high resolution preview callback", __FUNCTION__, __LINE__);
                    break;
                }
            }
        } else if (m_highResolutionCallbackRunning == false) {
            ALOGW("WRN(%s[%d]): m_reprocessingThreadfunc stop for high resolution preview callback", __FUNCTION__, __LINE__);
            loop = false;
            goto CLEAN_FRAME;
        }
    }

    /* Get Bayer buffer for reprocessing */
    ret = m_getBayerBuffer(m_getBayerPipeId(), &bayerBuffer);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): getBayerBuffer fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        goto CLEAN_FRAME;
    }

    ALOGD("DEBUG(%s[%d]):bayerBuffer index %d", __FUNCTION__, __LINE__, bayerBuffer.index);

    if (m_exynosCameraParameters->getReprocessingBayerMode() == REPROCESSING_BAYER_MODE_DIRTY_DYNAMIC) {
        m_captureSelector->clearList(m_getBayerPipeId(), false);
    }

    /* Generate reprocessing Frame */
    ret = generateFrameReprocessing(&newFrame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):generateFrameReprocessing fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        goto CLEAN_FRAME;
    }

#ifdef DEBUG_RAWDUMP
    if (m_exynosCameraParameters->checkBayerDumpEnable()) {
        int sensorMaxW, sensorMaxH;
        bool bRet;
        char filePath[70];

        memset(filePath, 0, sizeof(filePath));
        snprintf(filePath, sizeof(filePath), "/data/media/0/RawCapture%d_%d.raw",m_cameraId, m_fliteFrameCount);
        m_exynosCameraParameters->getMaxSensorSize(&sensorMaxW, &sensorMaxH);

        if (m_exynosCameraParameters->getUsePureBayerReprocessing() == true) {
            sensorMaxW += 16;
            sensorMaxH += 10;
        }
        bRet = dumpToFile((char *)filePath,
            bayerBuffer.addr[0],
            sensorMaxW * sensorMaxH * 2);
        if (bRet != true)
            ALOGE("couldn't make a raw file");
    }
#endif /* DEBUG_RAWDUMP */

    if (m_exynosCameraParameters->getUsePureBayerReprocessing() == false) {
        /* TODO: HACK: Will be removed, this is driver's job */
        ret = m_convertingStreamToShotExt(&bayerBuffer, &output_crop_info);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): shot_stream to shot_ext converting fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            goto CLEAN_FRAME;
        }

        camera2_node_group node_group_info;
        ExynosRect srcRect , dstRect;
        int pictureW = 0, pictureH = 0;

        memset(&node_group_info, 0x0, sizeof(camera2_node_group));
        m_exynosCameraParameters->getPictureSize(&pictureW, &pictureH);

        newFrame->getNodeGroupInfo(&node_group_info, PERFRAME_INFO_DIRTY_REPROCESSING_ISP);
        node_group_info.leader.input.cropRegion[0] = output_crop_info.cropRegion[0];
        node_group_info.leader.input.cropRegion[1] = output_crop_info.cropRegion[1];
        node_group_info.leader.input.cropRegion[2] = output_crop_info.cropRegion[2];
        node_group_info.leader.input.cropRegion[3] = output_crop_info.cropRegion[3];
        node_group_info.leader.output.cropRegion[0] = 0;
        node_group_info.leader.output.cropRegion[1] = 0;
        node_group_info.leader.output.cropRegion[2] = node_group_info.leader.input.cropRegion[2];
        node_group_info.leader.output.cropRegion[3] = node_group_info.leader.input.cropRegion[3];

        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[0] = node_group_info.leader.output.cropRegion[0];
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[1] = node_group_info.leader.output.cropRegion[1];
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[2] = node_group_info.leader.output.cropRegion[2];
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[3] = node_group_info.leader.output.cropRegion[3];
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[0] = 0;
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[1] = 0;
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[2] = pictureW;
        node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[3] = pictureH;

        ALOGV("DEBUG(%s[%d]): isp capture input(%d %d %d %d), output(%d %d %d %d)", __FUNCTION__, __LINE__,
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[0],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[1],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[2],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[3],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[0],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[1],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[2],
                                                                                    node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].output.cropRegion[3]);

        if (node_group_info.leader.output.cropRegion[2] < node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[2]) {
            ALOGI("INFO(%s[%d]:(%d -> %d))", __FUNCTION__, __LINE__,
                node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[2],
                node_group_info.leader.output.cropRegion[2]);

            node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[2] = node_group_info.leader.output.cropRegion[2];
        }
        if (node_group_info.leader.output.cropRegion[3] < node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[3]) {
            ALOGI("INFO(%s[%d]:(%d -> %d))", __FUNCTION__, __LINE__,
                node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[3],
                node_group_info.leader.output.cropRegion[3]);

            node_group_info.capture[PERFRAME_REPROCESSING_SCC_POS].input.cropRegion[3] = node_group_info.leader.output.cropRegion[3];
        }

        newFrame->storeNodeGroupInfo(&node_group_info, PERFRAME_INFO_DIRTY_REPROCESSING_ISP);
    }

    shot_ext = (struct camera2_shot_ext *)(bayerBuffer.addr[1]);

    /* Meta setting */
    if (shot_ext != NULL) {
        ret = newFrame->storeDynamicMeta(shot_ext);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): storeDynamicMeta fail ret(%d)", __FUNCTION__, __LINE__, ret);
            goto CLEAN_FRAME;
        }

        ret = newFrame->storeUserDynamicMeta(shot_ext);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): storeUserDynamicMeta fail ret(%d)", __FUNCTION__, __LINE__, ret);
            goto CLEAN_FRAME;
        }

        newFrame->getMetaData(shot_ext);
        m_exynosCameraParameters->duplicateCtrlMetadata((void *)shot_ext);

        ALOGD("DEBUG(%s[%d]):meta_shot_ext->shot.dm.request.frameCount : %d",
                __FUNCTION__, __LINE__,
                getMetaDmRequestFrameCount(shot_ext));
    } else {
        ALOGE("DEBUG(%s[%d]):shot_ext is NULL", __FUNCTION__, __LINE__);
    }

    /* SCC */
    m_getBufferManager(PIPE_SCC_REPROCESSING, &bufferMgr, DST_BUFFER_DIRECTION);

    ret = m_checkBufferAvailable(PIPE_SCC_REPROCESSING, bufferMgr);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): Waiting buffer timeout, pipeId(%d), ret(%d)",
            __FUNCTION__, __LINE__, PIPE_SCC_REPROCESSING, ret);
        goto CLEAN_FRAME;
    }

    ret = m_setupEntity(PIPE_SCC_REPROCESSING, newFrame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]:setupEntity fail, pipeId(%d), ret(%d)",
            __FUNCTION__, __LINE__, PIPE_SCC_REPROCESSING, ret);
        goto CLEAN_FRAME;
    }

    if ((m_exynosCameraParameters->getHighResolutionCallbackMode() == true) &&
        (m_highResolutionCallbackRunning == true)) {
        m_reprocessingFrameFactory->setOutputFrameQToPipe(m_highResolutionCallbackQ, PIPE_SCC_REPROCESSING);
    } else {
        m_reprocessingFrameFactory->setOutputFrameQToPipe(dstSccReprocessingQ, PIPE_SCC_REPROCESSING);
    }
    /* push frame to SCC pipe */
    m_reprocessingFrameFactory->pushFrameToPipe(&newFrame, PIPE_SCC_REPROCESSING);

    /* Add frame to post processing list */
    newFrame->frameLock();
    m_postProcessList.push_back(newFrame);

    ret = m_reprocessingFrameFactory->startInitialThreads();
    if (ret < 0) {
        ALOGE("ERR(%s):startInitialThreads fail", __FUNCTION__);
        goto CLEAN;
    }

    ret = newFrame->ensureDstBufferState(PIPE_SCC_REPROCESSING, ENTITY_BUFFER_STATE_PROCESSING);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): ensure buffer state(ENTITY_BUFFER_STATE_PROCESSING) fail, ret(%d)", __FUNCTION__, __LINE__, ret);
    }

    /* Get bayerPipeId at first entity */
    bayerPipeId = newFrame->getFirstEntity()->getPipeId();
    ALOGD("DEBUG(%s[%d]): bayer Pipe ID(%d)", __FUNCTION__, __LINE__, bayerPipeId);

    /* Check available buffer */
    ret = m_getBufferManager(bayerPipeId, &bufferMgr, DST_BUFFER_DIRECTION);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): getBufferManager fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        goto CLEAN;
    }
    if (bufferMgr != NULL) {
        ret = m_checkBufferAvailable(bayerPipeId, bufferMgr);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): Waiting buffer timeout, bayerPipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, bayerPipeId, ret);
            goto CLEAN;
        }
    }

    ret = m_setupEntity(bayerPipeId, newFrame, &bayerBuffer, NULL);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]:setupEntity fail, bayerPipeId(%d), ret(%d)",
            __FUNCTION__, __LINE__, bayerPipeId, ret);
        goto CLEAN;
    }

    m_reprocessingFrameFactory->setOutputFrameQToPipe(dstIspReprocessingQ, PIPE_ISP_REPROCESSING);

    /* push the newFrameReprocessing to pipe */
    m_reprocessingFrameFactory->pushFrameToPipe(&newFrame, bayerPipeId);

    /* When enabled SCC capture or pureBayerReprocessing, we need to start bayer pipe thread */
    if (m_exynosCameraParameters->getUsePureBayerReprocessing() == true ||
        isSccCapture() == true)
        m_reprocessingFrameFactory->startThread(bayerPipeId);

    /* wait ISP done */
    ALOGI("INFO(%s[%d]):wait ISP output", __FUNCTION__, __LINE__);
    ret = dstIspReprocessingQ->waitAndPopProcessQ(&newFrame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):ISP wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        /* TODO: doing exception handling */
        /* goto CLEAN; */
    }
    if (newFrame == NULL) {
        ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
        goto CLEAN;
    }

    ret = newFrame->setEntityState(bayerPipeId, ENTITY_STATE_COMPLETE);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setEntityState(ENTITY_STATE_PROCESSING) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, bayerPipeId, ret);
        return ret;
    }

    ALOGI("INFO(%s[%d]):ISP output done", __FUNCTION__, __LINE__);

    newFrame->setMetaDataEnable(true);

    /* put bayer buffer */
    ret = m_putBuffers(m_bayerBufferMgr, bayerBuffer.index);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): 3AA src putBuffer fail, index(%d), ret(%d)", __FUNCTION__, __LINE__, bayerBuffer.index, ret);
        goto CLEAN;
    }

    /* put isp buffer */
    if (m_exynosCameraParameters->getUsePureBayerReprocessing() == true) {
        ret = m_getBufferManager(bayerPipeId, &bufferMgr, DST_BUFFER_DIRECTION);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): getBufferManager fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            goto CLEAN;
        }
        if (bufferMgr != NULL) {
            ret = newFrame->getDstBuffer(bayerPipeId, &ispReprocessingBuffer);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):getDstBuffer fail, bayerPipeId(%d), ret(%d)",
                        __FUNCTION__, __LINE__, bayerPipeId, ret);
                goto CLEAN;
            }
            ret = m_putBuffers(m_ispReprocessingBufferMgr, ispReprocessingBuffer.index);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]): ISP src putBuffer fail, index(%d), ret(%d)", __FUNCTION__, __LINE__, bayerBuffer.index, ret);
                goto CLEAN;
            }
        }
    }

    m_reprocessingCounter.decCount();

    ALOGI("INFO(%s[%d]):reprocessing complete, remaining count(%d)", __FUNCTION__, __LINE__, m_reprocessingCounter.getCount());

    if (m_hdrEnabled) {
        ExynosCameraActivitySpecialCapture *m_sCaptureMgr;

        m_sCaptureMgr = m_exynosCameraActivityControl->getSpecialCaptureMgr();

        if (m_reprocessingCounter.getCount() == 0)
            m_sCaptureMgr->setCaptureStep(ExynosCameraActivitySpecialCapture::SCAPTURE_STEP_OFF);
    }

    if ((m_exynosCameraParameters->getHighResolutionCallbackMode() == true) &&
        (m_highResolutionCallbackRunning == true))
        loop = true;

    if (m_reprocessingCounter.getCount() > 0)
        loop = true;

    /* one shot */
    return loop;

CLEAN_FRAME:
    /* newFrame is not pushed any pipes, we can delete newFrame */
    if (newFrame != NULL && newFrame->getFrameLockState() == false) {
        newFrame->printEntity();
        ALOGD("DEBUG(%s[%d]): Reprocessing frame delete(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());
        delete newFrame;
        newFrame = NULL;
    }

CLEAN:
    if (bayerBuffer.index != -2 && m_bayerBufferMgr != NULL)
        m_putBuffers(m_bayerBufferMgr, bayerBuffer.index);
    if (ispReprocessingBuffer.index != -2 && m_ispReprocessingBufferMgr != NULL)
        m_putBuffers(m_ispReprocessingBufferMgr, ispReprocessingBuffer.index);

    /* newFrame is already pushed some pipes, we can not delete newFrame until frame is complete */
    if (newFrame != NULL && newFrame->isComplete() == true) {
        newFrame->frameUnlock();
        ret = m_removeFrameFromList(&m_postProcessList, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):remove frame from processList fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        }

        newFrame->printEntity();
        ALOGD("DEBUG(%s[%d]): Reprocessing frame delete(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());
        delete newFrame;
        newFrame = NULL;
    }

    if (m_hdrEnabled) {
        ExynosCameraActivitySpecialCapture *m_sCaptureMgr;

        m_sCaptureMgr = m_exynosCameraActivityControl->getSpecialCaptureMgr();

        if (m_reprocessingCounter.getCount() == 0)
            m_sCaptureMgr->setCaptureStep(ExynosCameraActivitySpecialCapture::SCAPTURE_STEP_OFF);
    }

    if ((m_exynosCameraParameters->getHighResolutionCallbackMode() == true) &&
        (m_highResolutionCallbackRunning == true))
        loop = true;

    if (m_reprocessingCounter.getCount() > 0)
        loop = true;

    ALOGI("INFO(%s[%d]): reprocessing fail, remaining count(%d)", __FUNCTION__, __LINE__, m_reprocessingCounter.getCount());

    return loop;
}

bool ExynosCameraHWImpl::m_pictureThreadFunc(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
    ALOGI("INFO(%s[%d]):", __FUNCTION__, __LINE__);

    int ret = 0;
    int loop = false;
    int bufIndex = -2;

    ExynosCameraFrame *newFrame = NULL;

    ExynosCameraBuffer sccReprocessingBuffer;
    ExynosCameraBufferManager *bufferMgr = NULL;
    struct camera2_stream *shot_stream = NULL;
    ExynosRect srcRect, dstRect;
    int pictureW = 0, pictureH = 0, pictureFormat = 0;
    int hwPictureW = 0, hwPictureH = 0, hwPictureFormat = 0;

    sccReprocessingBuffer.index = -2;

    int pipeId_scc = 0;
    int pipeId_gsc = 0;
    bool isSrc = false;

//    if (isReprocessing() == true && m_exynosCameraParameters->getSeriesShotCount() == 0 &&
//            m_hdrEnabled == false) {
    if (isReprocessing() == true) {
        pipeId_scc = PIPE_SCC_REPROCESSING;
        pipeId_gsc = PIPE_GSC_REPROCESSING;
        isSrc = true;
    } else {
        switch (getCameraId()) {
        case CAMERA_ID_FRONT:
            pipeId_scc = PIPE_SCC_FRONT;
            pipeId_gsc = PIPE_GSC_PICTURE_FRONT;
            break;
        default:
            ALOGE("ERR(%s[%d]):Current picture mode is not yet supported, CameraId(%d), reprocessing(%d)",
                    __FUNCTION__, __LINE__, getCameraId(), isReprocessing());
            break;
        }
    }

    /* wait SCC */
    ALOGI("INFO(%s[%d]):wait SCC output", __FUNCTION__, __LINE__);
    int retry = 0;
    do {
        ret = dstSccReprocessingQ->waitAndPopProcessQ(&newFrame);
        retry++;
    } while (ret == TIMED_OUT && retry < 40 &&
             (m_takePictureCounter.getCount() > 0 || m_exynosCameraParameters->getSeriesShotCount() == 0));

    if (ret < 0) {
        ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d), retry(%d), takePictuerCount(%d), seriesShotCount(%d)",
                __FUNCTION__, __LINE__, ret, retry, m_takePictureCounter.getCount(), m_exynosCameraParameters->getSeriesShotCount());
        // TODO: doing exception handling
        goto CLEAN;
    }

    if (newFrame == NULL || m_postProcessList.size() <= 0) {
        ALOGE("ERR(%s[%d]):newFrame is NULL or postPictureList size(%d)", __FUNCTION__, __LINE__, m_postProcessList.size());
        goto CLEAN;
    }

    /* When Front camera dose not setEntityState because Front camera share preview and capture frames */
    if (getCameraId() == CAMERA_ID_BACK) {
        ret = newFrame->setEntityState(pipeId_scc, ENTITY_STATE_COMPLETE);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):setEntityState(ENTITY_STATE_PROCESSING) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_scc, ret);
            return ret;
        }
    }

    ALOGI("INFO(%s[%d]):SCC output done, frame Count(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());

    if (needGSCForCapture(getCameraId()) == true) {
        /* set GSC buffer */
        ret = newFrame->getDstBuffer(pipeId_scc, &sccReprocessingBuffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, pipeId_scc, ret);
            goto CLEAN;
        }

        shot_stream = (struct camera2_stream *)(sccReprocessingBuffer.addr[1]);
        if (shot_stream != NULL) {
            ALOGD("DEBUG(%s[%d]):(%d %d %d %d)", __FUNCTION__, __LINE__,
                shot_stream->fcount,
                shot_stream->rcount,
                shot_stream->findex,
                shot_stream->fvalid);
            ALOGD("DEBUG(%s[%d]):(%d %d %d %d)(%d %d %d %d)", __FUNCTION__, __LINE__,
                shot_stream->input_crop_region[0],
                shot_stream->input_crop_region[1],
                shot_stream->input_crop_region[2],
                shot_stream->input_crop_region[3],
                shot_stream->output_crop_region[0],
                shot_stream->output_crop_region[1],
                shot_stream->output_crop_region[2],
                shot_stream->output_crop_region[3]);
        } else {
            ALOGE("DEBUG(%s[%d]):shot_stream is NULL", __FUNCTION__, __LINE__);
            goto CLEAN;
        }

        int retry = 0;
        m_getBufferManager(pipeId_gsc, &bufferMgr, DST_BUFFER_DIRECTION);
        do {
            ret = -1;
            retry++;
            if (bufferMgr->getNumOfAvailableBuffer() > 0) {
                ret = m_setupEntity(pipeId_gsc, newFrame, &sccReprocessingBuffer, NULL);
            } else {
                /* wait available SCC buffer */
                usleep(WAITING_TIME);
            }

            if (retry % 10 == 0) {
                ALOGW("WRAN(%s[%d]):retry setupEntity for GSC postPictureQ(%d)",
                        __FUNCTION__, __LINE__,
                        m_postPictureQ->getSizeOfProcessQ());
            }
        } while(ret < 0 && retry < (TOTAL_WAITING_TIME/WAITING_TIME) && m_stopBurstShot == false);

        if (ret < 0) {
            if (retry >= (TOTAL_WAITING_TIME/WAITING_TIME)) {
                ALOGE("ERR(%s[%d]):setupEntity fail, pipeId(%d), retry(%d), ret(%d), m_stopBurstShot(%d)",
                        __FUNCTION__, __LINE__, pipeId_gsc, retry, ret, m_stopBurstShot);
            } else {
                ALOGD("DEBUG(%s[%d]):setupEntity stopped, pipeId(%d), retry(%d), ret(%d), m_stopBurstShot(%d)",
                        __FUNCTION__, __LINE__, pipeId_gsc, retry, ret, m_stopBurstShot);
            }
            goto CLEAN;
        }
/* should change size calculation code in pure bayer */
#if 0
        if (shot_stream != NULL) {
            ret = m_calcPictureRect(&srcRect, &dstRect);
            ret = newFrame->setSrcRect(pipeId_gsc, &srcRect);
            ret = newFrame->setDstRect(pipeId_gsc, &dstRect);
        }
#else
        m_exynosCameraParameters->getPictureSize(&pictureW, &pictureH);
        pictureFormat = m_exynosCameraParameters->getPictureFormat();

        srcRect.x = shot_stream->input_crop_region[0];
        srcRect.y = shot_stream->input_crop_region[1];
        srcRect.w = shot_stream->input_crop_region[2];
        srcRect.h = shot_stream->input_crop_region[3];
        srcRect.fullW = shot_stream->input_crop_region[2];
        srcRect.fullH = shot_stream->input_crop_region[3];
        srcRect.colorFormat = pictureFormat;

        dstRect.x = 0;
        dstRect.y = 0;
        dstRect.w = pictureW;
        dstRect.h = pictureH;
        dstRect.fullW = pictureW;
        dstRect.fullH = pictureH;
        dstRect.colorFormat = JPEG_INPUT_COLOR_FMT;

        ret = getCropRectAlign(srcRect.w,  srcRect.h,
                               pictureW,   pictureH,
                               &srcRect.x, &srcRect.y,
                               &srcRect.w, &srcRect.h,
                               2, 2, 0);

        ret = newFrame->setSrcRect(pipeId_gsc, &srcRect);
        ret = newFrame->setDstRect(pipeId_gsc, &dstRect);
#endif

        ALOGD("DEBUG(%s):size (%d, %d, %d, %d %d %d)", __FUNCTION__,
            srcRect.x, srcRect.y, srcRect.w, srcRect.h, srcRect.fullW, srcRect.fullH);
        ALOGD("DEBUG(%s):size (%d, %d, %d, %d %d %d)", __FUNCTION__,
            dstRect.x, dstRect.y, dstRect.w, dstRect.h, dstRect.fullW, dstRect.fullH);

        /* push frame to GSC pipe */
        m_pictureFrameFactory->pushFrameToPipe(&newFrame, pipeId_gsc);
        m_pictureFrameFactory->setOutputFrameQToPipe(dstGscReprocessingQ, pipeId_gsc);

        /* wait GSC */
        newFrame = NULL;
        ALOGI("INFO(%s[%d]):wait GSC output", __FUNCTION__, __LINE__);
        ret = dstGscReprocessingQ->waitAndPopProcessQ(&newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s)(%d):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            /* TODO: doing exception handling */
            goto CLEAN;
        }
        if (newFrame == NULL) {
            ALOGE("ERR(%s):newFrame is NULL", __FUNCTION__);
            goto CLEAN;
        }
        ALOGI("INFO(%s[%d]):GSC output done", __FUNCTION__, __LINE__);

        /* put SCC buffer */
        ret = newFrame->getDstBuffer(pipeId_scc, &sccReprocessingBuffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_scc, ret);
            goto CLEAN;
        }

        m_getBufferManager(pipeId_scc, &bufferMgr, DST_BUFFER_DIRECTION);
        ret = m_putBuffers(bufferMgr, sccReprocessingBuffer.index);
        if (ret < 0) {
            ALOGE("ERR(%s)(%d):m_putBuffers fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            /* TODO: doing exception handling */
            goto CLEAN;
        }
    }

    /* push postProcess */
    m_postPictureQ->pushProcessQ(&newFrame);

    /* Shutter Callback */
    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_SHUTTER)) {
        ALOGI("INFO(%s[%d]): CAMERA_MSG_SHUTTER callback ", __FUNCTION__, __LINE__);
        m_notifyCb(CAMERA_MSG_SHUTTER, 0, 0, m_callbackCookie);
    }

    m_pictureCounter.decCount();

    ALOGI("INFO(%s[%d]):picture thread complete, remaining count(%d)", __FUNCTION__, __LINE__, m_pictureCounter.getCount());

    if (m_pictureCounter.getCount() > 0) {
        loop = true;
    } else {
//        if (isReprocessing() == true && m_exynosCameraParameters->getSeriesShotCount() == 0 &&
//                m_hdrEnabled == false)
        if (isReprocessing() == true)
            ALOGD("DEBUG(%s[%d]): ", __FUNCTION__, __LINE__);
        else {
            if (m_exynosCameraParameters->getUseDynamicScc() == true) {
                ALOGD("DEBUG(%s[%d]): Use dynamic bayer", __FUNCTION__, __LINE__);
                m_previewFrameFactory->setRequestSCC(false);
            }
            m_sccCaptureSelector->clearList(pipeId_scc, isSrc);
        }

        dstSccReprocessingQ->release();
    }

    /* one shot */
    return loop;

CLEAN:
    if (sccReprocessingBuffer.index != -2) {
        ALOGD("DEBUG(%s[%d]): putBuffer sccReprocessingBuffer(index:%d) in error state",
                __FUNCTION__, __LINE__, sccReprocessingBuffer.index);
        m_putBuffers(bufferMgr, sccReprocessingBuffer.index);
    }

#if 0
    if (newFrame != NULL) {
        ALOGD("DEBUG(%s[%d]): print Entity state in error state", __FUNCTION__, __LINE__);
        newFrame->printEntity();
        ALOGD("DEBUG(%s[%d]): delete newFrame in error state", __FUNCTION__, __LINE__);
        delete newFrame;
        newFrame = NULL;
    }
#endif

    ALOGI("INFO(%s[%d]):take picture fail, remaining count(%d)", __FUNCTION__, __LINE__, m_pictureCounter.getCount());

    if (m_pictureCounter.getCount() > 0)
        loop = true;

    /* one shot */
    return loop;
}


bool ExynosCameraHWImpl::m_startPictureInternalReprocessing(void)
{
    CLOGD("DEBUG(%s):in", __func__);

    if (m_pictureRunning == true) {
        CLOGE("ERR(%s):Aready m_pictureRunning is running", __func__);
        return false;
    }

    int pictureW, pictureH, pictureFormat, pictureFramesize;
    ExynosBuffer nullBuf;

    pictureFormat = m_secCamera->getPictureFormat();
    m_secCamera->getPictureSizeReprocessing(&pictureW, &pictureH);

    pictureFramesize = FRAME_SIZE(V4L2_PIX_2_HAL_PIXEL_FORMAT(pictureFormat), ALIGN_UP(pictureW, CAMERA_MAGIC_ALIGN), ALIGN_UP(pictureH, CAMERA_MAGIC_ALIGN));

    if (m_rawHeap) {
        m_rawHeap->release(m_rawHeap);
        m_rawHeap = 0;
        m_rawHeapFd = -1;
        m_rawHeapSize = 0;
    }

    int rawHeapSize = pictureFramesize;

    m_rawHeap = m_getMemoryCb(-1, rawHeapSize, 1, &m_rawHeapFd);
    if (!m_rawHeap || m_rawHeapFd <= 0) {
        CLOGE("ERR(%s):m_getMemoryCb(m_rawHeap, size(%d) fail", __func__, rawHeapSize);
        return false;
    }
    m_rawHeapSize = rawHeapSize;

    for (int i = 0; i < NUM_OF_PICTURE_BUF; i++) {
        if (m_pictureHeap[i]) {
            m_pictureHeap[i]->release(m_pictureHeap[i]);
            m_pictureHeap[i] = 0;
            m_pictureHeapFd[i] = -1;
        }

        m_pictureHeap[i] = m_getMemoryCb(-1, pictureFramesize, 1, &(m_pictureHeapFd[i]));
        if (!m_pictureHeap[i] || m_pictureHeapFd[i] <= 0) {
            CLOGE("ERR(%s):m_getMemoryCb(m_pictureHeap[%d], size(%d) fail", __func__, i, pictureFramesize);
            return false;
        }

        m_pictureBuf[0] = nullBuf;
        m_pictureBuf[0].virt.extP[0] = (char *)m_pictureHeap[i]->data;
        m_pictureBuf[0].fd.extFd[0] = m_pictureHeapFd[i];
        m_getAlignedYUVSize(pictureFormat, ALIGN_UP(pictureW, CAMERA_MAGIC_ALIGN), ALIGN_UP(pictureH, CAMERA_MAGIC_ALIGN), &m_pictureBuf[0]);

        m_pictureBuf[0].reserved.p = i;

        m_secCamera->setPictureBufReprocessing(&m_pictureBuf[0]);
    }

    if (m_secCamera->startPictureReprocessing() == false) {
        CLOGE("ERR(%s):Fail on m_secCamera->startPictureReprocessing()", __func__);
        return false;
    }

    for (int i = 0; i < NUM_OF_FLASH_BUF; i++)
        m_pictureBuf[i] = nullBuf;

    m_pictureRunning = true;

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}

bool ExynosCameraHWImpl::m_stopPictureInternalReprocessing(void)
{
    CLOGD("DEBUG(%s):in", __func__);

    if (m_pictureRunning == false) {
        CLOGE("ERR(%s):Aready m_pictureRunning is stop", __func__);
        return false;
    }

    if (m_secCamera->flagStartPictureReprocessing() == true
        && m_secCamera->stopPictureReprocessing() == false)
        CLOGE("ERR(%s):Fail on m_secCamera->stopPicture()", __func__);

    for (int i = 0; i < NUM_OF_PICTURE_BUF; i++) {
        if (m_pictureHeap[i]) {
            m_pictureHeap[i]->release(m_pictureHeap[i]);
            m_pictureHeap[i] = 0;
            m_pictureHeapFd[i] = -1;
        }
    }

    if (m_rawHeap) {
        m_rawHeap->release(m_rawHeap);
        m_rawHeap = 0;
        m_rawHeapFd = -1;
        m_rawHeapSize = 0;
    }

    m_pictureRunning = false;

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}

void ExynosCameraHWImpl::m_setSkipFrame(int frame)
{
    Mutex::Autolock lock(m_skipFrameLock);
    if (frame < m_skipFrame)
        return;

    m_skipFrame = frame;
}

int ExynosCameraHWImpl::m_getSkipFrame()
{
    Mutex::Autolock lock(m_skipFrameLock);

    return m_skipFrame;
}

void ExynosCameraHWImpl::m_decSkipFrame()
{
    Mutex::Autolock lock(m_skipFrameLock);

    m_skipFrame--;
}

int ExynosCameraHWImpl::m_saveJpeg( unsigned char *real_jpeg, int jpeg_size)
{
    FILE *yuv_fp = NULL;
    char filename[100], *buffer = NULL;

    /* file create/open, note to "wb" */
    yuv_fp = fopen("mnt/shell/emulated/0/DCIM/Camera.jpeg", "wb");
    if (yuv_fp == NULL) {
        CLOGE("Save jpeg file open error");
        return -1;
    }

    CLOGV("DEBUG(%s): real_jpeg size ========>  %d", __func__, jpeg_size);
    buffer = (char *) malloc(jpeg_size);
    if (buffer == NULL) {
        CLOGE("Save YUV] buffer alloc failed");
        if (yuv_fp)
            fclose(yuv_fp);

        return -1;
    }

    memcpy(buffer, real_jpeg, jpeg_size);

    fflush(stdout);

    fwrite(buffer, 1, jpeg_size, yuv_fp);

    fflush(yuv_fp);

    if (yuv_fp)
            fclose(yuv_fp);
    if (buffer)
            free(buffer);

    return 0;
}

bool ExynosCameraHWImpl::m_scaleDownYuv422(char *srcBuf, uint32_t srcWidth, uint32_t srcHeight,
                                             char *dstBuf, uint32_t dstWidth, uint32_t dstHeight)
{
    int32_t step_x, step_y;
    int32_t iXsrc, iXdst;
    int32_t x, y, src_y_start_pos, dst_pos, src_pos;

    if (dstWidth % 2 != 0 || dstHeight % 2 != 0) {
        CLOGE("scale_down_yuv422: invalid width, height for scaling");
        return false;
    }

    step_x = srcWidth / dstWidth;
    step_y = srcHeight / dstHeight;

    dst_pos = 0;
    for (uint32_t y = 0; y < dstHeight; y++) {
        src_y_start_pos = (y * step_y * (srcWidth * 2));

        for (uint32_t x = 0; x < dstWidth; x += 2) {
            src_pos = src_y_start_pos + (x * (step_x * 2));

            dstBuf[dst_pos++] = srcBuf[src_pos    ];
            dstBuf[dst_pos++] = srcBuf[src_pos + 1];
            dstBuf[dst_pos++] = srcBuf[src_pos + 2];
            dstBuf[dst_pos++] = srcBuf[src_pos + 3];
        }
    }

    return true;
}

bool ExynosCameraHWImpl::m_YUY2toNV21(void *srcBuf, void *dstBuf, uint32_t srcWidth, uint32_t srcHeight)
{
    int32_t        x, y, src_y_start_pos, dst_cbcr_pos, dst_pos, src_pos;
    unsigned char *srcBufPointer = (unsigned char *)srcBuf;
    unsigned char *dstBufPointer = (unsigned char *)dstBuf;

    dst_pos = 0;
    dst_cbcr_pos = srcWidth*srcHeight;
    for (uint32_t y = 0; y < srcHeight; y++) {
        src_y_start_pos = (y * (srcWidth * 2));

        for (uint32_t x = 0; x < (srcWidth * 2); x += 2) {
            src_pos = src_y_start_pos + x;

            dstBufPointer[dst_pos++] = srcBufPointer[src_pos];
        }
    }
    for (uint32_t y = 0; y < srcHeight; y += 2) {
        src_y_start_pos = (y * (srcWidth * 2));

        for (uint32_t x = 0; x < (srcWidth * 2); x += 4) {
            src_pos = src_y_start_pos + x;

            dstBufPointer[dst_cbcr_pos++] = srcBufPointer[src_pos + 3];
            dstBufPointer[dst_cbcr_pos++] = srcBufPointer[src_pos + 1];
        }
    }

    return true;
}

bool ExynosCameraHWImpl::m_checkVideoStartMarker(unsigned char *pBuf)
{
    if (!pBuf) {
        CLOGE("m_checkVideoStartMarker() => pBuf is NULL");
        return false;
    }

    if (HIBYTE(VIDEO_COMMENT_MARKER_H) == * pBuf      && LOBYTE(VIDEO_COMMENT_MARKER_H) == *(pBuf + 1) &&
        HIBYTE(VIDEO_COMMENT_MARKER_L) == *(pBuf + 2) && LOBYTE(VIDEO_COMMENT_MARKER_L) == *(pBuf + 3))
        return true;

    return false;
}

bool ExynosCameraHWImpl::m_checkEOIMarker(unsigned char *pBuf)
{
    if (!pBuf) {
        CLOGE("m_checkEOIMarker() => pBuf is NULL");
        return false;
    }

    // EOI marker [FF D9]
    if (HIBYTE(JPEG_EOI_MARKER) == *pBuf && LOBYTE(JPEG_EOI_MARKER) == *(pBuf + 1))
        return true;

    return false;
}

bool ExynosCameraHWImpl::m_findEOIMarkerInJPEG(unsigned char *pBuf, int dwBufSize, int *pnJPEGsize)
{
    if (NULL == pBuf || 0 >= dwBufSize) {
        CLOGE("m_findEOIMarkerInJPEG() => There is no contents.");
        return false;
    }

    unsigned char *pBufEnd = pBuf + dwBufSize;

    while (pBuf < pBufEnd) {
        if (m_checkEOIMarker(pBuf++))
            return true;

        (*pnJPEGsize)++;
    }

    return false;
}

bool ExynosCameraHWImpl::m_splitFrame(unsigned char *pFrame, int dwSize,
                    int dwJPEGLineLength, int dwVideoLineLength, int dwVideoHeight,
                    void *pJPEG, int *pdwJPEGSize,
                    void *pVideo, int *pdwVideoSize)
{
    CLOGV("DEBUG(%s):===========m_splitFrame Start==============", __func__);

    if (NULL == pFrame || 0 >= dwSize) {
        CLOGE("There is no contents (pFrame=%p, dwSize=%d", pFrame, dwSize);
        return false;
    }

    if (0 == dwJPEGLineLength || 0 == dwVideoLineLength) {
        CLOGE("There in no input information for decoding interleaved jpeg");
        return false;
    }

    unsigned char *pSrc = pFrame;
    unsigned char *pSrcEnd = pFrame + dwSize;

    unsigned char *pJ = (unsigned char *)pJPEG;
    int dwJSize = 0;
    unsigned char *pV = (unsigned char *)pVideo;
    int dwVSize = 0;

    bool bRet = false;
    bool isFinishJpeg = false;

    while (pSrc < pSrcEnd) {
        // Check video start marker
        if (m_checkVideoStartMarker(pSrc)) {
            int copyLength;

            if (pSrc + dwVideoLineLength <= pSrcEnd)
                copyLength = dwVideoLineLength;
            else
                copyLength = pSrcEnd - pSrc - VIDEO_COMMENT_MARKER_LENGTH;

            // Copy video data
            if (pV) {
                memcpy(pV, pSrc + VIDEO_COMMENT_MARKER_LENGTH, copyLength);
                pV += copyLength;
                dwVSize += copyLength;
            }

            pSrc += copyLength + VIDEO_COMMENT_MARKER_LENGTH;
        } else {
            // Copy pure JPEG data
            int size = 0;
            int dwCopyBufLen = dwJPEGLineLength <= pSrcEnd-pSrc ? dwJPEGLineLength : pSrcEnd - pSrc;

            if (m_findEOIMarkerInJPEG((unsigned char *)pSrc, dwCopyBufLen, &size)) {
                isFinishJpeg = true;
                size += 2;  // to count EOF marker size
            } else {
                if ((dwCopyBufLen == 1) && (pJPEG < pJ)) {
                    unsigned char checkBuf[2] = { *(pJ - 1), *pSrc };

                    if (m_checkEOIMarker(checkBuf))
                        isFinishJpeg = true;
                }
                size = dwCopyBufLen;
            }

            memcpy(pJ, pSrc, size);

            dwJSize += size;

            pJ += dwCopyBufLen;
            pSrc += dwCopyBufLen;
        }
        if (isFinishJpeg)
            break;
    }

    if (isFinishJpeg) {
        bRet = true;
        if (pdwJPEGSize)
            *pdwJPEGSize = dwJSize;
        if (pdwVideoSize)
            *pdwVideoSize = dwVSize;
    } else {
        CLOGE("DecodeInterleaveJPEG_WithOutDT() => Can not find EOI");
        bRet = false;
        if (pdwJPEGSize)
            *pdwJPEGSize = 0;
        if (pdwVideoSize)
            *pdwVideoSize = 0;
    }
    CLOGV("DEBUG(%s):===========m_splitFrame end==============", __func__);

    return bRet;
}

int ExynosCameraHWImpl::m_decodeInterleaveData(unsigned char *pInterleaveData,
                                                 int interleaveDataSize,
                                                 int yuvWidth,
                                                 int yuvHeight,
                                                 int *pJpegSize,
                                                 void *pJpegData,
                                                 void *pYuvData)
{
    if (pInterleaveData == NULL)
        return false;

    bool ret = true;
    unsigned int *interleave_ptr = (unsigned int *)pInterleaveData;
    unsigned char *jpeg_ptr = (unsigned char *)pJpegData;
    unsigned char *yuv_ptr = (unsigned char *)pYuvData;
    unsigned char *p;
    int jpeg_size = 0;
    int yuv_size = 0;

    int i = 0;

    CLOGV("DEBUG(%s):m_decodeInterleaveData Start~~~", __func__);
    while (i < interleaveDataSize) {
        if ((*interleave_ptr == 0xFFFFFFFF) || (*interleave_ptr == 0x02FFFFFF) ||
                (*interleave_ptr == 0xFF02FFFF)) {
            // Padding Data
            interleave_ptr++;
            i += 4;
        } else if ((*interleave_ptr & 0xFFFF) == 0x05FF) {
            // Start-code of YUV Data
            p = (unsigned char *)interleave_ptr;
            p += 2;
            i += 2;

            // Extract YUV Data
            if (pYuvData != NULL) {
                memcpy(yuv_ptr, p, yuvWidth * 2);
                yuv_ptr += yuvWidth * 2;
                yuv_size += yuvWidth * 2;
            }
            p += yuvWidth * 2;
            i += yuvWidth * 2;

            // Check End-code of YUV Data
            if ((*p == 0xFF) && (*(p + 1) == 0x06)) {
                interleave_ptr = (unsigned int *)(p + 2);
                i += 2;
            } else {
                ret = false;
                break;
            }
        } else {
            // Extract JPEG Data
            if (pJpegData != NULL) {
                memcpy(jpeg_ptr, interleave_ptr, 4);
                jpeg_ptr += 4;
                jpeg_size += 4;
            }
            interleave_ptr++;
            i += 4;
        }
    }
    if (ret) {
        if (pJpegData != NULL) {
            // Remove Padding after EOI
            for (i = 0; i < 3; i++) {
                if (*(--jpeg_ptr) != 0xFF) {
                    break;
                }
                jpeg_size--;
            }
            *pJpegSize = jpeg_size;

        }
        // Check YUV Data Size
        if (pYuvData != NULL) {
            if (yuv_size != (yuvWidth * yuvHeight * 2)) {
                ret = false;
            }
        }
    }
    CLOGV("DEBUG(%s):m_decodeInterleaveData End~~~", __func__);
    return ret;
}

camera_memory_t *ExynosCameraHWImpl::m_getJpegCallbackHeap(ExynosCameraBuffer jpegBuf, int seriesShotNumber)
{
    ALOGI("INFO(%s[%d]):", __FUNCTION__, __LINE__);

    camera_memory_t *jpegCallbackHeap = NULL;

    {
        ALOGD("DEBUG(%s[%d]):general callback : size (%d)", __FUNCTION__, __LINE__, jpegBuf.size[0]);

        jpegCallbackHeap = m_getMemoryCb(jpegBuf.fd[0], jpegBuf.size[0], 1, m_callbackCookie);
        if (!jpegCallbackHeap || jpegCallbackHeap->data == MAP_FAILED) {
            ALOGE("ERR(%s[%d]):m_getMemoryCb(%d) fail", __FUNCTION__, __LINE__, jpegBuf.size[0]);
            goto done;
        }

        if (jpegBuf.fd[0] < 0)
            memcpy(jpegCallbackHeap->data, jpegBuf.addr[0], jpegBuf.size[0]);
    }

done:
    if (jpegCallbackHeap == NULL ||
        jpegCallbackHeap->data == MAP_FAILED) {

        if (jpegCallbackHeap) {
            jpegCallbackHeap->release(jpegCallbackHeap);
            jpegCallbackHeap = NULL;
        }

        m_notifyCb(CAMERA_MSG_ERROR, -1, 0, m_callbackCookie);
    }

    ALOGD("INFO(%s[%d]):making callback buffer done", __FUNCTION__, __LINE__);

    return jpegCallbackHeap;
}

bool ExynosCameraHWImpl::m_postPictureThreadFunc(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
    ALOGI("INFO(%s[%d]):", __FUNCTION__, __LINE__);

    int ret = 0;
    int loop = false;
    int bufIndex = -2;

    ExynosCameraFrame *newFrame = NULL;

    ExynosCameraBuffer gscReprocessingBuffer;
    ExynosCameraBuffer jpegReprocessingBuffer;

    gscReprocessingBuffer.index = -2;
    jpegReprocessingBuffer.index = -2;

    int pipeId_gsc = 0;
    int pipeId_jpeg = 0;

    int currentSeriesShotMode = m_exynosCameraParameters->getSeriesShotMode();

//    if (isReprocessing() == true && m_exynosCameraParameters->getSeriesShotCount() == 0 &&
//            m_hdrEnabled == false) {
    if (isReprocessing() == true) {
        pipeId_gsc = PIPE_SCC_REPROCESSING;
        pipeId_jpeg = PIPE_JPEG_REPROCESSING;
    } else {
        switch (getCameraId()) {
            case CAMERA_ID_BACK:
                if (needGSCForCapture(getCameraId()) == true)
                    pipeId_gsc = PIPE_GSC_PICTURE;
                else
                    pipeId_gsc = PIPE_SCC;

                pipeId_jpeg = PIPE_JPEG;
                break;
            case CAMERA_ID_FRONT:
                if (needGSCForCapture(getCameraId()) == true)
                    pipeId_gsc = PIPE_GSC_PICTURE_FRONT;
                else
                    pipeId_gsc = PIPE_SCC_FRONT;

                pipeId_jpeg = PIPE_JPEG_FRONT;
                break;
            default:
                ALOGE("ERR(%s[%d]):Current picture mode is not yet supported, CameraId(%d), reprocessing(%d)",__FUNCTION__, __LINE__, getCameraId(), isReprocessing());
                break;
        }
    }

    ExynosCameraBufferManager *bufferMgr = NULL;
    ret = m_getBufferManager(pipeId_gsc, &bufferMgr, DST_BUFFER_DIRECTION);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):getBufferManager(SRC) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_gsc, ret);
        return ret;
    }

    ALOGI("INFO(%s[%d]):wait postPictureQ output", __FUNCTION__, __LINE__);
    ret = m_postPictureQ->waitAndPopProcessQ(&newFrame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        /* TODO: doing exception handling */
        goto CLEAN;
    }
    if (newFrame == NULL) {
        ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
        goto CLEAN;
    }

    if (m_jpegCounter.getCount() <= 0) {
        ALOGD("DEBUG(%s[%d]): Picture canceled", __FUNCTION__, __LINE__);
        goto CLEAN;
    }

    ALOGI("INFO(%s[%d]):postPictureQ output done", __FUNCTION__, __LINE__);

    /* put picture callback buffer */
    /* get gsc dst buffers */
    ret = newFrame->getDstBuffer(pipeId_gsc, &gscReprocessingBuffer);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_gsc, ret);
        goto CLEAN;
    }

    /* callback */
    if (m_hdrEnabled == false && m_exynosCameraParameters->getSeriesShotCount() <= 0) {
        if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_RAW_IMAGE)) {
            ALOGD("DEBUG(%s[%d]): RAW callabck", __FUNCTION__, __LINE__);
            camera_memory_t *rawCallbackHeap = NULL;
            rawCallbackHeap = m_getMemoryCb(gscReprocessingBuffer.fd[0], gscReprocessingBuffer.size[0], 1, m_callbackCookie);
            setBit(&m_callbackState, CALLBACK_STATE_RAW_IMAGE, true);
            m_dataCb(CAMERA_MSG_RAW_IMAGE, rawCallbackHeap, 0, NULL, m_callbackCookie);
            clearBit(&m_callbackState, CALLBACK_STATE_RAW_IMAGE, true);
            rawCallbackHeap->release(rawCallbackHeap);
        }

        if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_RAW_IMAGE_NOTIFY)) {
            ALOGD("DEBUG(%s[%d]): RAW_IMAGE_NOTIFY callabck", __FUNCTION__, __LINE__);

            m_notifyCb(CAMERA_MSG_RAW_IMAGE_NOTIFY, 0, 0, m_callbackCookie);
        }

        if ((m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_POSTVIEW_FRAME))
           ) {
            ALOGD("DEBUG(%s[%d]): POSTVIEW callabck", __FUNCTION__, __LINE__);

            camera_memory_t *postviewCallbackHeap = NULL;
            postviewCallbackHeap = m_getMemoryCb(gscReprocessingBuffer.fd[0], gscReprocessingBuffer.size[0], 1, m_callbackCookie);
            setBit(&m_callbackState, CALLBACK_STATE_POSTVIEW_FRAME, true);
            m_dataCb(CAMERA_MSG_POSTVIEW_FRAME, postviewCallbackHeap, 0, NULL, m_callbackCookie);
            clearBit(&m_callbackState, CALLBACK_STATE_POSTVIEW_FRAME, true);
            postviewCallbackHeap->release(postviewCallbackHeap);
        }
    }

    /* Make compressed image */
    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_COMPRESSED_IMAGE) ||
        m_exynosCameraParameters->getSeriesShotCount() > 0 ||
        m_hdrEnabled == true) {

        /* HDR callback */
        if (m_hdrEnabled == true ||
                currentSeriesShotMode == SERIES_SHOT_MODE_LLS ||
                currentSeriesShotMode == SERIES_SHOT_MODE_SIS) {
            ALOGD("DEBUG(%s[%d]): HDR callback", __FUNCTION__, __LINE__);

            /* send yuv image with jpeg callback */
            camera_memory_t    *jpegCallbackHeap = NULL;
            jpegCallbackHeap = m_getMemoryCb(gscReprocessingBuffer.fd[0], gscReprocessingBuffer.size[0], 1, m_callbackCookie);

            m_dataCb(CAMERA_MSG_COMPRESSED_IMAGE, jpegCallbackHeap, 0, NULL, m_callbackCookie);

            jpegCallbackHeap->release(jpegCallbackHeap);

            /* put GSC buffer */
            ret = m_putBuffers(bufferMgr, gscReprocessingBuffer.index);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):bufferMgr->putBuffers() fail, pipeId(%d), ret(%d)",
                        __FUNCTION__, __LINE__, pipeId_gsc, ret);
                goto CLEAN;
            }

            m_jpegCounter.decCount();
        } else {
            int retry = 0;

            /* 1. get wait available JPEG src buffer */
            do {
                bufIndex = -2;
                retry++;

                if (m_pictureEnabled == false) {
                    ALOGI("INFO(%s[%d]):m_pictureEnable is false", __FUNCTION__, __LINE__);
                    goto CLEAN;
                }
                if (m_jpegBufferMgr->getNumOfAvailableBuffer() > 0)
                    m_jpegBufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, &jpegReprocessingBuffer);

                if (bufIndex < 0) {
                    usleep(WAITING_TIME);

                    if (retry % 20 == 0) {
                        ALOGW("WRN(%s[%d]):retry JPEG getBuffer(%d) postPictureQ(%d)",
                                __FUNCTION__, __LINE__, bufIndex,
                                m_postPictureQ->getSizeOfProcessQ());
                        m_jpegBufferMgr->dump();
                    }
                }
                /* this will retry until 300msec */
            } while (bufIndex < 0 && retry < (TOTAL_WAITING_TIME / WAITING_TIME) && m_stopBurstShot == false);

            if (bufIndex < 0) {
                if (retry >= (TOTAL_WAITING_TIME / WAITING_TIME)) {
                    ALOGE("ERR(%s[%d]):getBuffer totally fail, retry(%d), m_stopBurstShot(%d)",
                            __FUNCTION__, __LINE__, retry, m_stopBurstShot);
                } else {
                    ALOGD("DEBUG(%s[%d]):getBuffer stopped, retry(%d), m_stopBurstShot(%d)",
                            __FUNCTION__, __LINE__, retry, m_stopBurstShot);
                }
                goto CLEAN;
            }

            /* 2. setup Frame Entity */
            ret = m_setupEntity(pipeId_jpeg, newFrame, &gscReprocessingBuffer, &jpegReprocessingBuffer);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):setupEntity fail, pipeId(%d), ret(%d)",
                        __FUNCTION__, __LINE__, pipeId_jpeg, ret);
                goto CLEAN;
            }

            /* 3. Q Set-up */
            m_pictureFrameFactory->setOutputFrameQToPipe(dstJpegReprocessingQ, pipeId_jpeg);

            /* 4. push the newFrame to pipe */
            m_pictureFrameFactory->pushFrameToPipe(&newFrame, pipeId_jpeg);

            /* 5. wait outputQ */
            ALOGI("INFO(%s[%d]):wait Jpeg output", __FUNCTION__, __LINE__);
            ret = dstJpegReprocessingQ->waitAndPopProcessQ(&newFrame);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
                /* TODO: doing exception handling */
                goto CLEAN;
            }
            if (newFrame == NULL) {
                ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
                goto CLEAN;
            }

            /* When Front camera dose not setEntityState because Front camera share preview and capture frames */
            if (getCameraId() == CAMERA_ID_BACK) {
                ret = newFrame->setEntityState(pipeId_jpeg, ENTITY_STATE_COMPLETE);
                if (ret < 0) {
                    ALOGE("ERR(%s[%d]):setEntityState(ENTITY_STATE_PROCESSING) fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_jpeg, ret);
                    return ret;
                }
            }

            /* put GSC buffer */
            ret = m_putBuffers(bufferMgr, gscReprocessingBuffer.index);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):bufferMgr->putBuffers() fail, pipeId(%d), ret(%d)",
                        __FUNCTION__, __LINE__, pipeId_gsc, ret);
                goto CLEAN;
            }

            int jpegOutputSize = newFrame->getJpegSize();
            ALOGI("INFO(%s[%d]):Jpeg output done, jpeg size(%d)", __FUNCTION__, __LINE__, jpegOutputSize);

            if (jpegOutputSize <= 0) {
                ALOGW("WRN(%s[%d]): jpegOutput size(%d) is invalid", __FUNCTION__, __LINE__, jpegOutputSize);
                jpegOutputSize = jpegReprocessingBuffer.size[0];
            }

            jpegReprocessingBuffer.size[0] = jpegOutputSize;

            /* push postProcess to call CAMERA_MSG_COMPRESSED_IMAGE */
            jpeg_callback_buffer_t jpegCallbackBuf;
            jpegCallbackBuf.buffer = jpegReprocessingBuffer;
retry:
            if ((m_exynosCameraParameters->getSeriesShotCount() > 0)
                ) {
                ;
            } else {
                jpegCallbackBuf.callbackNumber = 0;
                m_jpegCallbackQ->pushProcessQ(&jpegCallbackBuf);
            }

            m_jpegCounter.decCount();
        }
    } else {
        ALOGD("DEBUG(%s[%d]): Disabled compressed image", __FUNCTION__, __LINE__);

        /* put GSC buffer */
        ret = m_putBuffers(bufferMgr, gscReprocessingBuffer.index);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):bufferMgr->putBuffers() fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, pipeId_gsc, ret);
            goto CLEAN;
        }

        m_jpegCounter.decCount();
    }

    if (newFrame != NULL) {
        newFrame->printEntity();

        newFrame->frameUnlock();
        ret = m_removeFrameFromList(&m_postProcessList, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):remove frame from processList fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        }

        if (newFrame->isComplete() == true) {
            ALOGD("DEBUG(%s[%d]): Picture frame delete(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());
            delete newFrame;
            newFrame = NULL;
        } else {
            ALOGW("WRN(%s[%d]): Picture frame(%d) is not completed", __FUNCTION__, __LINE__, newFrame->getFrameCount());
        }
    }

    ALOGI("INFO(%s[%d]):postPicture thread complete, remaining count(%d)", __FUNCTION__, __LINE__, m_jpegCounter.getCount());

    if (m_jpegCounter.getCount() <= 0) {
        if (m_hdrEnabled == true) {
            ALOGI("INFO(%s[%d]): End of HDR capture!", __FUNCTION__, __LINE__);
            m_hdrEnabled = false;
            m_pictureEnabled = false;
        }
        if (currentSeriesShotMode == SERIES_SHOT_MODE_LLS ||
            currentSeriesShotMode == SERIES_SHOT_MODE_SIS) {
            ALOGI("INFO(%s[%d]): End of LLS/SIS capture!", __FUNCTION__, __LINE__);
            m_pictureEnabled = false;
        }

        ALOGD("DEBUG(%s[%d]): free gsc buffers", __FUNCTION__, __LINE__);
        m_gscBufferMgr->deinit();

        if (currentSeriesShotMode != SERIES_SHOT_MODE_BURST) {
            ALOGD("DEBUG(%s[%d]): clearList postProcessList, series shot mode(%d)", __FUNCTION__, __LINE__, currentSeriesShotMode);
            if (m_clearList(&m_postProcessList) < 0) {
                ALOGE("ERR(%s):m_clearList fail", __FUNCTION__);
            }
        }
    }

    if (m_postPictureQ->getSizeOfProcessQ() > 0) {
        ALOGD("DEBUG(%s[%d]):postPicture thread will run again)", __func__, __LINE__);
         loop = true;
    } else {
#if 0
        if (m_clearList(&m_postProcessList) < 0) {
            ALOGE("ERR(%s):m_clearList fail", __FUNCTION__);
        }
#endif
    }

    if (m_exynosCameraParameters->getScalableSensorMode()) {
        m_scalableSensorMgr.setMode(EXYNOS_CAMERA_SCALABLE_CHANGING);
        ret = m_restartPreviewInternal();
        if (ret < 0)
            ALOGE("(%s[%d]): restart preview internal fail", __FUNCTION__, __LINE__);
        m_scalableSensorMgr.setMode(EXYNOS_CAMERA_SCALABLE_NONE);
    }

    return loop;
CLEAN:

    if (m_postPictureQ->getSizeOfProcessQ() > 0)
        loop = true;

    return loop;
}

bool ExynosCameraHWImpl::m_jpegCallbackThreadFunc(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
    ALOGI("DEBUG(%s[%d]):", __FUNCTION__, __LINE__);

    int ret = 0;
    int retry = 0, maxRetry = 0;
    int loop = false;
    int seriesShotNumber = -1;

    jpeg_callback_buffer_t jpegCallbackBuf;
    ExynosCameraBuffer jpegCallbackBuffer;
    camera_memory_t *jpegCallbackHeap = NULL;

    jpegCallbackBuffer.index = -2;

    ExynosCameraActivityFlash *m_flashMgr = m_exynosCameraActivityControl->getFlashMgr();
    if (m_flashMgr->getNeedFlash() == true) {
        maxRetry = TOTAL_FLASH_WATING_COUNT;
    } else {
        maxRetry = TOTAL_WAITING_COUNT;
    }

    do {
        ret = m_jpegCallbackQ->waitAndPopProcessQ(&jpegCallbackBuf);
        if (ret < 0) {
            retry++;
            ALOGW("WARN(%s[%d]):jpegCallbackQ pop fail, retry(%d)", __FUNCTION__, __LINE__, retry);
        }
    } while(ret < 0 && retry < maxRetry && m_jpegCounter.getCount() > 0);

    if (ret < 0) {
        ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        loop = true;
        goto CLEAN;
    }

    jpegCallbackBuffer = jpegCallbackBuf.buffer;
    seriesShotNumber = jpegCallbackBuf.callbackNumber;

    ALOGD("DEBUG(%s[%d]):jpeg calllback is start", __FUNCTION__, __LINE__);

    /* Make compressed image */
    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_COMPRESSED_IMAGE) ||
        m_exynosCameraParameters->getSeriesShotCount() > 0) {
            m_captureLock.lock();
            camera_memory_t *jpegCallbackHeap = m_getJpegCallbackHeap(jpegCallbackBuffer, seriesShotNumber);
            if (jpegCallbackHeap == NULL) {
                ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
                /* TODO: doing exception handling */
                android_printAssert(NULL, LOG_TAG, "Cannot recoverable, assert!!!!");
            }

            setBit(&m_callbackState, CALLBACK_STATE_COMPRESSED_IMAGE, true);
            m_dataCb(CAMERA_MSG_COMPRESSED_IMAGE, jpegCallbackHeap, 0, NULL, m_callbackCookie);
            clearBit(&m_callbackState, CALLBACK_STATE_COMPRESSED_IMAGE, true);

            /* put JPEG callback buffer */
            if (m_jpegBufferMgr->putBuffer(jpegCallbackBuffer.index, EXYNOS_CAMERA_BUFFER_POSITION_NONE) != NO_ERROR)
                ALOGE("ERR(%s[%d]):putBuffer(%d) fail", __FUNCTION__, __LINE__, jpegCallbackBuffer.index);

            jpegCallbackHeap->release(jpegCallbackHeap);
    } else {
        ALOGD("DEBUG(%s[%d]): Disabled compressed image", __FUNCTION__, __LINE__);
    }

CLEAN:
    ALOGI("INFO(%s[%d]):jpeg callback thread complete, remaining count(%d)", __FUNCTION__, __LINE__, m_takePictureCounter.getCount());
    if (m_takePictureCounter.getCount() == 0) {
        m_pictureEnabled = false;
        m_clearJpegCallbackThread();
        m_captureLock.unlock();
    } else {
        m_captureLock.unlock();
    }

    return loop;
}

void ExynosCameraHWImpl::m_clearJpegCallbackThread(void)
{
    jpeg_callback_buffer_t jpegCallbackBuf;
    ExynosCameraBuffer jpegCallbackBuffer;

    ALOGI("INFO(%s[%d]): takePicture disabled, takePicture callback done takePictureCounter(%d)",
            __FUNCTION__, __LINE__, m_takePictureCounter.getCount());
    m_pictureEnabled = false;

    if (m_exynosCameraParameters->getUseDynamicScc() == true) {
        ALOGD("DEBUG(%s[%d]): Use dynamic bayer", __FUNCTION__, __LINE__);
        m_previewFrameFactory->setRequestSCC(false);
    }

    m_prePictureThread->requestExit();
    m_pictureThread->requestExit();
    m_postPictureThread->requestExit();
    m_jpegCallbackThread->requestExit();

    ALOGI("INFO(%s[%d]): wait m_prePictureThrad", __FUNCTION__, __LINE__);
    m_prePictureThread->requestExitAndWait();
    ALOGI("INFO(%s[%d]): wait m_pictureThrad", __FUNCTION__, __LINE__);
    m_pictureThread->requestExitAndWait();
    ALOGI("INFO(%s[%d]): wait m_postPictureThrad", __FUNCTION__, __LINE__);
    m_postPictureThread->requestExitAndWait();
    ALOGI("INFO(%s[%d]): wait m_jpegCallbackThrad", __FUNCTION__, __LINE__);
    m_jpegCallbackThread->requestExitAndWait();

    ALOGI("INFO(%s[%d]): All picture threads done", __FUNCTION__, __LINE__);

    while (m_jpegCallbackQ->getSizeOfProcessQ() > 0) {
        m_jpegCallbackQ->popProcessQ(&jpegCallbackBuf);
        jpegCallbackBuffer = jpegCallbackBuf.buffer;

        ALOGD("DEBUG(%s[%d]):put remaining jpeg buffer(index: %d)", __FUNCTION__, __LINE__, jpegCallbackBuffer.index);
        if (m_jpegBufferMgr->putBuffer(jpegCallbackBuffer.index, EXYNOS_CAMERA_BUFFER_POSITION_NONE) != NO_ERROR) {
            ALOGE("ERR(%s[%d]):putBuffer(%d) fail", __FUNCTION__, __LINE__, jpegCallbackBuffer.index);
        }
    }

    m_burst[JPEG_SAVE_THREAD0] = false;
    m_burst[JPEG_SAVE_THREAD1] = false;
    m_burst[JPEG_SAVE_THREAD2] = false;

    ALOGD("DEBUG(%s[%d]): clear postProcessList", __FUNCTION__, __LINE__);
    if (m_clearList(&m_postProcessList) < 0) {
        ALOGE("ERR(%s):m_clearList fail", __FUNCTION__);
    }

#if 1
    ALOGD("DEBUG(%s[%d]): clear postPictureQ", __FUNCTION__, __LINE__);
    m_postPictureQ->release();

    ALOGD("DEBUG(%s[%d]): clear dstSccReprocessingQ", __FUNCTION__, __LINE__);
    dstSccReprocessingQ->release();
#else
    ExynosCameraFrame *frame = NULL;

    ALOGD("DEBUG(%s[%d]): clear postPictureQ", __FUNCTION__, __LINE__);
    while(m_postPictureQ->getSizeOfProcessQ()) {
        m_postPictureQ->popProcessQ(&frame);
        if (frame != NULL) {
            delete frame;
            frame = NULL;
        }
    }

    ALOGD("DEBUG(%s[%d]): clear dstSccReprocessingQ", __FUNCTION__, __LINE__);
    while(dstSccReprocessingQ->getSizeOfProcessQ()) {
        dstSccReprocessingQ->popProcessQ(&frame);
        if (frame != NULL) {
            delete frame;
            frame = NULL;
        }
    }
#endif

    ALOGD("DEBUG(%s[%d]): free gsc buffers", __FUNCTION__, __LINE__);
    m_gscBufferMgr->deinit();
    ALOGD("DEBUG(%s[%d]): free jpeg buffers", __FUNCTION__, __LINE__);
    m_jpegBufferMgr->deinit();
    ALOGD("DEBUG(%s[%d]): free sccReprocessing buffers", __FUNCTION__, __LINE__);
    m_sccReprocessingBufferMgr->resetBuffers();
}

bool ExynosCameraHWImpl::m_highResolutionCallbackThreadFunc(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
    ALOGI("INFO(%s[%d]):", __FUNCTION__, __LINE__);

    int ret = 0;
    int loop = false;

    ExynosCameraFrame *newFrame = NULL;
    camera2_stream *shot_stream = NULL;

    ExynosCameraBuffer sccReprocessingBuffer;
    ExynosCameraBuffer highResolutionCbBuffer;
    ExynosCameraBufferManager *bufferMgr = NULL;

    int cbPreviewW = 0, cbPreviewH = 0;
    int previewFormat = 0;
    ExynosRect srcRect, dstRect;
    m_exynosCameraParameters->getPreviewSize(&cbPreviewW, &cbPreviewH);
    previewFormat = m_exynosCameraParameters->getPreviewFormat();

    int pipeId_scc = 0;
    int pipeId_gsc = 0;

    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    int planeCount = getYuvPlaneCount(previewFormat);
    int minBufferCount = 1;
    int maxBufferCount = 1;

    sccReprocessingBuffer.index = -2;
    highResolutionCbBuffer.index = -2;

    pipeId_scc = PIPE_SCC_REPROCESSING;
    pipeId_gsc = PIPE_GSC_REPROCESSING;

    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_CACHED_TYPE;
    buffer_manager_allocation_mode_t allocMode = BUFFER_MANAGER_ALLOCATION_ONDEMAND;

    if (m_exynosCameraParameters->getHighResolutionCallbackMode() == false &&
        m_highResolutionCallbackRunning == false) {
        ALOGD("DEBUG(%s[%d]): High Resolution Callback Stop", __FUNCTION__, __LINE__);
        goto CLEAN;
    }

    if (m_exynosCameraParameters->getHighResolutionCallbackMode() == false &&
        m_highResolutionCallbackRunning == false) {
        ALOGD("DEBUG(%s[%d]): High Resolution Callback Stop", __FUNCTION__, __LINE__);
        goto CLEAN;
    }

    ret = getYuvPlaneSize(previewFormat, planeSize, cbPreviewW, cbPreviewH);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): BAD value, format(%x), size(%dx%d)",
            __FUNCTION__, __LINE__, previewFormat, cbPreviewW, cbPreviewH);
        return ret;
    }

    /* wait SCC */
    ALOGV("INFO(%s[%d]):wait SCC output", __FUNCTION__, __LINE__);
    ret = m_highResolutionCallbackQ->waitAndPopProcessQ(&newFrame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        // TODO: doing exception handling
        goto CLEAN;
    }
    if (newFrame == NULL) {
        ALOGE("ERR(%s[%d]):newFrame is NULL", __FUNCTION__, __LINE__);
        goto CLEAN;
    }
    ALOGV("INFO(%s[%d]):SCC output done", __FUNCTION__, __LINE__);

    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_PREVIEW_FRAME)) {
        /* get GSC src buffer */
        ret = newFrame->getDstBuffer(pipeId_scc, &sccReprocessingBuffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)",
                    __FUNCTION__, __LINE__, pipeId_scc, ret);
            goto CLEAN;
        }

        shot_stream = (struct camera2_stream *)(sccReprocessingBuffer.addr[1]);

        /* alloc GSC buffer */
        if (m_highResolutionCallbackBufferMgr->isAllocated() == false) {
            ret = m_allocBuffers(m_highResolutionCallbackBufferMgr, planeCount, planeSize, bytesPerLine, minBufferCount, maxBufferCount, type, allocMode, false, false);
            if (ret < 0) {
                ALOGE("ERR(%s[%d]):m_highResolutionCallbackBufferMgr m_allocBuffers(minBufferCount=%d, maxBufferCount=%d) fail",
                    __FUNCTION__, __LINE__, minBufferCount, maxBufferCount);
                return ret;
            }
        }

        /* get GSC dst buffer */
        int bufIndex = -2;
        m_highResolutionCallbackBufferMgr->getBuffer(&bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_IN_HAL, &highResolutionCbBuffer);

        /* get preview callback heap */
        camera_memory_t *previewCallbackHeap = NULL;
        previewCallbackHeap = m_getMemoryCb(highResolutionCbBuffer.fd[0], highResolutionCbBuffer.size[0], 1, m_callbackCookie);

        ret = m_setCallbackBufferInfo(&highResolutionCbBuffer, (char *)previewCallbackHeap->data);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]): setCallbackBufferInfo fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            goto CLEAN;
        }

        /* set src/dst rect */
        srcRect.x = shot_stream->output_crop_region[0];
        srcRect.y = shot_stream->output_crop_region[1];
        srcRect.w = shot_stream->output_crop_region[2];
        srcRect.h = shot_stream->output_crop_region[3];

        ret = m_calcHighResolutionPreviewGSCRect(&srcRect, &dstRect);
        ret = newFrame->setSrcRect(pipeId_gsc, &srcRect);
        ret = newFrame->setDstRect(pipeId_gsc, &dstRect);

        ALOGV("DEBUG(%s[%d]):srcRect x : %d, y : %d, w : %d, h : %d", __FUNCTION__, __LINE__, srcRect.x, srcRect.y, srcRect.w, srcRect.h);
        ALOGV("DEBUG(%s[%d]):dstRect x : %d, y : %d, w : %d, h : %d", __FUNCTION__, __LINE__, dstRect.x, dstRect.y, dstRect.w, dstRect.h);

        ret = m_setupEntity(pipeId_gsc, newFrame, &sccReprocessingBuffer, &highResolutionCbBuffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):setupEntity fail, pipeId(%d), ret(%d)",
                __FUNCTION__, __LINE__, pipeId_gsc, ret);
            goto CLEAN;
        }

        /* push frame to GSC pipe */
        m_pictureFrameFactory->pushFrameToPipe(&newFrame, pipeId_gsc);
        m_pictureFrameFactory->setOutputFrameQToPipe(dstGscReprocessingQ, pipeId_gsc);

        /* wait GSC for high resolution preview callback */
        ALOGI("INFO(%s[%d]):wait GSC output", __FUNCTION__, __LINE__);
        ret = dstGscReprocessingQ->waitAndPopProcessQ(&newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s)(%d):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
            /* TODO: doing exception handling */
            goto CLEAN;
        }
        if (newFrame == NULL) {
            ALOGE("ERR(%s):newFrame is NULL", __FUNCTION__);
            goto CLEAN;
        }
        ALOGI("INFO(%s[%d]):GSC output done", __FUNCTION__, __LINE__);

        /* put SCC buffer */
        ret = newFrame->getDstBuffer(pipeId_scc, &sccReprocessingBuffer);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):getDstBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_scc, ret);
            goto CLEAN;
        }
        ret = m_putBuffers(m_sccReprocessingBufferMgr, sccReprocessingBuffer.index);

        ALOGV("DEBUG(%s[%d]):high resolution preview callback", __FUNCTION__, __LINE__);
        if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_PREVIEW_FRAME)) {
            setBit(&m_callbackState, CALLBACK_STATE_PREVIEW_FRAME, false);
            m_dataCb(CAMERA_MSG_PREVIEW_FRAME, previewCallbackHeap, 0, NULL, m_callbackCookie);
            clearBit(&m_callbackState, CALLBACK_STATE_PREVIEW_FRAME, false);
        }

        previewCallbackHeap->release(previewCallbackHeap);

        /* put high resolution callback buffer */
        ret = m_putBuffers(m_highResolutionCallbackBufferMgr, highResolutionCbBuffer.index);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_putBuffers fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId_gsc, ret);
            goto CLEAN;
        }
    }

    if (newFrame != NULL) {
        newFrame->printEntity();

        newFrame->frameUnlock();
        ret = m_removeFrameFromList(&m_postProcessList, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):remove frame from processList fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        }

        if (newFrame->isComplete() == true) {
            ALOGD("DEBUG(%s[%d]): Reprocessing frame delete(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());
            delete newFrame;
            newFrame = NULL;
        }
    }

    if (m_highResolutionCallbackQ->getSizeOfProcessQ() > 0) {
        ALOGD("DEBUG(%s[%d]):highResolutionCallbackQ size %d", __FUNCTION__, __LINE__, m_highResolutionCallbackQ->getSizeOfProcessQ());
        loop = true;
    }

    ALOGI("INFO(%s[%d]):high resolution callback thread complete", __FUNCTION__, __LINE__);

    /* one shot */
    return loop;

CLEAN:
    if (sccReprocessingBuffer.index != -2)
        ret = m_putBuffers(m_sccReprocessingBufferMgr, sccReprocessingBuffer.index);
    if (highResolutionCbBuffer.index != -2)
        m_putBuffers(m_highResolutionCallbackBufferMgr, highResolutionCbBuffer.index);

    if (newFrame != NULL) {
        newFrame->printEntity();

        newFrame->frameUnlock();
        ret = m_removeFrameFromList(&m_postProcessList, newFrame);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):remove frame from processList fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        }

        if (newFrame->isComplete() == true) {
            ALOGD("DEBUG(%s[%d]): Reprocessing frame delete(%d)", __FUNCTION__, __LINE__, newFrame->getFrameCount());
            delete newFrame;
            newFrame = NULL;
        }
    }

    if (m_highResolutionCallbackQ->getSizeOfProcessQ() > 0)
        loop = true;

    ALOGI("INFO(%s[%d]):high resolution callback thread fail", __FUNCTION__, __LINE__);

    /* one shot */
    return loop;
}

status_t ExynosCameraHWImpl::m_doPrviewToRecordingFunc(
        int32_t pipeId,
        ExynosCameraBuffer previewBuf,
        ExynosCameraBuffer recordingBuf)
{
#ifdef DEBUG
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
#endif

    ALOGV("DEBUG(%s[%d]):--IN-- (previewBuf.index=%d, recordingBuf.index=%d)",
        __FUNCTION__, __LINE__, previewBuf.index, recordingBuf.index);

    status_t ret = NO_ERROR;
    ExynosRect srcRect, dstRect;
    ExynosCameraFrame  *newFrame = NULL;

    newFrame = m_previewFrameFactory->createNewFrameVideoOnly();
    if (newFrame == NULL) {
        ALOGE("ERR(%s):newFrame is NULL", __FUNCTION__);
        return UNKNOWN_ERROR;
    }

    /* csc and scaling */
    ret = m_calcRecordingGSCRect(&srcRect, &dstRect);
    ret = newFrame->setSrcRect(pipeId, srcRect);
    ret = newFrame->setDstRect(pipeId, dstRect);

    ret = m_setupEntity(pipeId, newFrame, &previewBuf, &recordingBuf);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setupEntity fail, pipeId(%d), ret(%d)",
            __FUNCTION__, __LINE__, pipeId, ret);
        ret = INVALID_OPERATION;
        if (newFrame != NULL) {
            delete newFrame;
            newFrame = NULL;
        }
        goto func_exit;
    }
    m_previewFrameFactory->pushFrameToPipe(&newFrame, pipeId);
    m_previewFrameFactory->setOutputFrameQToPipe(m_recordingQ, pipeId);

func_exit:

    ALOGV("DEBUG(%s[%d]):--OUT--", __FUNCTION__, __LINE__);
    return ret;

}

bool ExynosCameraHWImpl::m_recordingThreadFunc(void)
{
#ifdef DEBUG
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);
#endif

    int  ret  = 0;
    bool loop = false;
    int  pipeId = 0;
    nsecs_t timeStamp = 0;

    ExynosCameraBuffer buffer;
    ExynosCameraFrame  *frame = NULL;

    if (getCameraId() == CAMERA_ID_BACK)
        pipeId = PIPE_GSC_VIDEO;
    else
        pipeId = PIPE_GSC_VIDEO_FRONT;

    ALOGV("INFO(%s[%d]):wait gsc done output", __FUNCTION__, __LINE__);
    ret = m_recordingQ->waitAndPopProcessQ(&frame);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):wait and pop fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        ret = INVALID_OPERATION;
        goto func_exit;
    }
    if (frame == NULL) {
        ALOGE("ERR(%s[%d]):frame is NULL", __FUNCTION__, __LINE__);
        ret = INVALID_OPERATION;
        goto func_exit;
    }
    ALOGV("INFO(%s[%d]):gsc done for recording callback", __FUNCTION__, __LINE__);

    ret = frame->getDstBuffer(pipeId, &buffer);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):getDstBuffer fail, ret(%d)", __FUNCTION__, __LINE__, ret);
        /* TODO: doing exception handling */
        goto func_exit;
    }

    if (buffer.index < 0 || buffer.index >= (int)m_exynosconfig->current->bufInfo.num_recording_buffers) {
        ALOGE("ERR(%s[%d]):Out of Index! (Max: %d, Index: %d)", __FUNCTION__, __LINE__, m_exynosconfig->current->bufInfo.num_recording_buffers, buffer.index);
        goto func_exit;
    }

    timeStamp = m_recordingTimeStamp[buffer.index];

    if (m_recordingStartTimeStamp == 0) {
        m_recordingStartTimeStamp = timeStamp;
        ALOGI("INFO(%s[%d]):m_recordingStartTimeStamp=%lld",
                __FUNCTION__, __LINE__, m_recordingStartTimeStamp);
    }

    if ((0L < timeStamp)
        && (m_lastRecordingTimeStamp < timeStamp)
        && (m_recordingStartTimeStamp <= timeStamp)) {
        if (m_recordingEnabled == true
            && m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_VIDEO_FRAME)) {
#ifdef CHECK_MONOTONIC_TIMESTAMP
            ALOGD("DEBUG(%s[%d]):m_dataCbTimestamp::recordingFrameIndex=%d, recordingTimeStamp=%lld",
                __FUNCTION__, __LINE__, buffer.index, timeStamp);
#endif
#ifdef DEBUG
            ALOGD("DEBUG(%s[%d]): - lastTimeStamp(%lld), systemTime(%lld), recordingStart(%lld)",
                __FUNCTION__, __LINE__,
                m_lastRecordingTimeStamp,
                systemTime(SYSTEM_TIME_MONOTONIC),
                m_recordingStartTimeStamp);
#endif
            struct addrs *recordAddrs = NULL;

            recordAddrs = (struct addrs *)m_recordingCallbackHeap->data;
            recordAddrs[buffer.index].type        = kMetadataBufferTypeCameraSource;
            recordAddrs[buffer.index].fdPlaneY    = (unsigned int)buffer.fd[0];
            recordAddrs[buffer.index].fdPlaneCbcr = (unsigned int)buffer.fd[1];
            recordAddrs[buffer.index].bufIndex    = buffer.index;

            m_dataCbTimestamp(
                    timeStamp,
                    CAMERA_MSG_VIDEO_FRAME,
                    m_recordingCallbackHeap,
                    buffer.index,
                    m_callbackCookie);
            m_lastRecordingTimeStamp = timeStamp;
        }
    } else {
        ALOGW("WARN(%s[%d]):recordingFrameIndex=%d, timeStamp(%lld) invalid -"
            " lastTimeStamp(%lld), systemTime(%lld), recordingStart(%lld)",
            __FUNCTION__, __LINE__, buffer.index, timeStamp,
            m_lastRecordingTimeStamp,
            systemTime(SYSTEM_TIME_MONOTONIC),
            m_recordingStartTimeStamp);
        m_releaseRecordingBuffer(buffer.index);
    }

func_exit:

    if (frame != NULL) {
        delete frame;
        frame = NULL;
    }

    if (m_recordingQ->getSizeOfProcessQ() > 0)
        loop = true;

    return loop;
}

status_t ExynosCameraHWImpl::m_releaseRecordingBuffer(int bufIndex)
{
    status_t ret = NO_ERROR;

    if (bufIndex < 0 || bufIndex >= (int)m_exynosconfig->current->bufInfo.num_recording_buffers) {
        ALOGE("ERR(%s):Out of Index! (Max: %d, Index: %d)", __FUNCTION__, m_exynosconfig->current->bufInfo.num_recording_buffers, bufIndex);
        ret = INVALID_OPERATION;
        goto func_exit;
    }

    m_recordingTimeStamp[bufIndex] = 0L;
    ret = m_putBuffers(m_recordingBufferMgr, bufIndex);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):put Buffer fail", __FUNCTION__, __LINE__);
    }

func_exit:

    return ret;
}

status_t ExynosCameraHWImpl::m_calcPreviewGSCRect(ExynosRect *srcRect, ExynosRect *dstRect)
{
    return m_exynosCameraParameters->calcPreviewGSCRect(srcRect, dstRect);
}

status_t ExynosCameraHWImpl::m_calcHighResolutionPreviewGSCRect(ExynosRect *srcRect, ExynosRect *dstRect)
{
    return m_exynosCameraParameters->calcHighResolutionPreviewGSCRect(srcRect, dstRect);
}

status_t ExynosCameraHWImpl::m_calcRecordingGSCRect(ExynosRect *srcRect, ExynosRect *dstRect)
{
    return m_exynosCameraParameters->calcRecordingGSCRect(srcRect, dstRect);
}

status_t ExynosCameraHWImpl::m_calcPictureRect(ExynosRect *srcRect, ExynosRect *dstRect)
{
    return m_exynosCameraParameters->calcPictureRect(srcRect, dstRect);
}

status_t ExynosCameraHWImpl::m_calcPictureRect(int originW, int originH, ExynosRect *srcRect, ExynosRect *dstRect)
{
    return m_exynosCameraParameters->calcPictureRect(originW, originH, srcRect, dstRect);
}

status_t ExynosCameraHWImpl::m_searchFrameFromList(List<ExynosCameraFrame *> *list, uint32_t frameCount, ExynosCameraFrame **frame)
{
    int ret = 0;
    ExynosCameraFrame *curFrame = NULL;
    List<ExynosCameraFrame *>::iterator r;

    if (list->empty()) {
        ALOGD("DEBUG(%s[%d]):list is empty", __FUNCTION__, __LINE__);
        return NO_ERROR;
    }

    r = list->begin()++;

    do {
        curFrame = *r;
        if (curFrame == NULL) {
            ALOGE("ERR(%s):curFrame is empty", __FUNCTION__);
            return INVALID_OPERATION;
        }

        if (frameCount == curFrame->getFrameCount()) {
            ALOGV("DEBUG(%s):frame count match: expected(%d)", __FUNCTION__, frameCount);
            *frame = curFrame;
            return NO_ERROR;
        }
        r++;
    } while (r != list->end());

    ALOGV("DEBUG(%s[%d]):Cannot find match frame, frameCount(%d)", __FUNCTION__, __LINE__, frameCount);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_removeFrameFromList(List<ExynosCameraFrame *> *list, ExynosCameraFrame *frame)
{
    int ret = 0;
    ExynosCameraFrame *curFrame = NULL;
    int frameCount = 0;
    int curFrameCount = 0;
    List<ExynosCameraFrame *>::iterator r;

    if (frame == NULL) {
        ALOGE("ERR(%s):frame is NULL", __FUNCTION__);
        return BAD_VALUE;
    }

    if (list->empty()) {
        ALOGE("ERR(%s):list is empty", __FUNCTION__);
        return INVALID_OPERATION;
    }

    frameCount = frame->getFrameCount();
    r = list->begin()++;

    do {
        curFrame = *r;
        if (curFrame == NULL) {
            ALOGE("ERR(%s):curFrame is empty", __FUNCTION__);
            return INVALID_OPERATION;
        }

        curFrameCount = curFrame->getFrameCount();
        if (frameCount == curFrameCount) {
            ALOGV("DEBUG(%s):frame count match: expected(%d), current(%d)", __FUNCTION__, frameCount, curFrameCount);
            list->erase(r);
            return NO_ERROR;
        }
        ALOGW("WARN(%s):frame count mismatch: expected(%d), current(%d)", __FUNCTION__, frameCount, curFrameCount);
        /* removed message */
        /* curFrame->printEntity(); */
        r++;
    } while (r != list->end());

    ALOGE("ERR(%s):Cannot find match frame!!!", __FUNCTION__);

    return INVALID_OPERATION;
}

status_t ExynosCameraHWImpl::m_clearList(List<ExynosCameraFrame *> *list)
{
    int ret = 0;
    ExynosCameraFrame *curFrame = NULL;
    List<ExynosCameraFrame *>::iterator r;

    ALOGD("DEBUG(%s):remaining frame(%d), we remove them all", __FUNCTION__, list->size());

    while (!list->empty()) {
        r = list->begin()++;
        curFrame = *r;
        if (curFrame != NULL && curFrame->getFrameLockState() == false) {
            ALOGV("DEBUG(%s):remove frame count %d", __FUNCTION__, curFrame->getFrameCount() );
            delete curFrame;
            curFrame = NULL;
        }
        list->erase(r);
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_printFrameList(List<ExynosCameraFrame *> *list)
{
    int ret = 0;
    ExynosCameraFrame *curFrame = NULL;
    List<ExynosCameraFrame *>::iterator r;

    ALOGE("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
    ALOGD("\t remaining frame count(%d)", list->size());

    r = list->begin()++;

    do {
        curFrame = *r;
        if (curFrame != NULL) {
            ALOGI("\t hal frame count %d", curFrame->getFrameCount() );
            curFrame->printEntity();
        }

        r++;
    } while (r != list->end());
    ALOGE("----------------------------------------------------------------------------");

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_createIonAllocator(ExynosCameraIonAllocator **allocator)
{
    status_t ret = NO_ERROR;
    int retry = 0;
    do {
        retry++;
        ALOGI("INFO(%s[%d]):try(%d) to create IonAllocator", __FUNCTION__, __LINE__, retry);
        *allocator = new ExynosCameraIonAllocator();
        ret = (*allocator)->init(false);
        if (ret < 0)
            ALOGE("ERR(%s[%d]):create IonAllocator fail (retryCount=%d)", __FUNCTION__, __LINE__, retry);
        else {
            ALOGD("DEBUG(%s[%d]):m_createIonAllocator success (allocator=%p)", __FUNCTION__, __LINE__, *allocator);
            break;
        }
    } while (ret < 0 && retry < 3);

    if (ret < 0 && retry >=3) {
        ALOGE("ERR(%s[%d]):create IonAllocator fail (retryCount=%d)", __FUNCTION__, __LINE__, retry);
        ret = INVALID_OPERATION;
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_createInternalBufferManager(ExynosCameraBufferManager **bufferManager, const char *name)
{
    return m_createBufferManager(bufferManager, name, BUFFER_MANAGER_ION_TYPE);
}

status_t ExynosCameraHWImpl::m_createBufferManager(
        ExynosCameraBufferManager **bufferManager,
        const char *name,
        buffer_manager_type type)
{
    status_t ret = NO_ERROR;

    if (m_ionAllocator == NULL) {
        ret = m_createIonAllocator(&m_ionAllocator);
        if (ret < 0)
            ALOGE("ERR(%s[%d]):m_createIonAllocator fail", __FUNCTION__, __LINE__);
        else
            ALOGD("DEBUG(%s[%d]):m_createIonAllocator success", __FUNCTION__, __LINE__);
    }

    *bufferManager = ExynosCameraBufferManager::createBufferManager(type);
    (*bufferManager)->create(name, m_ionAllocator);

    ALOGD("DEBUG(%s):BufferManager(%s) created", __FUNCTION__, name);

    return ret;
}

bool ExynosCameraHWImpl::m_releasebuffersForRealloc()
{
    status_t ret = NO_ERROR;
    /* skip to free and reallocate buffers : flite / 3aa / isp / ispReprocessing */
    ALOGE(" m_setBuffers free all buffers");
    if (m_bayerBufferMgr != NULL) {
        m_bayerBufferMgr->deinit();
    }
    if (m_3aaBufferMgr != NULL) {
        m_3aaBufferMgr->deinit();
    }
    if (m_ispBufferMgr != NULL) {
        m_ispBufferMgr->deinit();
    }

    /* realloc callback buffers */
    if (m_scpBufferMgr != NULL) {
        m_scpBufferMgr->deinit();
        m_scpBufferMgr->setBufferCount(0);
    }

    if (m_sccBufferMgr != NULL) {
        m_sccBufferMgr->deinit();
    }

#ifdef SAMSUNG_MAGICSHOT
    if (m_frontgscBufferMgr != NULL) {
        m_frontgscBufferMgr->deinit();
    }
#endif

    if (m_previewCallbackBufferMgr != NULL) {
        m_previewCallbackBufferMgr->deinit();
    }
    if (m_highResolutionCallbackBufferMgr != NULL) {
        m_highResolutionCallbackBufferMgr->deinit();
    }

    m_exynosCameraParameters->setReallocBuffer(false);

    if (m_exynosCameraParameters->getRestartPreview() == true) {
        ret = setPreviewWindow(m_previewWindow);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):setPreviewWindow fail", __FUNCTION__, __LINE__);
            return INVALID_OPERATION;
        }

        ALOGE("INFO(%s[%d]) m_resetPreview(%d)", __FUNCTION__, __LINE__, m_resetPreview);
        if (ret < 0) {
            ALOGE("(%s[%d]): restart preview internal fail", __FUNCTION__, __LINE__);
            return INVALID_OPERATION;
        }
    }

   return true;
}


status_t ExynosCameraHWImpl::m_setBuffers(void)
{
    ExynosCameraAutoTimer autoTimer(__FUNCTION__);

    ALOGI("INFO(%s[%d]):alloc buffer - camera ID: %d",
        __FUNCTION__, __LINE__, m_cameraId);
    int ret = 0;
    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES]    = {0};
    int hwPreviewW, hwPreviewH;
    int hwPictureW, hwPictureH;

    int previewMaxW, previewMaxH;
    int sensorMaxW, sensorMaxH;

    int planeCount  = 1;
    int minBufferCount = 1;
    int maxBufferCount = 1;
    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE;

#if 1
    if( m_exynosCameraParameters->getReallocBuffer() ) {
        /* skip to free and reallocate buffers : flite / 3aa / isp / ispReprocessing */
        m_releasebuffersForRealloc();
    }
#endif

    m_exynosCameraParameters->getHwPreviewSize(&hwPreviewW, &hwPreviewH);
    ALOGI("(%s):HW Preview width x height = %dx%d", __FUNCTION__, hwPreviewW, hwPreviewH);
    m_exynosCameraParameters->getHwPictureSize(&hwPictureW, &hwPictureH);
    ALOGI("(%s):HW Picture width x height = %dx%d", __FUNCTION__, hwPictureW, hwPictureH);
    if( m_exynosCameraParameters->getHighSpeedRecording() ) {
        m_exynosCameraParameters->getHwSensorSize(&sensorMaxW, &sensorMaxH);
        ALOGI("(%s):HW Sensor(HighSpeed) MAX width x height = %dx%d", __FUNCTION__, sensorMaxW, sensorMaxH);
        m_exynosCameraParameters->getHwPreviewSize(&previewMaxW, &previewMaxH);
        ALOGI("(%s):HW Preview(HighSpeed) MAX width x height = %dx%d", __FUNCTION__, previewMaxW, previewMaxH);
    } else {
        m_exynosCameraParameters->getMaxSensorSize(&sensorMaxW, &sensorMaxH);
        ALOGI("(%s):HW Sensor MAX width x height = %dx%d", __FUNCTION__, sensorMaxW, sensorMaxH);
        m_exynosCameraParameters->getMaxPreviewSize(&previewMaxW, &previewMaxH);
        ALOGI("(%s):HW Preview MAX width x height = %dx%d", __FUNCTION__, previewMaxW, previewMaxH);
    }

    /* FLITE */
#ifdef CAMERA_PACKED_BAYER_ENABLE
#ifdef DEBUG_RAWDUMP
    if (m_exynosCameraParameters->checkBayerDumpEnable()) {
        bytesPerLine[0] = (sensorMaxW + 16) * 2;
        planeSize[0] = (sensorMaxW + 16) * (sensorMaxH + 10) * 2;
    } else
#endif /* DEBUG_RAWDUMP */
    {
        bytesPerLine[0] = ROUND_UP((sensorMaxW + 16), 10) * 8 / 5;
        planeSize[0]    = bytesPerLine[0] * (sensorMaxH + 10);
    }
#else
    planeSize[0] = (sensorMaxW + 16) * (sensorMaxH + 10) * 2;
#endif
    planeCount  = 2;

    /* TO DO : make num of buffers samely */
    if (getCameraId() == CAMERA_ID_BACK) {
        maxBufferCount =  m_exynosconfig->current->bufInfo.num_bayer_buffers;
#ifdef RESERVED_MEMORY_ENABLE
        type = EXYNOS_CAMERA_BUFFER_ION_RESERVED_TYPE;
#endif
    } else {
        maxBufferCount = m_exynosconfig->current->bufInfo.front_num_bayer_buffers;
    }

    ret = m_allocBuffers(m_bayerBufferMgr, planeCount, planeSize, bytesPerLine, maxBufferCount, maxBufferCount, type, true, false);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):bayerBuffer m_allocBuffers(bufferCount=%d) fail",
            __FUNCTION__, __LINE__, maxBufferCount);
        return ret;
    }

    type = EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE;

#ifdef CAMERA_PACKED_BAYER_ENABLE
    memset(&bytesPerLine, 0, sizeof(unsigned int) * EXYNOS_CAMERA_BUFFER_MAX_PLANES);
#endif

    /* for preview */
    planeSize[0] = 32 * 64 * 2;
    planeCount  = 2;
    /* TO DO : make num of buffers samely */
    if (getCameraId())
        maxBufferCount = m_exynosconfig->current->bufInfo.front_num_bayer_buffers;
    else
        maxBufferCount = m_exynosconfig->current->bufInfo.num_bayer_buffers;

    ret = m_allocBuffers(m_3aaBufferMgr, planeCount, planeSize, bytesPerLine, maxBufferCount, true, false);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_3aaBufferMgr m_allocBuffers(bufferCount=%d) fail",
            __FUNCTION__, __LINE__, maxBufferCount);
        return ret;
    }

    if (getCameraId() == CAMERA_ID_BACK) {
#ifdef CAMERA_PACKED_BAYER_ENABLE
#ifdef DEBUG_RAWDUMP
        if (m_exynosCameraParameters->checkBayerDumpEnable()) {
            bytesPerLine[0] = previewMaxW * 2;
            planeSize[0] = previewMaxW * previewMaxH * 2;
        } else
#endif /* DEBUG_RAWDUMP */
        {
            bytesPerLine[0] = ROUND_UP((sensorMaxW * 3 / 2), 16);
            planeSize[0]    = bytesPerLine[0] * sensorMaxH;
        }
#else
        /* planeSize[0] = width * height * 2; */
        planeSize[0] = previewMaxW * previewMaxH * 2;
#endif
    } else {
#ifdef CAMERA_PACKED_BAYER_ENABLE
#ifdef DEBUG_RAWDUMP
        if (m_exynosCameraParameters->checkBayerDumpEnable()) {
            bytesPerLine[0] = sensorMaxW * 2;
            planeSize[0] = sensorMaxW * sensorMaxH * 2;
        } else
#endif /* DEBUG_RAWDUMP */
        {
            bytesPerLine[0] = ROUND_UP((sensorMaxW * 3 / 2), 16);
            planeSize[0]    = bytesPerLine[0] * sensorMaxH;
        }
#else
        /* planeSize[0] = width * height * 2; */
        planeSize[0] = sensorMaxW * sensorMaxH * 2;
#endif
    }
    planeCount  = 2;
    /* TO DO : make num of buffers samely */
    if (getCameraId())
        maxBufferCount = m_exynosconfig->current->bufInfo.front_num_bayer_buffers;
    else
        maxBufferCount = m_exynosconfig->current->bufInfo.num_bayer_buffers;

    ret = m_allocBuffers(m_ispBufferMgr, planeCount, planeSize, bytesPerLine, maxBufferCount, true, false);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_ispBufferMgr m_allocBuffers(bufferCount=%d) fail",
            __FUNCTION__, __LINE__, maxBufferCount);
        return ret;
    }

    planeSize[0] = hwPreviewW * hwPreviewH;
    planeSize[1] = hwPreviewW * hwPreviewH / 2;
    planeCount  = 3;
    if( m_exynosCameraParameters->getShotMode() == SHOT_MODE_BEAUTY_FACE ) {
        maxBufferCount = m_exynosCameraParameters->getPreviewBufferCount();
    } else {
        maxBufferCount = m_exynosconfig->current->bufInfo.num_preview_buffers;
    }


    bool needMmap = false;
    if (m_previewWindow == NULL)
        needMmap = true;

    ret = m_allocBuffers(m_scpBufferMgr, planeCount, planeSize, bytesPerLine, maxBufferCount, true, needMmap);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_scpBufferMgr m_allocBuffers(bufferCount=%d) fail",
            __FUNCTION__, __LINE__, maxBufferCount);
        return ret;
    }

#ifdef USE_BUFFER_WITH_STRIDE
    int stride = m_scpBufferMgr->getBufStride();
    if (stride != hwPreviewW) {
        ALOGI("INFO(%s[%d]):hwPreviewW(%d), stride(%d)", __FUNCTION__, __LINE__, hwPreviewW, stride);
        if (stride == 0) {
            /* If the SCP buffer manager is not instance of GrallocExynosCameraBufferManager
               (In case of setPreviewWindow(null) is called), return value of setHwPreviewStride()
               will be zero. If this value is passed as SCP width to firmware, firmware will
               generate PABORT error. */
            ALOGW("WARN(%s[%d]):HACK: Invalid stride(%d). It will be replaced as hwPreviewW(%d) value.",
                __FUNCTION__, __LINE__, stride, hwPreviewW);
            stride = hwPreviewW;
        }
    }
    m_exynosCameraParameters->setHwPreviewStride(stride);
#endif

    if (getCameraId() == CAMERA_ID_FRONT) {
        m_exynosCameraParameters->getHwPictureSize(&hwPictureW, &hwPictureH);
        ALOGI("(%s):HW Picture width x height = %dx%d", __FUNCTION__, hwPictureW, hwPictureH);
        planeSize[0] = ALIGN_UP(hwPictureW, GSCALER_IMG_ALIGN) * ALIGN_UP(hwPictureH, GSCALER_IMG_ALIGN) * 2;
        planeCount  = 2;
        /* TO DO : make same num of buffers */
        if (getCameraId())
            maxBufferCount = m_exynosconfig->current->bufInfo.front_num_bayer_buffers;
        else
            maxBufferCount = m_exynosconfig->current->bufInfo.num_picture_buffers;

        ret = m_allocBuffers(m_sccBufferMgr, planeCount, planeSize, bytesPerLine, maxBufferCount, true, false);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_sccBufferMgr m_allocBuffers(bufferCount=%d) fail",
                __FUNCTION__, __LINE__, maxBufferCount);
            return ret;
        }
    }

    ALOGI("INFO(%s[%d]):alloc buffer done - camera ID: %d",
        __FUNCTION__, __LINE__, m_cameraId);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_setReprocessingBuffer(void)
{
    int ret = 0;
    int pictureMaxW, pictureMaxH;
    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    int planeCount  = 0;
    int bufferCount = 0;
    int minBufferCount = NUM_REPROCESSING_BUFFERS;
    int maxBufferCount = NUM_PICTURE_BUFFERS;
    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE;
    buffer_manager_allocation_mode_t allocMode = BUFFER_MANAGER_ALLOCATION_ONDEMAND;

    m_exynosCameraParameters->getMaxPictureSize(&pictureMaxW, &pictureMaxH);
    ALOGI("(%s):HW Picture MAX width x height = %dx%d", __FUNCTION__, pictureMaxW, pictureMaxH);

    /* for reprocessing */
#ifdef CAMERA_PACKED_BAYER_ENABLE
#ifdef DEBUG_RAWDUMP
    if (m_exynosCameraParameters->checkBayerDumpEnable()) {
        bytesPerLine[0] = pictureMaxW * 2;
        planeSize[0] = pictureMaxW * pictureMaxH * 2;
    } else
#endif /* DEBUG_RAWDUMP */
    {
        bytesPerLine[0] = ROUND_UP((pictureMaxW * 3 / 2), 16);
        planeSize[0] = bytesPerLine[0] * pictureMaxH;
    }
#else
    planeSize[0] = pictureMaxW * pictureMaxH * 2;
#endif
    planeCount  = 2;
    bufferCount = NUM_REPROCESSING_BUFFERS;

    if (m_exynosCameraParameters->getHighResolutionCallbackMode() == true) {
        /* ISP Reprocessing Buffer realloc for high resolution callback */
        minBufferCount = 2;
    }

    ret = m_allocBuffers(m_ispReprocessingBufferMgr, planeCount, planeSize, bytesPerLine, minBufferCount, maxBufferCount, type, allocMode, true, false);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_ispReprocessingBufferMgr m_allocBuffers(minBufferCount=%d/maxBufferCount=%d) fail",
            __FUNCTION__, __LINE__, minBufferCount, maxBufferCount);
        return ret;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_setPreviewCallbackBuffer(void)
{
    int ret = 0;
    int previewW = 0, previewH = 0;
    int previewFormat = 0;
    m_exynosCameraParameters->getPreviewSize(&previewW, &previewH);
    previewFormat = m_exynosCameraParameters->getPreviewFormat();

    unsigned int planeSize[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};
    unsigned int bytesPerLine[EXYNOS_CAMERA_BUFFER_MAX_PLANES] = {0};

    int planeCount  = getYuvPlaneCount(previewFormat);
    int bufferCount = 1;
    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_CACHED_TYPE;

    if (m_previewCallbackBufferMgr == NULL) {
        ALOGE("ERR(%s[%d]): m_previewCallbackBufferMgr is NULL", __FUNCTION__, __LINE__);
        return INVALID_OPERATION;
    }

    if (m_previewCallbackBufferMgr->isAllocated() == true) {
        if (m_exynosCameraParameters->getRestartPreview() == true) {
            ALOGD("DEBUG(%s[%d]): preview size is changed, realloc buffer", __FUNCTION__, __LINE__);
            m_previewCallbackBufferMgr->deinit();
        } else {
            return NO_ERROR;
        }
    }

    ret = getYuvPlaneSize(previewFormat, planeSize, previewW, previewH);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): BAD value, format(%x), size(%dx%d)",
            __FUNCTION__, __LINE__, previewFormat, previewW, previewH);
        return ret;
    }

    ret = m_allocBuffers(m_previewCallbackBufferMgr, planeCount, planeSize, bytesPerLine, bufferCount, bufferCount, type, false, false);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_previewCallbackBufferMgr m_allocBuffers(bufferCount=%d) fail",
            __FUNCTION__, __LINE__, bufferCount);
        return ret;
    }

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_setPictureBuffer(void)
{
    int ret = 0;
    unsigned int planeSize[3] = {0};
    unsigned int bytesPerLine[3] = {0};
    int pictureW = 0, pictureH = 0, pictureFormat = 0;
    int planeCount = 0;
    int minBufferCount = 1;
    int maxBufferCount = 1;
    exynos_camera_buffer_type_t type = EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE;
    buffer_manager_allocation_mode_t allocMode = BUFFER_MANAGER_ALLOCATION_ONDEMAND;

    m_exynosCameraParameters->getPictureSize(&pictureW, &pictureH);
    pictureFormat = m_exynosCameraParameters->getPictureFormat();

    if ((needGSCForCapture(getCameraId()) == true)
        ) {
        {
            planeSize[0] = pictureW * pictureH * 2;
        }
        planeCount = 1;
        minBufferCount = 1;
        /* TO DO : make num of buffers samely */
        if (getCameraId())
            maxBufferCount = m_exynosconfig->current->bufInfo.front_num_picture_buffers;
        else
            maxBufferCount = m_exynosconfig->current->bufInfo.num_picture_buffers;

        // Pre-allocate certain amount of buffers enough to fed into 3 JPEG save threads.
        if (m_exynosCameraParameters->getSeriesShotCount() > 0)
            minBufferCount = NUM_BURST_GSC_JPEG_INIT_BUFFER;

        ret = m_allocBuffers(m_gscBufferMgr, planeCount, planeSize, bytesPerLine, minBufferCount, maxBufferCount, type, allocMode, false, false);
        if (ret < 0) {
            ALOGE("ERR(%s[%d]):m_gscBufferMgr m_allocBuffers(minBufferCount=%d, maxBufferCount=%d) fail",
                __FUNCTION__, __LINE__, minBufferCount, maxBufferCount);
            return ret;
        }
    }

    if (m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_COMPRESSED_IMAGE) == true
        && m_hdrEnabled == false) {
        planeSize[0] = FRAME_SIZE(V4L2_PIX_2_HAL_PIXEL_FORMAT(pictureFormat), pictureW, pictureH);
        planeCount = 1;
        minBufferCount = 1;
        /* TO DO : make num of buffers samely */
        if (getCameraId())
            maxBufferCount = m_exynosconfig->current->bufInfo.front_num_picture_buffers;
        else
            maxBufferCount = m_exynosconfig->current->bufInfo.num_picture_buffers;


        type = EXYNOS_CAMERA_BUFFER_ION_CACHED_TYPE;
        ALOGD("DEBUG(%s[%d]): jpegBuffer picture(%dx%d) size(%d)", __FUNCTION__, __LINE__, pictureW, pictureH, planeSize[0]);

        // Same with above GSC buffers
        if (m_exynosCameraParameters->getSeriesShotCount() > 0)
            minBufferCount = NUM_BURST_GSC_JPEG_INIT_BUFFER;

        ret = m_allocBuffers(m_jpegBufferMgr, planeCount, planeSize, bytesPerLine, minBufferCount, maxBufferCount, type, allocMode, false, false);
        if (ret < 0)
            ALOGE("ERR(%s:%d):jpegSrcHeapBuffer m_allocBuffers(bufferCount=%d) fail",
                    __FUNCTION__, __LINE__, NUM_REPROCESSING_BUFFERS);
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_releaseBuffers(void)
{
    ALOGI("INFO(%s[%d]):release buffer", __FUNCTION__, __LINE__);
    int ret = 0;

    if (m_bayerBufferMgr != NULL) {
        m_bayerBufferMgr->deinit();
    }
    if (m_3aaBufferMgr != NULL) {
        m_3aaBufferMgr->deinit();
    }
    if (m_ispBufferMgr != NULL) {
        m_ispBufferMgr->deinit();
    }
    if (m_scpBufferMgr != NULL) {
        m_scpBufferMgr->deinit();
    }
    if (m_ispReprocessingBufferMgr != NULL) {
        m_ispReprocessingBufferMgr->deinit();
    }
    if (m_sccReprocessingBufferMgr != NULL) {
        m_sccReprocessingBufferMgr->deinit();
    }
    if (m_sccBufferMgr != NULL) {
        m_sccBufferMgr->deinit();
    }
    if (m_gscBufferMgr != NULL) {
        m_gscBufferMgr->deinit();
    }

    if (m_jpegBufferMgr != NULL) {
        m_jpegBufferMgr->deinit();
    }
    if (m_recordingBufferMgr != NULL) {
        m_recordingBufferMgr->deinit();
    }
    if (m_previewCallbackBufferMgr != NULL) {
        m_previewCallbackBufferMgr->deinit();
    }
    if (m_highResolutionCallbackBufferMgr != NULL) {
        m_highResolutionCallbackBufferMgr->deinit();
    }

    ALOGI("INFO(%s[%d]):free buffer done", __FUNCTION__, __LINE__);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_putBuffers(ExynosCameraBufferManager *bufManager, int bufIndex)
{
    if (bufManager != NULL)
        bufManager->putBuffer(bufIndex, EXYNOS_CAMERA_BUFFER_POSITION_NONE);

    return NO_ERROR;
}

status_t ExynosCameraHWImpl::m_allocBuffers(
        ExynosCameraBufferManager *bufManager,
        int  planeCount,
        unsigned int *planeSize,
        unsigned int *bytePerLine,
        int  reqBufCount,
        bool createMetaPlane,
        bool needMmap)
{
    int ret = 0;

    ret = m_allocBuffers(
                bufManager,
                planeCount,
                planeSize,
                bytePerLine,
                reqBufCount,
                reqBufCount,
                EXYNOS_CAMERA_BUFFER_ION_NONCACHED_TYPE,
                BUFFER_MANAGER_ALLOCATION_ATONCE,
                createMetaPlane,
                needMmap);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_allocBuffers(reqBufCount=%d) fail",
            __FUNCTION__, __LINE__, reqBufCount);
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_allocBuffers(
        ExynosCameraBufferManager *bufManager,
        int  planeCount,
        unsigned int *planeSize,
        unsigned int *bytePerLine,
        int  minBufCount,
        int  maxBufCount,
        exynos_camera_buffer_type_t type,
        bool createMetaPlane,
        bool needMmap)
{
    int ret = 0;

    ret = m_allocBuffers(
                bufManager,
                planeCount,
                planeSize,
                bytePerLine,
                minBufCount,
                maxBufCount,
                type,
                BUFFER_MANAGER_ALLOCATION_ONDEMAND,
                createMetaPlane,
                needMmap);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):m_allocBuffers(minBufCount=%d, maxBufCount=%d, type=%d) fail",
            __FUNCTION__, __LINE__, minBufCount, maxBufCount, type);
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_allocBuffers(
        ExynosCameraBufferManager *bufManager,
        int  planeCount,
        unsigned int *planeSize,
        unsigned int *bytePerLine,
        int  minBufCount,
        int  maxBufCount,
        exynos_camera_buffer_type_t type,
        buffer_manager_allocation_mode_t allocMode,
        bool createMetaPlane,
        bool needMmap)
{
    int ret = 0;

    ALOGI("INFO(%s[%d]):setInfo(planeCount=%d, minBufCount=%d, maxBufCount=%d, type=%d, allocMode=%d)",
        __FUNCTION__, __LINE__, planeCount, minBufCount, maxBufCount, (int)type, (int)allocMode);

    ret = bufManager->setInfo(
                        planeCount,
                        planeSize,
                        bytePerLine,
                        minBufCount,
                        maxBufCount,
                        type,
                        allocMode,
                        createMetaPlane,
                        needMmap);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setInfo fail", __FUNCTION__, __LINE__);
        goto func_exit;
    }

    ret = bufManager->alloc();
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):alloc fail", __FUNCTION__, __LINE__);
        goto func_exit;
    }

func_exit:

    return ret;
}

bool ExynosCameraHWImpl::m_getPreviewCallbackBuffer(void)
{
    CLOGD("DEBUG(%s):in", __func__);

    int i, j;
    int previewW, previewH, previewFormat, previewFramesize, previewBufW, previewBufH;
    int previewCallbackFramesize = 0;
    void *virtAddr[3];

    m_secCamera->getPreviewSize(&previewW, &previewH);
    previewFormat = m_secCamera->getPreviewFormat();

    // previewCallbackFramesize for m_previewCallbackHeap[i]
    ExynosBuffer callbackBuf;
    m_getAlignedYUVSize(m_orgPreviewRect.colorFormat, m_orgPreviewRect.w, m_orgPreviewRect.h, &callbackBuf, true);

    for (i = 0; i < ExynosBuffer::BUFFER_PLANE_NUM_DEFAULT; i++)
        previewCallbackFramesize += callbackBuf.size.extS[i];

    CLOGV("callback size: %d", previewCallbackFramesize);

    if (m_previewWindow)
        m_secCamera->setFlagInternalPreviewBuf(false);
    else
        m_secCamera->setFlagInternalPreviewBuf(true);

    ExynosBuffer previewBuf;
    m_getAlignedYUVSize(previewFormat, previewW, previewH, &previewBuf);

    for (i = 0; i < 3; i++)
        virtAddr[i] = NULL;

    for (i = 0; i < NUM_OF_PREVIEW_BUF; i++) {
        m_avaliblePreviewBufHandle[i] = false;

        if (m_previewWindow) {
            if (m_previewWindow->dequeue_buffer(m_previewWindow, &m_previewBufHandle[i], &m_previewStride[i]) != 0) {
                CLOGE("ERR(%s):Could not dequeue gralloc buffer[%d]!!", __func__, i);
                continue;
            } else {
                if (m_previewBufHandle[i] == NULL)
                    continue;

                m_numOfDequeuedBuf++;

                 if (m_previewWindow->lock_buffer(m_previewWindow, m_previewBufHandle[i]) != 0)
                     CLOGE("ERR(%s):Could not lock gralloc buffer[%d]!!", __func__, i);
            }

            if (m_flagGrallocLocked[i] == false) {
                if (m_grallocHal->lock(m_grallocHal,
                                       *m_previewBufHandle[i],
                                       GRALLOC_LOCK_FOR_CAMERA,
                                       0, 0, previewW, previewH, virtAddr) != 0) {
                    CLOGE("ERR(%s):could not obtain gralloc buffer", __func__);
                    CLOGE("ERR(%s)(%d): gralloc buffer handle information is following;", __func__, __LINE__);
                    if (*m_previewBufHandle[i] != NULL)
                        CLOGE("ERR(%s):version: %d, numFds: %d, numInts: %d, data[0]: %d ",
                                        __func__,
                                        (*m_previewBufHandle[i])->version,
                                        (*m_previewBufHandle[i])->numFds,
                                        (*m_previewBufHandle[i])->numInts,
                                        (*m_previewBufHandle[i])->data[0]);
                    else
                        CLOGE("ERR(%s):bufHandle is null ", __func__);

                    CLOGE("ERR(%s):virtAddr[0]: 0x%08x", __func__, (unsigned int)virtAddr[0]);
                    CLOGE("ERR(%s):virtAddr[1]: 0x%08x", __func__, (unsigned int)virtAddr[1]);
                    CLOGE("ERR(%s):virtAddr[2]: 0x%08x", __func__, (unsigned int)virtAddr[2]);

                    if (m_previewWindow->cancel_buffer(m_previewWindow, m_previewBufHandle[i]) != 0)
                        CLOGE("ERR(%s):Could not cancel_buffer gralloc buffer[%d]!!", __func__, i);

                    continue;
                }

                m_grallocVirtAddr[i] = virtAddr[0];
                m_matchedGrallocIndex[i] = i;
                m_flagGrallocLocked[i] = true;
                m_avaliblePreviewBufHandle[i] = true;
            }

            const private_handle_t *priv_handle = private_handle_t::dynamicCast(*m_previewBufHandle[i]);
                previewBuf.fd.extFd[0] = priv_handle->fd;
                previewBuf.fd.extFd[1] = priv_handle->fd1;
                previewBuf.virt.extP[0] = (char *)virtAddr[0];
                previewBuf.virt.extP[1] = (char *)virtAddr[1];
        } else {
            /* Hal have to allocate internal memory for preview, due to window is NULL */
            if (m_secCamera->allocInternalPreviewBuf(&previewBuf) == false) {
                CLOGE("ERR(%s):Failed to alloc internal preview buffer", __func__);
                continue;
            }
        }

        previewBuf.reserved.p = i;

        m_secCamera->setPreviewBuf(&previewBuf);
        m_setPreviewBufStatus(i, ON_DRIVER);
    }

    if (m_previewWindow) {
        int res = 0;
        for (i = NUM_OF_PREVIEW_BUF - m_minUndequeuedBufs; i < NUM_OF_PREVIEW_BUF; i++) {
            if (m_flagGrallocLocked[i] == true) {
                m_grallocHal->unlock(m_grallocHal, *m_previewBufHandle[i]);
                m_flagGrallocLocked[i] = false;
            }

            res = m_previewWindow->cancel_buffer(m_previewWindow, m_previewBufHandle[i]);
            CLOGD("DEBUG(%s):cancel buffer %d result (%dnd buffer)", __func__, res, i);
            if (res != 0) {
                CLOGE("ERR(%s):could not cancel buffer %d error(%dnd)", __func__, res, i);
                return INVALID_OPERATION;
            }
            m_secCamera->cancelPreviewBuf(i);
            m_setPreviewBufStatus(i, ON_SERVICE);

            m_numOfDequeuedBuf--;
            if (m_numOfDequeuedBuf < 0)
                m_numOfDequeuedBuf = 0;
            m_avaliblePreviewBufHandle[previewBuf.reserved.p] = false;
        }
    }

#ifndef START_HW_THREAD_ENABLE
    for (i = 0; i < NUM_OF_PREVIEW_BUF; i++) {
        if (m_previewCallbackHeap[i]) {
            m_previewCallbackHeap[i]->release(m_previewCallbackHeap[i]);
            m_previewCallbackHeap[i] = 0;
            m_previewCallbackHeapFd[i] = -1;
        }

        m_previewCallbackHeap[i] = m_getMemoryCb(-1, previewCallbackFramesize, 1, &(m_previewCallbackHeapFd[i]));
        CLOGV("callback size: %d", previewCallbackFramesize);
        if (!m_previewCallbackHeap[i] || m_previewCallbackHeapFd[i] < 0) {
            CLOGE("ERR(%s):m_getMemoryCb(m_previewCallbackHeap[%d], size(%d) fail", __func__, i, previewCallbackFramesize);
            continue;
        }
    }
#endif

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}

bool ExynosCameraHWImpl::m_startCameraHw(void)
{
    CLOGD("DEBUG(%s):in", __func__);

    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_FRONT) {
        if (m_secCamera->startSensor() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startSensor()", __func__);
            return UNKNOWN_ERROR;
        }

        if (m_secCamera->startSensorOn(ExynosCamera::CAMERA_MODE_FRONT) == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startSensorOn()", __func__);
            return UNKNOWN_ERROR;
        }

        if (m_secCamera->startIsp() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIsp()", __func__);
            return false;
        }

        if (m_secCamera->startIs3a0(ExynosCamera::CAMERA_MODE_FRONT) == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIs3a0()", __func__);
            return false;
        }

        if (m_pictureRunning == false
            && m_startPictureInternal() == false)
            CLOGE("ERR(%s):m_startPictureInternal() fail", __func__);

        if (m_secCamera->startPreview() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startPreview()", __func__);
            return false;
        }
    } else if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
        if (m_secCamera->startSensorReprocessing() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startSensorReprocessing()", __func__);
            return UNKNOWN_ERROR;
        }

        /* Sensor stream on at the OTF path */
        if (m_secCamera->startSensorOn(ExynosCamera::CAMERA_MODE_REPROCESSING) == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startSensorOn()", __func__);
            return UNKNOWN_ERROR;
        }

        if (m_secCamera->startIsp() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIsp()", __func__);
            return false;
        }

        if (m_secCamera->startIs3a1(ExynosCamera::CAMERA_MODE_BACK) == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIs3a1()", __func__);
            return false;
        }

        if (m_secCamera->startPreview() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startPreview()", __func__);
            return false;
        }

        if (m_secCamera->startIspReprocessing() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIspReprocessing()", __func__);
            return false;
        }

        if (m_secCamera->startIs3a0(ExynosCamera::CAMERA_MODE_REPROCESSING) == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startIs3a0()", __func__);
            return false;
        }

        if (m_secCamera->startSensor() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startSensor()", __func__);
            return UNKNOWN_ERROR;
        }

        if (m_pictureRunning== false
            && m_startPictureInternalReprocessing() == false)
            CLOGE("ERR(%s):m_startPictureInternalReprocessing() fail", __func__);

        if (m_secCamera->startPreviewReprocessing() == false) {
            CLOGE("ERR(%s):Fail on m_secCamera->startPreviewReprocessing()", __func__);
            return false;
        }
    }

    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
        if (m_secCamera->qAll3a1Buf() == false)
            CLOGE("ERR(%s):Fail qAll3a1Buf", __func__);
    }

    if (m_secCamera->StartStream() == false) {
        CLOGE("ERR(%s):StartStream fail", __func__);
        return false;
    }
    m_setSkipFrame(INITIAL_SKIP_FRAME);

    if (m_startSensor() != NO_ERROR) {
        CLOGE("ERR(%s):Fail on m_startSensor()", __func__);
        return false;
    }

#ifdef OTF_SENSOR_REPROCESSING
    if (m_secCamera->getCameraMode() == ExynosCamera::CAMERA_MODE_BACK) {
        if (m_startSensorReprocessing() != NO_ERROR) {
            CLOGE("ERR(%s):Fail on m_startSensorReprocessing()", __func__);
            return false;
        }
    }
#endif

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}

status_t ExynosCameraHWImpl::m_checkThreadState(int *threadState, int *countRenew)
{
    int ret = NO_ERROR;

    if ((*threadState == ERROR_POLLING_DETECTED) || (*countRenew > ERROR_DQ_BLOCKED_COUNT)) {
        ALOGW("WRN(%s[%d]:SCP DQ Timeout! State:[%d], Duration:%d msec", __FUNCTION__, __LINE__, *threadState, (*countRenew)*(MONITOR_THREAD_INTERVAL/1000));
        ret = false;
    } else {
        ALOGV("[%s] (%d) (%d)", __FUNCTION__, __LINE__, *threadState);
        ret = NO_ERROR;
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_checkThreadInterval(uint32_t pipeId, uint32_t pipeInterval, int *threadState)
{
    uint64_t *threadInterval;
    int ret = NO_ERROR;

    m_previewFrameFactory->getThreadInterval(&threadInterval, pipeId);
    if (*threadInterval > pipeInterval) {
        ALOGW("WRN(%s[%d]:Pipe(%d) Thread Interval [%lld msec], State:[%d]", __FUNCTION__, __LINE__, pipeId, (*threadInterval)/1000, *threadState);
        ret = false;
    } else {
        ALOGV("Thread IntervalTime [%lld]", *threadInterval);
        ALOGV("Thread Renew Count [%d]", *countRenew);
        ret = NO_ERROR;
    }

    return ret;
}

bool ExynosCameraHWImpl::m_monitorThreadFunc(void)
{
    ALOGV("INFO(%s[%d]):", __FUNCTION__, __LINE__);

    int *threadState;
    int *countRenew;
    int camId = getCameraId();
    int ret = NO_ERROR;


#if 0
    /* check PIPE_SCP thread state & interval */
    m_previewFrameFactory->getThreadState(&threadState, PIPE_SCP);
    m_previewFrameFactory->getThreadRenew(&countRenew, PIPE_SCP);
    m_checkThreadState(threadState, countRenew)?:ret = false;

    if (ret == false) {
        dump();

        /* in GED */
        /* m_notifyCb(CAMERA_MSG_ERROR, 100, 0, m_callbackCookie); */
        /* specifically defined */
        m_notifyCb(CAMERA_MSG_ERROR, 1001, 0, m_callbackCookie);
        /* or */
        /* android_printAssert(NULL, LOG_TAG, "killed by itself"); */
    }
    m_checkThreadInterval(PIPE_SCP, WARNING_SCP_THREAD_INTERVAL, threadState)?:ret = false;

    /* check PIPE_3AA thread state & interval */
    if(camId == CAMERA_ID_BACK) {
        m_previewFrameFactory->getThreadRenew(&countRenew, PIPE_3AA_ISP);
        m_checkThreadState(threadState, countRenew)?:ret = false;

        if (ret == false) {
            dump();

            /* in GED */
            m_notifyCb(CAMERA_MSG_ERROR, 100, 0, m_callbackCookie);
            /* specifically defined */
            /* m_notifyCb(CAMERA_MSG_ERROR, 1001, 0, m_callbackCookie); */
            /* or */
            android_printAssert(NULL, LOG_TAG, "killed by itself");
        }

        m_checkThreadInterval(PIPE_3AA_ISP, WARNING_3AA_THREAD_INTERVAL, threadState)?:ret = false;
    }
    else if(camId == CAMERA_ID_FRONT) {
        m_previewFrameFactory->getThreadRenew(&countRenew, PIPE_3AA_FRONT);
        m_checkThreadState(threadState, countRenew)?:ret = false;

        if (ret == false) {
            dump();

            /* in GED */
            m_notifyCb(CAMERA_MSG_ERROR, 100, 0, m_callbackCookie);
            /* specifically defined */
            /* m_notifyCb(CAMERA_MSG_ERROR, 1001, 0, m_callbackCookie); */
            /* or */
            android_printAssert(NULL, LOG_TAG, "killed by itself");
        }

        m_checkThreadInterval(PIPE_3AA_FRONT, WARNING_3AA_THREAD_INTERVAL, threadState)?:ret = false;
    }
    else {
        ALOGE("ERR(%s[%d]):Invalid Camera ID [%d]", __FUNCTION__, __LINE__, camId);
    }

    if (m_callbackState == 0) {
        m_callbackStateOld = 0;
        m_callbackState = 0;
        m_callbackMonitorCount = 0;
    } else {
        if (m_callbackStateOld != m_callbackState) {
            m_callbackStateOld = m_callbackState;
            ALOGD("INFO(%s[%d]):callback state is updated (0x%x)", __FUNCTION__, __LINE__, m_callbackStateOld);
        } else {
            if ((m_callbackStateOld & m_callbackState) != 0)
                ALOGE("ERR(%s[%d]):callback is blocked (0x%x), Duration:%d msec", __FUNCTION__, __LINE__, m_callbackState, m_callbackMonitorCount*(MONITOR_THREAD_INTERVAL/1000));
        }
    }
#endif

    m_previewFrameFactory->incThreadRenew(PIPE_SCP);

    usleep(MONITOR_THREAD_INTERVAL);

    return true;
}

bool ExynosCameraHWImpl::m_autoFocusResetNotify(int focusMode)
{
    /* show restart */
    ALOGD("DEBUG(%s):CAMERA_MSG_FOCUS(%d) mode(%d)", __func__, 4, focusMode);
    m_notifyCb(CAMERA_MSG_FOCUS, 4, 0, m_callbackCookie);

    /* show focusing */
    ALOGD("DEBUG(%s):CAMERA_MSG_FOCUS(%d) mode(%d)", __func__, 3, focusMode);
    m_notifyCb(CAMERA_MSG_FOCUS, 3, 0, m_callbackCookie);

    return true;
}

bool ExynosCameraHWImpl::m_autoFocusThreadFunc(void)
{
    ALOGI("INFO(%s[%d]): -IN-", __FUNCTION__, __LINE__);

    bool afResult = false;
    int focusMode = 0;

    /* block until we're told to start.  we don't want to use
     * a restartable thread and requestExitAndWait() in cancelAutoFocus()
     * because it would cause deadlock between our callbacks and the
     * caller of cancelAutoFocus() which both want to grab the same lock
     * in CameraServices layer.
     */

    if (m_autoFocusType == AUTO_FOCUS_SERVICE) {
        focusMode = m_exynosCameraParameters->getFocusMode();
    } else if (m_autoFocusType == AUTO_FOCUS_HAL) {
        focusMode = FOCUS_MODE_AUTO;

        m_autoFocusResetNotify(focusMode);

        m_autoFocusLock.lock();
    }

    /* check early exit request */
    if (m_exitAutoFocusThread == true) {
        ALOGD("DEBUG(%s):exiting on request", __FUNCTION__);
        goto done;
    }

    m_autoFocusRunning = true;

    if (m_autoFocusRunning == true) {
        //afResult = m_secCamera->autoFocus();
        afResult = m_exynosCameraActivityControl->autoFocus(focusMode, m_autoFocusType);
        if (afResult == true)
            ALOGV("DEBUG(%s):autoFocus Success!!", __FUNCTION__);
        else
            ALOGV("DEBUG(%s):autoFocus Fail !!", __FUNCTION__);
    } else {
        ALOGV("DEBUG(%s):autoFocus canceled !!", __FUNCTION__);
    }

    /*
     * CAMERA_MSG_FOCUS only takes a bool.  true for
     * finished and false for failure.
     * If cancelAutofocus() called, no callback.
     */
    if ((m_autoFocusRunning == true) &&
        /*(m_enabledMsgType & CAMERA_MSG_FOCUS)) {*/
        m_exynosCameraParameters->msgTypeEnabled(CAMERA_MSG_FOCUS)) {

        if (m_notifyCb != NULL) {
            int afFinalResult = (int)afResult;

            /* if inactive detected, tell it */
            /*
            if (m_secCamera->getFocusMode() == ExynosCamera::FOCUS_MODE_CONTINUOUS_PICTURE) {
                if (m_secCamera->getCAFResult() == 2) { */
            if (focusMode == FOCUS_MODE_CONTINUOUS_PICTURE) {
                if (m_exynosCameraActivityControl->getCAFResult() == 2) {
                    afFinalResult = 2;
                }
            }

            //CLOGD("DEBUG(%s):CAMERA_MSG_FOCUS(%d) mode(%d)", __func__, afFinalResult, m_secCamera->getFocusMode());
            ALOGD("DEBUG(%s):CAMERA_MSG_FOCUS(%d) mode(%d)", __FUNCTION__, afFinalResult, focusMode);
            m_notifyCb(CAMERA_MSG_FOCUS, afFinalResult, 0, m_callbackCookie);
        }  else {
            //CLOGD("DEBUG(%s):m_notifyCb is NULL mode(%d)", __func__, m_secCamera->getFocusMode());
            ALOGD("DEBUG(%s):m_notifyCb is NULL mode(%d)", __FUNCTION__, focusMode);
        }
    } else {
        ALOGV("DEBUG(%s):autoFocus canceled, no callback !!", __FUNCTION__);
    }

    m_autoFocusRunning = false;

    ALOGV("DEBUG(%s):exiting with no error", __FUNCTION__);

done:
    m_autoFocusLock.unlock();

    ALOGI("DEBUG(%s):end", __FUNCTION__);

    return true;
}

status_t ExynosCameraHWImpl::dump(int fd) const
{
    ALOGI("INFO(%s[%d]):", __FUNCTION__, __LINE__);
    const size_t SIZE = 256;
    char buffer[SIZE];
    String8 result;
    const Vector<String16> args;

    if (m_secCamera != 0) {
        m_params.dump(fd, args);
        snprintf(buffer, 255, " preview running(%s)\n", m_previewRunning?"true": "false");
        result.append(buffer);
    } else {
        result.append("No camera client yet.\n");
    }

    write(fd, result.string(), result.size());

    return NO_ERROR;
}

void ExynosCameraHWImpl::dump()
{
    ALOGI("INFO(%s[%d]):", __FUNCTION__, __LINE__);

    if (m_previewFrameFactory != NULL)
        m_previewFrameFactory->dump();

    if (m_bayerBufferMgr != NULL)
        m_bayerBufferMgr->dump();
    if (m_3aaBufferMgr != NULL)
        m_3aaBufferMgr->dump();
    if (m_ispBufferMgr != NULL)
        m_ispBufferMgr->dump();
    if (m_scpBufferMgr != NULL)
        m_scpBufferMgr->dump();

    if (m_ispReprocessingBufferMgr != NULL)
        m_ispReprocessingBufferMgr->dump();
    if (m_sccReprocessingBufferMgr != NULL)
        m_sccReprocessingBufferMgr->dump();
    if (m_sccBufferMgr != NULL)
        m_sccBufferMgr->dump();
    if (m_gscBufferMgr != NULL)
        m_gscBufferMgr->dump();

    return;
}

status_t ExynosCameraHWImpl::m_getBufferManager(uint32_t pipeId, ExynosCameraBufferManager **bufMgr, uint32_t direction)
{
    status_t ret = NO_ERROR;
    ExynosCameraBufferManager **bufMgrList[2] = {NULL};
    *bufMgr = NULL;

    if (getCameraId() == CAMERA_ID_BACK) {
        switch (pipeId) {
        case PIPE_FLITE:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_bayerBufferMgr;
            break;
        case PIPE_3AA_ISP:
            bufMgrList[0] = &m_3aaBufferMgr;
            bufMgrList[1] = &m_ispBufferMgr;
            break;
        case PIPE_3AC:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_bayerBufferMgr;
            break;
        case PIPE_SCP:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_scpBufferMgr;
            break;
        case PIPE_3AA_REPROCESSING:
            bufMgrList[0] = &m_bayerBufferMgr;
            bufMgrList[1] = &m_ispReprocessingBufferMgr;
            break;
        case PIPE_ISP_REPROCESSING:
            bufMgrList[0] = &m_ispReprocessingBufferMgr;
            bufMgrList[1] = NULL;
            break;
#if 0 // TODO: need to commonize
        case PIPE_SCC_REPROCESSING:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_sccBufferMgr;
            break;
        case PIPE_GSC_REPROCESSING:
            bufMgrList[0] = &m_sccBufferMgr;
            bufMgrList[1] = &m_gscBufferMgr;
            break;
        case PIPE_ISP_REPROCESSING:
            bufMgrList[0] = &m_bayerBufferMgr;
            bufMgrList[1] = NULL;
            break;
#endif
        case PIPE_SCC_REPROCESSING:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_sccReprocessingBufferMgr;
            break;
        case PIPE_GSC_REPROCESSING:
            bufMgrList[0] = &m_sccReprocessingBufferMgr;
            bufMgrList[1] = &m_gscBufferMgr;
            break;
        default:
            ALOGE("ERR(%s[%d]): Unknown pipeId(%d)", __FUNCTION__, __LINE__, pipeId);
            bufMgrList[0] = NULL;
            bufMgrList[1] = NULL;
            ret = BAD_VALUE;
            break;
        }
    } else {
        switch (pipeId) {
        case PIPE_FLITE_FRONT:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_bayerBufferMgr;
            break;
        case PIPE_3AA_FRONT:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_ispBufferMgr;
            break;
        case PIPE_ISP_FRONT:
            bufMgrList[0] = NULL;
            bufMgrList[1] = NULL;
            break;
        case PIPE_SCC_FRONT:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_sccBufferMgr;
            break;
        case PIPE_SCP_FRONT:
            bufMgrList[0] = NULL;
            bufMgrList[1] = &m_scpBufferMgr;
            break;
        case PIPE_GSC_PICTURE_FRONT:
            bufMgrList[0] = &m_sccBufferMgr;
            bufMgrList[1] = &m_gscBufferMgr;
            break;
        default:
            ALOGE("ERR(%s[%d]): Unknown pipeId(%d)", __FUNCTION__, __LINE__, pipeId);
            bufMgrList[0] = NULL;
            bufMgrList[1] = NULL;
            ret = BAD_VALUE;
            break;
        }
    }

    if (bufMgrList[direction] != NULL)
        *bufMgr = *bufMgrList[direction];

    return ret;
}

uint32_t ExynosCameraHWImpl::m_getBayerPipeId(void)
{
    uint32_t pipeId = 0;

    if (m_exynosCameraParameters->getUsePureBayerReprocessing() == true)
        pipeId = PIPE_FLITE;
    else
        pipeId = PIPE_3AC;

    return pipeId;
}

void ExynosCameraHWImpl::m_debugFpsCheck(uint32_t pipeId)
{
#ifdef FPS_CHECK
    uint32_t id = pipeId % DEBUG_MAX_PIPE_NUM;

    m_debugFpsCount[id]++;
    if (m_debugFpsCount[id] == 1) {
        m_debugFpsTimer[id].start();
    }
    if (m_debugFpsCount[id] == 30) {
        m_debugFpsTimer[id].stop();
        long long durationTime = m_debugFpsTimer[id].durationMsecs();
        ALOGI("DEBUG: FPS_CHECK(id:%d), duration %lld / 30 = %lld ms", pipeId, durationTime, durationTime / 30);
        m_debugFpsCount[id] = 0;
    }
#endif
}

status_t ExynosCameraHWImpl::m_convertingStreamToShotExt(ExynosCameraBuffer *buffer, struct camera2_node_output *outputInfo)
{
/* TODO: HACK: Will be removed, this is driver's job */
    status_t ret = NO_ERROR;
    int bayerFrameCount = 0;
    camera2_shot_ext *shot_ext = NULL;
    camera2_stream *shot_stream = NULL;

    shot_stream = (struct camera2_stream *)buffer->addr[1];
    bayerFrameCount = shot_stream->fcount;
    outputInfo->cropRegion[0] = shot_stream->output_crop_region[0];
    outputInfo->cropRegion[1] = shot_stream->output_crop_region[1];
    outputInfo->cropRegion[2] = shot_stream->output_crop_region[2];
    outputInfo->cropRegion[3] = shot_stream->output_crop_region[3];

    memset(buffer->addr[1], 0x0, sizeof(struct camera2_shot_ext));

    shot_ext = (struct camera2_shot_ext *)buffer->addr[1];
    shot_ext->shot.dm.request.frameCount = bayerFrameCount;

    return ret;
}

status_t ExynosCameraHWImpl::m_getBayerBuffer(uint32_t pipeId, ExynosCameraBuffer *buffer)
{
    status_t ret = NO_ERROR;
    bool isSrc = false;
    int retryCount = 30; /* 200ms x 30 */
    camera2_shot_ext *shot_ext = NULL;

    m_captureSelector->setWaitTime(200000000);
    ExynosCameraFrame *bayerFrame = m_captureSelector->selectFrames(m_reprocessingCounter.getCount(), pipeId, isSrc, retryCount);
    if (bayerFrame == NULL) {
        ALOGE("ERR(%s[%d]):bayerFrame is NULL", __FUNCTION__, __LINE__);
        ret = INVALID_OPERATION;
        goto ERR;
    }

    ret = bayerFrame->getDstBuffer(pipeId, buffer);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]): getDstBuffer fail, pipeId(%d), ret(%d)", __FUNCTION__, __LINE__, pipeId, ret);
        goto ERR;
    }

    shot_ext = (struct camera2_shot_ext *)buffer->addr[1];

    ALOGD("DEBUG(%s[%d]): Selected frame count(hal : %d / driver : %d)", __FUNCTION__, __LINE__,
                                                                         bayerFrame->getFrameCount(),
                                                                         shot_ext->shot.dm.request.frameCount);
    return ret;

ERR:
    if (bayerFrame != NULL && bayerFrame->isComplete() == true) {
        if (bayerFrame->getFrameLockState() == false) {
            ALOGD("DEBUG(%s[%d]): Selected frame(%d) complete, Delete", __FUNCTION__, __LINE__, bayerFrame->getFrameCount());
            delete bayerFrame;
        }
        bayerFrame = NULL;
    }

    return ret;
}

status_t ExynosCameraHWImpl::m_checkBufferAvailable(uint32_t pipeId, ExynosCameraBufferManager *bufferMgr)
{
    status_t ret = TIMED_OUT;
    int retry = 0;

    do {
        ret = -1;
        retry++;
        if (bufferMgr->getNumOfAvailableBuffer() > 0) {
            ret = OK;
        } else {
            /* wait available ISP buffer */
            usleep(WAITING_TIME);
        }
        if (retry % 10 == 0)
            ALOGW("WRAN(%s[%d]):retry(%d) setupEntity for pipeId(%d)", __FUNCTION__, __LINE__, retry, pipeId);
    } while(ret < 0 && retry < (TOTAL_WAITING_TIME/WAITING_TIME));

    return ret;
}

status_t ExynosCameraHWImpl::m_boostDynamicCapture(void)
{
    status_t ret = NO_ERROR;
#if 0 /* TODO: need to implementation for bayer */
    uint32_t pipeId = PIPE_SCC;
    uint32_t size = m_processList.size();

    ExynosCameraFrame *curFrame = NULL;
    List<ExynosCameraFrame *>::iterator r;
    camera2_node_group node_group_info_isp;

    if (m_processList.empty()) {
        ALOGD("DEBUG(%s[%d]):m_processList is empty", __FUNCTION__, __LINE__);
        return NO_ERROR;
    }
    ALOGD("DEBUG(%s[%d]):m_processList size(%d)", __FUNCTION__, __LINE__, m_processList.size());
    r = m_processList.end();

    for (unsigned int i = 0; i < 3; i++) {
        r--;
        if (r == m_processList.begin())
            break;

    }

    curFrame = *r;
    if (curFrame == NULL) {
        ALOGE("ERR(%s):curFrame is empty", __FUNCTION__);
        return INVALID_OPERATION;
    }

    if (curFrame->getRequest(PIPE_SCC) == true) {
        ALOGD("DEBUG(%s[%d]): Boosting dynamic capture is not need", __FUNCTION__, __LINE__);
        return NO_ERROR;
    }

    ALOGI("INFO(%s[%d]): boosting dynamic capture (frameCount: %d)", __FUNCTION__, __LINE__, curFrame->getFrameCount());
    /* For ISP */
    curFrame->getNodeGroupInfo(&node_group_info_isp, PERFRAME_INFO_ISP);
    m_updateBoostDynamicCaptureSize(&node_group_info_isp);
    curFrame->storeNodeGroupInfo(&node_group_info_isp, PERFRAME_INFO_ISP);

    curFrame->setRequest(pipeId, true);
    curFrame->setNumRequestPipe(curFrame->getNumRequestPipe() + 1);

    ret = curFrame->setEntityState(pipeId, ENTITY_STATE_REWORK);
    if (ret < 0) {
        ALOGE("ERR(%s[%d]):setEntityState fail, pipeId(%d), state(%d), ret(%d)",
                __FUNCTION__, __LINE__, pipeId, ENTITY_STATE_REWORK, ret);
        return ret;
    }

    m_previewFrameFactory->pushFrameToPipe(&curFrame, pipeId);
    m_dynamicSccCount++;
    ALOGV("DEBUG(%s[%d]): dynamicSccCount inc(%d) frameCount(%d)", __FUNCTION__, __LINE__, m_dynamicSccCount, curFrame->getFrameCount());
#endif

    return ret;
}

void ExynosCameraHWImpl::m_updateBoostDynamicCaptureSize(camera2_node_group *node_group_info)
{
#if 0 /* TODO: need to implementation for bayer */
    ExynosRect sensorSize;
    ExynosRect bayerCropSize;

    node_group_info->capture[PERFRAME_BACK_SCC_POS].request = 1;

    m_exynosCameraParameters->getPreviewBayerCropSize(&sensorSize, &bayerCropSize);

    node_group_info->leader.input.cropRegion[0] = bayerCropSize.x;
    node_group_info->leader.input.cropRegion[1] = bayerCropSize.y;
    node_group_info->leader.input.cropRegion[2] = bayerCropSize.w;
    node_group_info->leader.input.cropRegion[3] = bayerCropSize.h;
    node_group_info->leader.output.cropRegion[0] = 0;
    node_group_info->leader.output.cropRegion[1] = 0;
    node_group_info->leader.output.cropRegion[2] = node_group_info->leader.input.cropRegion[2];
    node_group_info->leader.output.cropRegion[3] = node_group_info->leader.input.cropRegion[3];

    /* Capture 0 : SCC - [scaling] */
    node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[0] = node_group_info->leader.output.cropRegion[0];
    node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[1] = node_group_info->leader.output.cropRegion[1];
    node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[2] = node_group_info->leader.output.cropRegion[2];
    node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[3] = node_group_info->leader.output.cropRegion[3];

    node_group_info->capture[PERFRAME_BACK_SCC_POS].output.cropRegion[0] = node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[0];
    node_group_info->capture[PERFRAME_BACK_SCC_POS].output.cropRegion[1] = node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[1];
    node_group_info->capture[PERFRAME_BACK_SCC_POS].output.cropRegion[2] = node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[2];
    node_group_info->capture[PERFRAME_BACK_SCC_POS].output.cropRegion[3] = node_group_info->capture[PERFRAME_BACK_SCC_POS].input.cropRegion[3];

    /* Capture 1 : SCP - [scaling] */
    node_group_info->capture[PERFRAME_BACK_SCP_POS].input.cropRegion[0] = node_group_info->leader.output.cropRegion[0];
    node_group_info->capture[PERFRAME_BACK_SCP_POS].input.cropRegion[1] = node_group_info->leader.output.cropRegion[1];
    node_group_info->capture[PERFRAME_BACK_SCP_POS].input.cropRegion[2] = node_group_info->leader.output.cropRegion[2];
    node_group_info->capture[PERFRAME_BACK_SCP_POS].input.cropRegion[3] = node_group_info->leader.output.cropRegion[3];

#endif
    return;
}

void ExynosCameraHWImpl::m_checkFpsAndUpdatePipeWaitTime(void)
{
    uint32_t curMinFps = 0;
    uint32_t curMaxFps = 0;
    frame_queue_t *inputFrameQ = NULL;

    m_exynosCameraParameters->getPreviewFpsRange(&curMinFps, &curMaxFps);

    if (m_curMinFps != curMinFps) {
        ALOGD("DEBUG(%s[%d]):(%d)(%d)", __FUNCTION__, __LINE__, curMinFps, curMaxFps);
        m_previewFrameFactory->getInputFrameQToPipe(&inputFrameQ, PIPE_SCC);

        /* 100ms * (30 / 15 fps) = 200ms */
        /* 100ms * (30 / 30 fps) = 100ms */
        /* 100ms * (30 / 10 fps) = 300ms */
        if (inputFrameQ != NULL && curMinFps != 0)
            inputFrameQ->setWaitTime((100000000 * (30 / curMinFps)));
    }

    m_curMinFps = curMinFps;

    return;
}

void ExynosCameraHWImpl::m_checkPreviewTime(void)
{
    m_previewTimer.stop();
    if (m_previewTimerIndex == CHECK_TIME_FRAME_DURATION) {

        long long totalTime = 0;
        for (int i = 0; i < CHECK_TIME_FRAME_DURATION; i++)
            totalTime += m_previewTimerTime[i];

        unsigned int gapTime = (unsigned int)(totalTime / CHECK_TIME_FRAME_DURATION);
        CLOGD("DEBUG:CHECK_TIME_PREVIEW : %d(%.1f fps)", gapTime, (1000000.0f / (float)gapTime));
        m_previewTimerIndex = 0;
    }

    if (m_previewTimerIndex != 0)
        m_previewTimerTime[m_previewTimerIndex] = m_previewTimer.durationUsecs();

    if (m_previewTimerIndex == 1)
        m_previewTimerTime[0] = m_previewTimerTime[1];

    m_previewTimerIndex++;

    m_previewTimer.start();
}

bool ExynosCameraHWImpl::m_checkPictureBufferVaild(ExynosBuffer *buf, int retry)
{
    int ret = false;

    if (buf->reserved.p >= 0
        && buf->virt.p != NULL
        && buf->size.s > 0) {
        if (((camera2_shot_ext *)buf->virt.extP[1])->shot.dm.request.frameCount != 0) {
            ret = true;
        } else {
            CLOGW("WRN(%s): frame[%d] count is 0", __func__, buf->reserved.p);
            m_secCamera->printBayerLockStatus();
        }

        goto out;
    } else if (retry > 30) {
        CLOGE("ERR(%s):time out", __func__);
        ret = true;
        goto out;
    }

    CLOGW("WRN(%s): buffer is invalid, retry after 1ms", __func__);
    usleep(1000);
out:
    return ret;
}

void ExynosCameraHWImpl::m_checkRecordingTime(void)
{
    m_recordingTimer.stop();
    if (m_recordingTimerIndex == CHECK_TIME_FRAME_DURATION) {

        long long totalTime = 0;
        for (int i = 0; i < CHECK_TIME_FRAME_DURATION; i++)
            totalTime += m_recordingTimerTime[i];

        unsigned int gapTime = (unsigned int)(totalTime / CHECK_TIME_FRAME_DURATION);
        CLOGD("DEBUG:CHECK_TIME_RECORDING : %d(%.1f fps)", gapTime, (1000000.0f / (float)gapTime));
        m_recordingTimerIndex = 0;
    }

    if (m_recordingTimerIndex != 0)
        m_recordingTimerTime[m_recordingTimerIndex] = m_recordingTimer.durationUsecs();

    if (m_recordingTimerIndex == 1)
        m_recordingTimerTime[0] = m_recordingTimerTime[1];

    m_recordingTimerIndex++;

    m_recordingTimer.start();
}

void ExynosCameraHWImpl::m_pushVideoQ(ExynosBuffer *buf)
{
    Mutex::Autolock lock(m_videoQMutex);
    m_videoQ.push_back(*buf);
}

bool ExynosCameraHWImpl::m_popVideoQ(ExynosBuffer *buf)
{
    List<ExynosBuffer>::iterator r;

    Mutex::Autolock lock(m_videoQMutex);

    if (m_videoQ.size() == 0)
        return false;

    r = m_videoQ.begin()++;
    *buf = *r;
    m_videoQ.erase(r);

    return true;
}

int ExynosCameraHWImpl::m_sizeOfVideoQ(void)
{
    Mutex::Autolock lock(m_videoQMutex);

    return m_videoQ.size();
}

void ExynosCameraHWImpl::m_releaseVideoQ(void)
{
    List<ExynosBuffer>::iterator r;

    Mutex::Autolock lock(m_videoQMutex);

    while (m_videoQ.size() > 0) {
        r = m_videoQ.begin()++;
        m_videoQ.erase(r);
    }
}

void ExynosCameraHWImpl::m_pushPreviewQ(ExynosBuffer *buf)
{
    Mutex::Autolock lock(m_previewQMutex);

    m_previewQ.push_back(*buf);
}

void ExynosCameraHWImpl::m_pushFrontPreviewQ(ExynosBuffer *buf)
{
    Mutex::Autolock lock(m_previewQMutex);

    m_previewQ.push_front(*buf);
}

bool ExynosCameraHWImpl::m_popPreviewQ(ExynosBuffer *buf)
{
    List<ExynosBuffer>::iterator r;

    Mutex::Autolock lock(m_previewQMutex);

    if (m_previewQ.size() == 0)
        return false;

    r = m_previewQ.begin()++;
    *buf = *r;
    m_previewQ.erase(r);
    return true;
}

bool ExynosCameraHWImpl::m_eraseBackPreviewQ()
{
    List<ExynosBuffer>::iterator r;
    Mutex::Autolock lock(m_previewQMutex);
    ExynosBuffer buf;

    if (m_previewQ.size() == 0)
        return false;


    r = m_previewQ.begin();
    buf = *r;
    for (unsigned int i = 0; i < m_previewQ.size() - 1; i++) {
        r++;
        buf = *r;
    }
    m_previewQ.erase(r);

    return true;
}

int ExynosCameraHWImpl::m_sizeOfPreviewQ(void)
{
    Mutex::Autolock lock(m_previewQMutex);

    return m_previewQ.size();
}

void ExynosCameraHWImpl::m_releasePreviewQ(void)
{
    List<ExynosBuffer>::iterator r;

    Mutex::Autolock lock(m_previewQMutex);

    while (m_previewQ.size() > 0) {
        r = m_previewQ.begin()++;
        m_previewQ.erase(r);
    }
}

void ExynosCameraHWImpl::m_setPreviewBufStatus(int index, int status)
{
    m_previewBufStatus[index] = status;
}

int ExynosCameraHWImpl::m_getRecordingFrame(void)
{
    Mutex::Autolock lock(m_recordingFrameMutex);

    for (int i = 0; i < NUM_OF_VIDEO_BUF; i++) {
        m_recordingFrameIndex++;

        /* rotate index */
        if (NUM_OF_VIDEO_BUF <= m_recordingFrameIndex)
            m_recordingFrameIndex = 0;

        if (m_recordingFrameAvailable[m_recordingFrameIndex] == true) {
            m_availableRecordingFrameCnt--;
            m_recordingFrameAvailable[m_recordingFrameIndex] = false;
            return m_recordingFrameIndex;
        }
    }

    for (int i = 0; i < NUM_OF_VIDEO_BUF; i++) {
        CLOGD("DEBUG(%s:%d):m_recordingFrameAvailable[%d](%d) / m_availableRecordingFrameCnt(%d)",
            __func__, __LINE__, i, m_recordingFrameAvailable[i], m_availableRecordingFrameCnt);
    }

    return -1;
}

void ExynosCameraHWImpl::m_resetRecordingFrameStatus(void)
{
    Mutex::Autolock lock(m_recordingFrameMutex);

    for (int i = 0; i < NUM_OF_VIDEO_BUF; i++)
        m_recordingFrameAvailable[i] = true;

    m_availableRecordingFrameCnt = NUM_OF_VIDEO_BUF;
    m_recordingFrameIndex = 0;
}

void ExynosCameraHWImpl::m_freeRecordingFrame(int index)
{
    Mutex::Autolock lock(m_recordingFrameMutex);

    m_availableRecordingFrameCnt++;
    m_recordingFrameAvailable[index] = true;
}

void ExynosCameraHWImpl::m_setStartPreviewComplete(int threadId, bool toggle)
{
/*    CLOGE("%s : threadId 0x%x toggle 0x%x", __func__, threadId, toggle); */
    if (toggle == true)
        m_startComplete |= (threadId);
    else
        m_startComplete &= (~threadId);
}

bool ExynosCameraHWImpl::m_checkStartPreviewComplete(uint32_t mask)
{
/*    CLOGE("%s : mask 0x%x state 0x%x", __func__, mask, m_startComplete); */
    if ((m_startComplete & mask) == mask)
        return true;
    else
        return false;
}

void ExynosCameraHWImpl::m_clearAllStartPreviewComplete(void)
{
    m_startComplete = THREAD_ID_ALL_CLEARED;
}

#ifdef SCALABLE_SENSOR
bool ExynosCameraHWImpl::m_chgScalableSensorSize(enum SCALABLE_SENSOR_SIZE sizeMode)
{
    CLOGD("DEBUG(%s):in", __func__);

    Mutex::Autolock lock(m_13MCaptureLock);
#ifdef SCALABLE_SENSOR_CHKTIME
    struct timeval start, end;
    int sec, usec;
#endif
    CLOGD("DEBUG(%s):start", __func__);

    if (m_checkScalableSate(sizeMode) == false) {
        CLOGE("ERR(%s):m_checkScalableSate() fail", __func__);
        return false;
    }

    /* when m_13MCaptureStart is true, skip previewThread */
    switch (sizeMode) {
    case SCALABLE_SENSOR_SIZE_13M:
        m_13MCaptureStart = true;
        break;
    }

    /* 1. stop sensor Thread */
#ifdef SCALABLE_SENSOR_CHKTIME
    gettimeofday(&start, NULL);
#endif

    CLOGD("DEBUG(%s): 1. stop sensor Thread start", __func__);

#if !defined(SCALABLE_SENSOR_FORCE_DONE)
    ExynosBuffer sensorBuf;
    ExynosBuffer ispBuf;
    m_secCamera->notifyStop(true);
    m_sensorThread->requestExitAndWait();
    while (m_secCamera->getNumOfShotedFrame() > 0) {
        CLOGD("DEBUG %s(%d), stop phase - %d frames are remained", __func__, __LINE__, m_secCamera->getNumOfShotedFrame());
        if (m_secCamera->getIs3a1Buf(ExynosCameraHWImpl::CAMERA_MODE_BACK, &sensorBuf, &ispBuf) == false) {
            CLOGE("ERR(%s):getIs3a1Buf() fail(id:%d)", __func__, getCameraId());
        }
        if (ispBuf.reserved.p < 0) {
            CLOGW("WRN(%s): ispBuf.reserved.p = %d", __func__, ispBuf.reserved.p);
            continue;
        }
        if (m_secCamera->putISPBuf(&ispBuf) == false) {
            CLOGE("ERR(%s):putISPBuf() fail", __func__);
        }
        isp_input_count++;
        m_ispCondition.signal();
    }
    if (0 < isp_input_count)
        usleep(5000);

    isp_input_count = 0;
#else
    m_sensorThread->requestExitAndWait();
#endif

#ifdef SCALABLE_SENSOR_CHKTIME
    gettimeofday(&end, NULL);
    CLOGD("DEBUG(%s):CHKTIME 1. stop sensor Thread (%d)", __func__, (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec));
#endif

    /* 2. Sensor size change */
#ifdef SCALABLE_SENSOR_CHKTIME
    gettimeofday(&start, NULL);
#endif

    CLOGD("DEBUG(%s): 2. Sensor size change start", __func__);
    if (!m_secCamera->setScalableSensorSize(sizeMode)) {
        CLOGE("ERR(%s):setScalableSensorSize fail", __func__);
        return false;
    }

#ifdef SCALABLE_SENSOR_CHKTIME
    gettimeofday(&end, NULL);
    CLOGD("DEBUG(%s):CHKTIME 2. Sensor size change (%d)", __func__, (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec));
#endif

    /* 3. restart sensor thread */
#ifdef SCALABLE_SENSOR_CHKTIME
    gettimeofday(&start, NULL);
#endif

    CLOGD("DEBUG(%s): 3. restart sensor thread start ", __func__);
#if !defined(SCALABLE_SENSOR_FORCE_DONE)
    m_secCamera->notifyStop(false);
#endif

    m_sensorThread->run("CameraSensorThread", PRIORITY_DEFAULT);

    /* when m_13MCaptureStart is false, keep running previewThread */
    switch (sizeMode) {
    case SCALABLE_SENSOR_SIZE_FHD:
        m_13MCaptureStart = false;
        break;
    }

#ifdef SCALABLE_SENSOR_CHKTIME
    gettimeofday(&end, NULL);
    CLOGD("DEBUG(%s):CHKTIME 3. restart sensor thread (%d)", __func__, (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec));
#endif

    CLOGD("DEBUG(%s):out", __func__);

    return true;
}

bool ExynosCameraHWImpl::m_checkScalableSate(enum SCALABLE_SENSOR_SIZE sizeMode)
{
    bool ret = true;
    bool checkMode;

    if (sizeMode == SCALABLE_SENSOR_SIZE_13M) {
        checkMode = true;
    } else if (sizeMode == SCALABLE_SENSOR_SIZE_FHD) {
        checkMode = false;
    } else {
        CLOGE("ERR(%s):Unknown mode", __func__);
        return false;
    }

    if (checkMode == m_13MCaptureStart) {
        CLOGE("ERR(%s):invalid scalable sensor mode(new = %x, cur = %x)", __func__, sizeMode, m_13MCaptureStart);
        ret = false;
    }

    return ret;
}

bool ExynosCameraHWImpl::m_checkAndWaitScalableSate(enum SCALABLE_SENSOR_SIZE sizeMode)
{
    bool ret = true;
    bool checkMode;
    int retryCnt = 30;

    if (sizeMode == SCALABLE_SENSOR_SIZE_13M) {
        checkMode = true;
    } else if (sizeMode == SCALABLE_SENSOR_SIZE_FHD) {
        checkMode = false;
    } else {
        CLOGE("ERR(%s):Unknown mode", __func__);
        return false;
    }

    while (0 < retryCnt) {
        if (checkMode != m_13MCaptureStart) {
            CLOGD("DEBUG(%s): HIT scalable sensor mode", __func__);
            ret = true;
            break;
        }
        CLOGD("DEBUG(%s): waiting change scalable sensor mode", __func__);
        retryCnt--;
        usleep(30000);
    }

    if (retryCnt == 0) {
        CLOGE("ERR(%s):TIMEOUT!", __func__);
        ret = false;
    }

    return ret;
}

#endif


}; /* namespace android */
