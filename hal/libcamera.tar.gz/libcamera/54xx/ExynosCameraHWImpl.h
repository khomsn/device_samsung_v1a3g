/*
**
** Copyright 2013, Samsung Electronics Co. LTD
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#ifndef EXYNOS_CAMERA_HW_IMPLEMENTATION_H
#define EXYNOS_CAMERA_HW_IMPLEMENTATION_H

#include <common/Buffers/ExynosCameraBuffer.h>
#include <common/ExynosCameraFrame.h>
#include <common/ExynosCameraList.h>
#include <common/Buffers/ExynosCameraBufferManager.h>
#include <ExynosCameraFrameFactory.h>
#include <ExynosCameraScalableSensor.h>
#include <common/ExynosCameraFrameSelector.h>
#include <common/ExynosCameraHWInterface.h>

namespace android {

typedef struct ExynosCameraJpegCallbackBuffer {
    ExynosCameraBuffer buffer;
    int callbackNumber;
} jpeg_callback_buffer_t;

typedef ExynosCameraList<ExynosCameraFrame *> frame_queue_t;
typedef ExynosCameraList<jpeg_callback_buffer_t> jpeg_callback_queue_t;

typedef enum buffer_direction_type {
    SRC_BUFFER_DIRECTION        = 0,
    DST_BUFFER_DIRECTION        = 1,
    INVALID_BUFFER_DIRECTION,
} buffer_direction_type_t;

enum jpeg_save_thread {
    JPEG_SAVE_THREAD0       = 0,
    JPEG_SAVE_THREAD1       = 1,
    JPEG_SAVE_THREAD2,
};


class ExynosCameraHWInterface;

class ExynosCameraHWImpl : public ExynosCameraHWInterface {
public:
    ExynosCameraHWImpl() : ExynosCameraHWInterface(){};
    ExynosCameraHWImpl(int cameraId, camera_device_t *dev);
    virtual             ~ExynosCameraHWImpl();

    void        setCallbacks(
                    camera_notify_callback notify_cb,
                                     camera_data_callback data_cb,
                                     camera_data_timestamp_callback data_cb_timestamp,
                                     camera_request_memory get_memory,
                                     void *user);

    void        enableMsgType(int32_t msgType);
    void        disableMsgType(int32_t msgType);
    bool        msgTypeEnabled(int32_t msgType);

    /* startPreview(), stopPreview(), setParameters(), setPreviewWindows() must be excuted exclusively
       related lock is m_startStopLock; */
    status_t    startPreviewLocked();
    void        stopPreviewLocked();
    status_t    setParametersLocked(const CameraParameters& params);
    status_t    setPreviewWindowLocked(preview_stream_ops *w);

    bool        previewEnabled();

    status_t    storeMetaDataInBuffers(bool enable);

    status_t    startRecording();
    void        stopRecording();
    bool        recordingEnabled();
    void        releaseRecordingFrame(const void *opaque);

    status_t    autoFocus();
    status_t    cancelAutoFocus();

    status_t    takePicture();
    status_t    cancelPicture();

    CameraParameters  getParameters() const;
    status_t    sendCommand(int32_t command, int32_t arg1, int32_t arg2);

    int         getMaxNumDetectedFaces(void);
    bool        startFaceDetection(void);
    bool        stopFaceDetection(void);

    bool        m_startFaceDetection(bool toggle);
    status_t    m_doFdCallbackFunc(ExynosCameraFrame *frame);

    void        release();

    status_t    dump(int fd) const;
    void        dump(void);

    inline  int         getCameraId() const;
    bool        isReprocessing(void) const;
    bool        isSccCapture(void) const;

    status_t    generateFrame(int32_t frameCount, ExynosCameraFrame **newFrame);

    status_t    generateFrameReprocessing(ExynosCameraFrame **newFrame);

public:
    ExynosCameraParameters          *m_exynosCameraParameters;
    ExynosCameraFrameFactory        *m_previewFrameFactory;
    ExynosCameraGrallocAllocator    *m_grAllocator;
    ExynosCameraIonAllocator        *m_ionAllocator;
    ExynosCameraMHBAllocator        *m_mhbAllocator;

    ExynosCameraFrameFactory        *m_pictureFrameFactory;

    ExynosCameraFrameFactory        *m_reprocessingFrameFactory;
    mutable Mutex                   m_frameLock;

    bool                            m_previewEnabled;
    bool                            m_pictureEnabled;
    bool                            m_recordingEnabled;
    bool                            m_zslPictureEnabled;

    ExynosCameraActivityControl     *m_exynosCameraActivityControl;


/*************************************Private*********************************/
private:
    void        m_createThreads(void);

    status_t    m_startPreviewInternal(void);
    //bool        m_startPreviewInternal(void);
    status_t    m_stopPreviewInternal(void);
    //void        m_stopPreviewInternal(void);
    status_t    m_restartPreviewInternal(void);

    status_t    m_startPictureInternal(void);
    status_t    m_stopPictureInternal(void);

    status_t    m_startRecordingInternal(void);
    status_t    m_stopRecordingInternal(void);

    status_t    m_searchFrameFromList(List<ExynosCameraFrame *> *list, uint32_t frameCount, ExynosCameraFrame **frame);
    status_t    m_removeFrameFromList(List<ExynosCameraFrame *> *list, ExynosCameraFrame *frame);

    status_t    m_clearList(List<ExynosCameraFrame *> *list);

    status_t    m_printFrameList(List<ExynosCameraFrame *> *list);

    status_t    m_createIonAllocator(ExynosCameraIonAllocator **allocator);
    status_t    m_createInternalBufferManager(ExynosCameraBufferManager **bufferManager, const char *name);
    status_t    m_createBufferManager(
                    ExynosCameraBufferManager **bufferManager,
                    const char *name,
                    buffer_manager_type type = BUFFER_MANAGER_ION_TYPE);

    status_t    m_setConfigInform();
    status_t    m_setBuffers(void);
    status_t    m_setReprocessingBuffer(void);
    status_t    m_setPreviewCallbackBuffer(void);
    status_t    m_setPictureBuffer(void);
    status_t    m_releaseBuffers(void);

    status_t    m_putBuffers(ExynosCameraBufferManager *bufManager, int bufIndex);
    status_t    m_allocBuffers(
                    ExynosCameraBufferManager *bufManager,
                    int  planeCount,
                    unsigned int *planeSize,
                    unsigned int *bytePerLine,
                    int  reqBufCount,
                    bool createMetaPlane,
                    bool needMmap = false);
    status_t    m_allocBuffers(
                    ExynosCameraBufferManager *bufManager,
                    int  planeCount,
                    unsigned int *planeSize,
                    unsigned int *bytePerLine,
                    int  minBufCount,
                    int  maxBufCount,
                    exynos_camera_buffer_type_t type,
                    bool createMetaPlane,
                    bool needMmap = false);
    status_t    m_allocBuffers(
                    ExynosCameraBufferManager *bufManager,
                    int  planeCount,
                    unsigned int *planeSize,
                    unsigned int *bytePerLine,
                    int  minBufCount,
                    int  maxBufCount,
                    exynos_camera_buffer_type_t type,
                    buffer_manager_allocation_mode_t allocMode,
                    bool createMetaPlane,
                    bool needMmap = false);

    status_t    m_handlePreviewFrame(ExynosCameraFrame *frame);
    status_t    m_handlePreviewFrameFront(ExynosCameraFrame *frame);

    status_t    m_setupEntity(
                    uint32_t pipeId,
                    ExynosCameraFrame *newFrame,
                    ExynosCameraBuffer *srcBuf = NULL,
                    ExynosCameraBuffer *dstBuf = NULL);
    status_t    m_setSrcBuffer(
                    uint32_t pipeId,
                    ExynosCameraFrame *newFrame,
                    ExynosCameraBuffer *buffer);
    status_t    m_setDstBuffer(
                    uint32_t pipeId,
                    ExynosCameraFrame *newFrame,
                    ExynosCameraBuffer *buffer);

    status_t    m_getBufferManager(uint32_t pipeId, ExynosCameraBufferManager **bufMgr, uint32_t direction);

    status_t    m_calcPreviewGSCRect(ExynosRect *srcRect, ExynosRect *dstRect);
    status_t    m_calcHighResolutionPreviewGSCRect(ExynosRect *srcRect, ExynosRect *dstRect);
    status_t    m_calcRecordingGSCRect(ExynosRect *srcRect, ExynosRect *dstRect);
    status_t    m_calcPictureRect(ExynosRect *srcRect, ExynosRect *dstRect);
    status_t    m_calcPictureRect(int originW, int originH, ExynosRect *srcRect, ExynosRect *dstRect);

    status_t    m_setCallbackBufferInfo(ExynosCameraBuffer *callbackBuf, char *baseAddr);

    status_t    m_doPreviewToCallbackFunc(
                    int32_t pipeId,
                    ExynosCameraFrame *newFrame,
                    ExynosCameraBuffer previewBuf,
                    ExynosCameraBuffer callbackBuf);
   // bool        m_doPreviewToCallbackFunc(ExynosBuffer previewBuf, ExynosBuffer *callbackBuf, bool useCSC);                
    status_t    m_doCallbackToPreviewFunc(
                    int32_t pipeId,
                    ExynosCameraFrame *newFrame,
                    ExynosCameraBuffer callbackBuf,
                    ExynosCameraBuffer previewBuf);
//    bool        m_doCallbackToPreviewFunc(ExynosBuffer previewBuf, ExynosBuffer *callbackBuf, bool useCSC);                    
    status_t    m_doPrviewToRecordingFunc(
                    int32_t pipeId,
                    ExynosCameraBuffer previewBuf,
                    ExynosCameraBuffer recordingBuf);
    status_t    m_releaseRecordingBuffer(int bufIndex);

    status_t    m_fastenAeStable(void);
    camera_memory_t *m_getJpegCallbackHeap(ExynosCameraBuffer callbackBuf, int seriesShotNumber);

    void        m_debugFpsCheck(uint32_t pipeId);

    uint32_t    m_getBayerPipeId(void);

    status_t    m_convertingStreamToShotExt(ExynosCameraBuffer *buffer, struct camera2_node_output *outputInfo);

    status_t    m_getBayerBuffer(uint32_t pipeId, ExynosCameraBuffer *buffer);
    status_t    m_checkBufferAvailable(uint32_t pipeId, ExynosCameraBufferManager *bufferMgr);

    status_t    m_boostDynamicCapture(void);
    void        m_updateBoostDynamicCaptureSize(camera2_node_group *node_group_info);
    void        m_checkFpsAndUpdatePipeWaitTime(void);

private:
    typedef ExynosCameraThread<ExynosCameraHWImpl> mainCameraThread;

    uint32_t                        m_cameraId;

    camera_notify_callback          m_notifyCb;
    camera_data_callback            m_dataCb;
    camera_data_timestamp_callback  m_dataCbTimestamp;
    camera_request_memory           m_getMemoryCb;
    void                            *m_callbackCookie;

    List<ExynosCameraFrame *>       m_processList;
    List<ExynosCameraFrame *>       m_postProcessList;
    frame_queue_t                   *m_pipeFrameDoneQ;

    sp<mainCameraThread>            m_mainThread;
    bool                            m_mainThreadFunc(void);

    frame_queue_t                   *m_previewQ;
    frame_queue_t                   *m_previewFrontQ;
    sp<mainCameraThread>            m_previewThread;
     //sp<mainCameraThread>    m_previewThread;
    bool                            m_previewThreadFunc(void);

    sp<mainCameraThread>            m_setBuffersThread;
    bool                            m_setBuffersThreadFunc(void);

    sp<mainCameraThread>            m_startPictureInternalThread;
    bool                            m_startPictureInternalThreadFunc(void);

    sp<mainCameraThread>            m_autoFocusThread;
    //sp<AutoFocusThread> m_autoFocusThread;
    bool                            m_autoFocusThreadFunc(void);
    bool                            m_autoFocusResetNotify(int focusMode);
    mutable Mutex       m_autoFocusLock;
    mutable Mutex                   m_captureLock;
    bool                m_exitAutoFocusThread;
    bool                m_autoFocusRunning;
    int                             m_autoFocusType;

    ExynosCameraBufferManager       *m_bayerBufferMgr;
    ExynosCameraBufferManager       *m_3aaBufferMgr;
    ExynosCameraBufferManager       *m_ispBufferMgr;
    ExynosCameraBufferManager       *m_sccBufferMgr;
    ExynosCameraBufferManager       *m_scpBufferMgr;

    uint32_t                        m_fliteFrameCount;
    uint32_t                        m_3aa_ispFrameCount;
    uint32_t                        m_sccFrameCount;
    uint32_t                        m_scpFrameCount;

    /* for Recording */
    bool                            m_doCscRecording;
    frame_queue_t                   *m_recordingQ;
    mutable Mutex                   m_recordingStateLock;
    nsecs_t                         m_lastRecordingTimeStamp;
    nsecs_t                         m_recordingStartTimeStamp;

    ExynosCameraBufferManager       *m_recordingBufferMgr;

    nsecs_t                         m_recordingTimeStamp[MAX_BUFFERS];
    sp<mainCameraThread>            m_recordingThread;
    bool                            m_recordingThreadFunc(void);

    ExynosCameraBufferManager       *m_previewCallbackBufferMgr;
    ExynosCameraBufferManager       *m_highResolutionCallbackBufferMgr;

    /* Pre picture Thread */
    sp<mainCameraThread>            m_prePictureThread;
    bool                            m_reprocessingPrePictureInternal(void);
    bool                            m_prePictureInternal(bool* pIsProcessed);
    bool                            m_prePictureThreadFunc(void);

    sp<mainCameraThread>            m_pictureThread;
        //sp<PictureThread>   m_pictureThread;
    bool                            m_pictureThreadFunc(void);

    sp<mainCameraThread>            m_postPictureThread;
    bool                            m_postPictureThreadFunc(void);

    sp<mainCameraThread>            m_jpegCallbackThread;
    bool                            m_jpegCallbackThreadFunc(void);
    void                            m_clearJpegCallbackThread(void);

    bool                            m_releasebuffersForRealloc(void);

    /* Reprocessing Buffer Managers */
    ExynosCameraBufferManager       *m_ispReprocessingBufferMgr;

    ExynosCameraBufferManager       *m_sccReprocessingBufferMgr;

    /* TODO: will be removed when SCC scaling for picture size */
    ExynosCameraBufferManager       *m_gscBufferMgr;

    ExynosCameraBufferManager       *m_jpegBufferMgr;

    ExynosCameraCounter             m_takePictureCounter;
    ExynosCameraCounter             m_reprocessingCounter;
    ExynosCameraCounter             m_pictureCounter;
    ExynosCameraCounter             m_jpegCounter;

    /* Reprocessing Q */
    frame_queue_t                   *dstIspReprocessingQ;
    frame_queue_t                   *dstSccReprocessingQ;
    frame_queue_t                   *dstGscReprocessingQ;

    frame_queue_t                   *dstJpegReprocessingQ;

    frame_queue_t                   *m_postPictureQ;
    jpeg_callback_queue_t           *m_jpegCallbackQ;

    bool                            m_flagStartFaceDetection;
    camera_face_t            m_faces[NUM_OF_DETECTED_FACES];
    camera_frame_metadata_t         m_frameMetadata;
    camera_memory_t                 *m_fdCallbackHeap;

    bool                     m_faceDetected;
    int                      m_fdThreshold;

    ExynosCameraScalableSensor      m_scalableSensorMgr;

    /* Watch Dog Thread */
    sp<mainCameraThread>            m_monitorThread;
    bool                            m_monitorThreadFunc(void);
    status_t                        m_checkThreadState(int *threadState, int *countRenew);
    status_t                        m_checkThreadInterval(uint32_t pipeId, uint32_t pipeInterval, int *threadState);
    unsigned int                    m_callbackState;
    unsigned int                    m_callbackStateOld;
    int                             m_callbackMonitorCount;
    bool                            m_isNeedAllocPictureBuffer;

#ifdef FPS_CHECK
    /* TODO: */
#define DEBUG_MAX_PIPE_NUM 10
    int32_t                         m_debugFpsCount[DEBUG_MAX_PIPE_NUM];
    ExynosCameraDurationTimer       m_debugFpsTimer[DEBUG_MAX_PIPE_NUM];
#endif

    ExynosCameraFrameSelector       *m_captureSelector;
    ExynosCameraFrameSelector       *m_sccCaptureSelector;

    bool                            m_stopBurstShot;
    bool                            m_burst[3];
    bool                            m_running[3];

    /* high resolution preview callback */
    sp<mainCameraThread>            m_highResolutionCallbackThread;
    bool                            m_highResolutionCallbackThreadFunc(void);

    frame_queue_t                   *m_highResolutionCallbackQ;
    bool                            m_highResolutionCallbackRunning;
    bool                            m_skipReprocessing;
    bool                            m_resetPreview;

    uint32_t                        m_displayPreviewToggle;

    bool                            m_hdrEnabled;
    unsigned int                    m_hdrSkipedFcount;
    bool                            m_isFirstStart;
    uint32_t                        m_dynamicSccCount;
    bool                            m_isTryStopFlash;

    int                             m_previewBufferCount;
    struct ExynosConfigInfo         *m_exynosconfig;

    uint32_t                        m_recordingFrameSkipCount;

    uint32_t                        m_curMinFps;

private:
    status_t    setParameters(const CameraParameters& params);
    status_t    setPreviewWindow(preview_stream_ops *w);
    status_t    startPreview();
    void        stopPreview();

private:
    bool        m_initSecCamera(int cameraId);
    void        m_initDefaultParameters(int cameraId);

    void        m_disableMsgType(int32_t msgType, bool restore);
    void        m_restoreMsgType(void);

    status_t    m_startSensor();
    void        m_stopSensor();
    bool        m_sensorThreadFuncWrap(void);
    bool        m_sensorThreadFuncM2M(void);
    bool        m_sensorThreadFuncOTF(void);

    status_t    m_startSensorReprocessing();
    void        m_stopSensorReprocessing();
    bool        m_sensorThreadFuncReprocessing(void);

#ifdef START_HW_THREAD_ENABLE
    bool        m_startThreadFuncMain(void);
    bool        m_startThreadFuncReprocessing(void);
    bool        m_startThreadFuncBufAlloc(void);
#endif

    void        m_releaseBuffer(void);
    bool        m_getPreviewCallbackBuffer(void);
    bool        m_startCameraHw(void);


    bool        m_videoThreadFuncWrapper(void);
    bool        m_videoThreadFunc(void);

    bool        m_ispThreadFunc(void);





    int         m_saveJpeg(unsigned char *real_jpeg, int jpeg_size);
    int         m_decodeInterleaveData(unsigned char *pInterleaveData,
                                       int interleaveDataSize,
                                       int yuvWidth,
                                       int yuvHeight,
                                       int *pJpegSize,
                                       void *pJpegData,
                                       void *pYuvData);
    bool        m_YUY2toNV21(void *srcBuf, void *dstBuf, uint32_t srcWidth, uint32_t srcHeight);
    bool        m_scaleDownYuv422(char *srcBuf, uint32_t srcWidth,
                                  uint32_t srcHight, char *dstBuf,
                                  uint32_t dstWidth, uint32_t dstHight);

    bool        m_checkVideoStartMarker(unsigned char *pBuf);
    bool        m_checkEOIMarker(unsigned char *pBuf);
    bool        m_findEOIMarkerInJPEG(unsigned char *pBuf,
                                      int dwBufSize, int *pnJPEGsize);
    bool        m_splitFrame(unsigned char *pFrame, int dwSize,
                             int dwJPEGLineLength, int dwVideoLineLength,
                             int dwVideoHeight, void *pJPEG,
                             int *pdwJPEGSize, void *pVideo,
                             int *pdwVideoSize);

    void        m_setSkipFrame(int frame);
    int         m_getSkipFrame();
    void        m_decSkipFrame();

    bool        m_isSupportedPreviewSize(const int width, const int height);
    bool        m_isSupportedPictureSize(const int width, const int height) const;
    bool        m_isSupportedVideoSize(const int width, const int height) const;

    int         m_getAlignedYUVSize(int colorFormat, int w, int h, ExynosBuffer *buf, bool flagAndroidColorFormat = false);

    bool        m_getSupportedFpsList(String8 & string8Buf, int min, int max);
    bool        m_getSupportedVariableFpsList(int min, int max, int *newMin, int *newMax);
    bool        m_getResolutionList(String8 & string8Buf, int *w, int *h, int mode);
    bool        m_getZoomRatioList(String8 & string8Buf, int maxZoom, int start, int end);
    bool        m_getMatchedPictureSize(const int src_w, const int src_h, int *dst_w, int *dst_h);

    int         m_bracketsStr2Ints(char *str, int num, ExynosRect2 *rect2s, int *weights, int mode);
    bool        m_subBracketsStr2Ints(int num, char *str, int *arr);

    int         m_calibratePosition(int w, int new_w, int pos);

    bool        m_startPictureInternalReprocessing(void);
    bool        m_stopPictureInternalReprocessing(void);
    void        m_checkPreviewTime(void);
    void        m_checkRecordingTime(void);

    bool        m_checkPictureBufferVaild(ExynosBuffer *buf, int retry);
    void        m_resetRecordingFrameStatus(void);
    int         m_getRecordingFrame(void);
    void        m_freeRecordingFrame(int index);

    void        m_pushVideoQ(ExynosBuffer *buf);
    bool        m_popVideoQ(ExynosBuffer *buf);
    int         m_sizeOfVideoQ(void);
    void        m_releaseVideoQ(void);

    void        m_pushFrontPreviewQ(ExynosBuffer *buf);
    void        m_pushPreviewQ(ExynosBuffer *buf);
    bool        m_popPreviewQ(ExynosBuffer *buf);
    int         m_sizeOfPreviewQ(void);
    void        m_releasePreviewQ(void);
    bool        m_eraseBackPreviewQ(void);

    void        m_setPreviewBufStatus(int index, int status);

    bool        m_skipFrom3A1ToIsp(int skipCnt, int backFpsMin, int backFpsMax);

    mutable Mutex   m_startStopLock;
    bool        m_checkStartPreviewComplete(uint32_t mask);
    void        m_setStartPreviewComplete(int threadId, bool toggle);
    void        m_clearAllStartPreviewComplete(void);
#ifdef SCALABLE_SENSOR
    bool        m_chgScalableSensorSize(enum SCALABLE_SENSOR_SIZE sizeMode);
    bool        m_checkScalableSate(enum SCALABLE_SENSOR_SIZE sizeMode);
    bool        m_checkAndWaitScalableSate(enum SCALABLE_SENSOR_SIZE sizeMode);
#endif

#ifdef START_HW_THREAD_ENABLE
    sp<StartThreadMain>      m_startThreadMain;
    sp<StartThreadReprocessing>     m_startThreadReprocessing;
    sp<StartThreadBufAlloc>  m_startThreadBufAlloc;
#endif

    
    sp<mainCameraThread>     m_videoThread;
    

    sp<mainCameraThread>    m_sensorThread;
    sp<mainCameraThread>    m_sensorThreadReprocessing;
    sp<mainCameraThread>    m_ispThread;

#ifdef START_HW_THREAD_ENABLE
    mutable Mutex       m_startThreadMainLock;
    mutable Condition   m_startThreadMainCondition;
    bool                m_startThreadMainRunning;
    bool                m_exitStartThreadMain;
    bool                m_errorExistInStartThreadMain;

    mutable Mutex       m_startThreadMainFinishLock;
    mutable Condition   m_startThreadMainFinishCondition;

    mutable Mutex       m_startThreadReprocessingLock;
    mutable Condition   m_startThreadReprocessingCondition;
    bool                m_startThreadReprocessingRunning;
    bool                m_exitStartThreadReprocessing;
    bool                m_errorExistInStartThreadReprocessing;

    mutable Mutex       m_startThreadReprocessingFinishLock;
    mutable Condition   m_startThreadReprocessingFinishCondition;
    bool                m_startThreadReprocessingFinished;
    bool                m_startThreadReprocessingFinishWaiting;

    mutable Mutex       m_startThreadBufAllocLock;
    mutable Condition   m_startThreadBufAllocCondition;
    bool                m_exitStartThreadBufAlloc;
    bool                m_errorExistInStartThreadBufAlloc;

    mutable Mutex       m_startThreadBufAllocFinishLock;
    mutable Condition   m_startThreadBufAllocFinishCondition;
    bool                m_startThreadBufAllocFinished;
    bool                m_startThreadBufAllocWaiting;
#endif


    mutable Mutex       m_ispLock;
    mutable Condition   m_ispCondition;
    bool                m_exitIspThread;

    /* used by preview thread to block until it's told to run */
    mutable Mutex       m_previewLock;

#ifdef USE_CAMERA_ESD_RESET
            bool        m_sensorESDReset;
#endif
            bool        m_previewRunning;
            bool        m_previewStartDeferred;
    unsigned int        m_startComplete;

    mutable Mutex       m_videoLock;
    mutable Condition   m_videoCondition;
    mutable Condition   m_videoStoppedCondition;
//            bool        m_recordingEnabled;
            bool        m_exitVideoThread;

    mutable Mutex       m_sensorStopLock;
    mutable Mutex       m_sensorLock;
    bool                m_sensorRunning;

    mutable Mutex       m_sensorLockReprocessing;
    bool                m_sensorRunningReprocessing;

    void               *m_grallocVirtAddr[NUM_OF_PREVIEW_BUF];
    int                 m_matchedGrallocIndex[NUM_OF_PREVIEW_BUF];
    nsecs_t             m_videoBufTimestamp[NUM_OF_PREVIEW_BUF];
    ExynosBuffer        m_pictureBuf[NUM_OF_FLASH_BUF];

    ExynosBuffer        m_sharedBayerBuffer;
    ExynosBuffer        m_sharedISPBuffer;

    mutable Mutex       m_pictureLock;
    mutable Condition   m_pictureCondition;
            bool        m_pictureRunning;
            bool        m_captureInProgress;
            bool        m_captureMode;
            bool        m_waitForCapture;

    ExynosRect          m_orgPreviewRect;
    ExynosRect          m_orgPictureRect;
    ExynosRect          m_orgVideoRect;

    void               *m_exynosPreviewCSC;
    void               *m_exynosPictureCSC;
    void               *m_exynosVideoCSC;

    int                 m_flip_horizontal;
    bool                m_isCSCBypassed;

    preview_stream_ops *m_previewWindow;

    int                 m_numOfDequeuedBuf;

    /* used to guard threading state */
    mutable Mutex       m_stateLock;

    CameraParameters    m_params;

    camera_memory_t    *m_previewCallbackHeap[NUM_OF_PREVIEW_BUF];

    buffer_handle_t    *m_previewBufHandle[NUM_OF_PREVIEW_BUF];
    int                 m_previewStride[NUM_OF_PREVIEW_BUF];
    bool                m_avaliblePreviewBufHandle[NUM_OF_PREVIEW_BUF];
    bool                m_flagGrallocLocked[NUM_OF_PREVIEW_BUF];
    int                 m_previewBufStatus[NUM_OF_PREVIEW_BUF];
    bool                m_previewBufRegistered[NUM_OF_PREVIEW_BUF];

    int                 m_minUndequeuedBufs;

    int                 m_recordingFrameIndex;

    Mutex               m_videoQMutex;
    List<ExynosBuffer>  m_videoQ;

    Mutex               m_previewQMutex;
    List<ExynosBuffer>  m_previewQ;

    camera_memory_t    *m_recordingCallbackHeap;
    camera_memory_t    *m_videoHeap[NUM_OF_VIDEO_BUF];
    camera_memory_t    *m_resizedVideoHeap[NUM_OF_VIDEO_BUF][2];

    camera_memory_t    *m_pictureHeap[NUM_OF_PICTURE_BUF];
    camera_memory_t    *m_rawHeap;
    int                 m_rawHeapSize;

    camera_memory_t    *m_jpegHeap;
    int                 m_jpegHeapFd;

    bool                m_callbackCSC;

    int                 m_previewCallbackHeapFd[NUM_OF_PREVIEW_BUF];
    int                 m_recordingCallbackHeapFd;
    int                 m_videoHeapFd[NUM_OF_VIDEO_BUF];
    int                 m_resizedVideoHeapFd[NUM_OF_VIDEO_BUF][2];
    bool                m_recordingFrameAvailable[NUM_OF_VIDEO_BUF];
    int                 m_pictureHeapFd[NUM_OF_PICTURE_BUF];
    int                 m_rawHeapFd;

    int                 m_flashMode;
    int                 m_previewCount;
    int                 m_availableRecordingFrameCnt;
    Mutex               m_recordingFrameMutex;

    DurationTimer       m_startPreviewTimer;
    DurationTimer       m_shot2ShotTimer;

    DurationTimer       m_previewTimer;
    long long           m_previewTimerTime[CHECK_TIME_FRAME_DURATION];
    int                 m_previewTimerIndex;
    DurationTimer       m_recordingTimer;
    long long           m_recordingTimerTime[CHECK_TIME_FRAME_DURATION];
    int                 m_recordingTimerIndex;

    int                 m_sensorErrCnt;

    ExynosCamera       *m_secCamera;
#ifdef USE_VDIS
    ExynosCameraVDis   *m_VDis;
#endif

    mutable Mutex       m_skipFrameLock;
            int         m_skipFrame;


            int32_t     m_enabledMsgType;
            int32_t     m_storedMsg;

    camera_device_t *m_halDevice;
    static gralloc_module_t const* m_grallocHal;

    static Mutex g_is3a0Mutex;
    static Mutex g_is3a1Mutex;

    int isp_input_count;
    int isp_last_frame_cnt;

    unsigned int m_sharedBayerFcount;
#ifdef FORCE_LEADER_OFF
    bool tryThreadStop;
    int tryThreadStatus;
    bool leaderOff;
#endif

#ifdef DYNAMIC_BAYER_BACK_REC
    bool isDqSensor;
#endif

#ifdef SCALABLE_SENSOR
#ifndef DYNAMIC_BAYER_BACK_REC
    bool isDqSensor;
#endif
    bool         m_13MCaptureStart;
    Mutex        m_13MCaptureLock;
#endif

    bool         m_forceAELock;
    char         m_antiBanding[10];

private:
#ifdef START_HW_THREAD_ENABLE
    class StartThreadMain : public Thread {
        ExynosCameraHWImpl *mHardware;
    public:
        StartThreadMain(ExynosCameraHWImpl *hw): Thread(false), mHardware(hw) { }
        virtual void onFirstRef() {
            run("CameraStartThreadMain", PRIORITY_DEFAULT);
        }
        virtual bool threadLoop() {
            mHardware->m_startThreadFuncMain();
            return true;
        }
    };

    class StartThreadReprocessing : public Thread {
        ExynosCameraHWImpl *mHardware;
    public:
        StartThreadReprocessing(ExynosCameraHWImpl *hw): Thread(false), mHardware(hw) { }
        virtual void onFirstRef() {
            run("CameraStartThreadReprocessing", PRIORITY_DEFAULT);
        }
        virtual bool threadLoop() {
            mHardware->m_startThreadFuncReprocessing();
            return true;
        }
    };

    class StartThreadBufAlloc : public Thread {
        ExynosCameraHWImpl *mHardware;
    public:
        StartThreadBufAlloc(ExynosCameraHWImpl *hw): Thread(false), mHardware(hw) { }
        virtual void onFirstRef() {
            run("CameraStartThreadBufAlloc", PRIORITY_DEFAULT);
        }
        virtual bool threadLoop() {
            mHardware->m_startThreadFuncBufAlloc();
            return true;
        }
    };
#endif

    class VideoThread : public Thread {
        ExynosCameraHWImpl *mHardware;
    public:
        VideoThread(ExynosCameraHWImpl *hw):
        Thread(false),
        mHardware(hw) { }
        virtual void onFirstRef() {
            run("CameraVideoThread", PRIORITY_DEFAULT);
        }
        virtual bool threadLoop() {
            mHardware->m_videoThreadFuncWrapper();
            return false;
        }
    };

    class PictureThread : public Thread {
        ExynosCameraHWImpl *mHardware;
    public:
        PictureThread(ExynosCameraHWImpl *hw):
        Thread(false),
        mHardware(hw) { }
        virtual bool threadLoop() {
            mHardware->m_pictureThreadFunc();
            return false;
        }
    };

    class AutoFocusThread : public Thread {
        ExynosCameraHWImpl *mHardware;
    public:
        AutoFocusThread(ExynosCameraHWImpl *hw): Thread(false), mHardware(hw) { }
        virtual void onFirstRef() {
            /* run("CameraAutoFocusThread", PRIORITY_DEFAULT); */
        }
        virtual bool threadLoop() {
            mHardware->m_autoFocusThreadFunc();
            return false;
        }
    };

    typedef bool (ExynosCameraHWImpl::*thread_loop)(void);

    class CameraThread : public Thread {
        ExynosCameraHWImpl *mHardware;
        thread_loop mThreadLoop;
        char mName[64];
        struct timeval mTimeStart;
        struct timeval mTimeStop;
    public:
        CameraThread(ExynosCameraHWImpl *hw, thread_loop loop) :
#ifdef SINGLE_PROCESS
            // In single process mode this thread needs to be a java thread,
            // since we won't be calling through the binder.
            Thread(true),
#else
            Thread(false),
#endif
            mHardware(hw),
            mThreadLoop(loop) {
            memset(&mTimeStart, 0, sizeof(mTimeStart));
            memset(&mTimeStop, 0, sizeof(mTimeStop));
            memset(&mName, 0, sizeof(mName));
        }

        virtual status_t run(const char* name = 0,
            int32_t priority = PRIORITY_DEFAULT,
            size_t stack = 0) {

            ALOGD("DEBUG(%s):Thread(%s) start running", __func__, name);

            memset(&mTimeStart, 0, sizeof(mTimeStart));
            memset(&mTimeStop, 0, sizeof(mTimeStop));
            memset(&mName, 0, sizeof(mName));
            memcpy(mName, name, strlen(name) + 1);

            return Thread::run(name, priority, stack);
        }

        void calcFrameWaitTime(int maxFps) {
            // Calculate how long to wait between frames
            if (mTimeStart.tv_sec == 0 && mTimeStart.tv_usec == 0) {
                gettimeofday(&mTimeStart, NULL);
            }
            else {
                gettimeofday(&mTimeStop, NULL);
                unsigned long timeUs = (mTimeStop.tv_sec*1000000 + mTimeStop.tv_usec)
                    - (mTimeStart.tv_sec*1000000 + mTimeStart.tv_usec);
                gettimeofday(&mTimeStart, NULL);
                //unsigned long framerateUs = 1000.0/maxFps*1000000;
                //unsigned long delay = framerateUs > timeUs ? framerateUs - timeUs : 0;

                ALOGV("%s: time %ld us", mName, timeUs);
                //usleep(delay);
            }
        }

    private:
        virtual bool threadLoop() {
            // loop until we need to quit
            return (mHardware->*mThreadLoop)();
        }
    };


private:

    enum THREAD_ID {
        THREAD_ID_ALL_CLEARED = 0,
        THREAD_ID_SENSOR      = 1 << 0,
        THREAD_ID_PREVIEW     = 1 << 1,
        THREAD_ID_BAYER_OUT   = 1 << 2,
        THREAD_ID_ALL_SET     = (THREAD_ID_SENSOR | THREAD_ID_PREVIEW | THREAD_ID_BAYER_OUT)
    };

};

}; /* namespace android */

#endif
